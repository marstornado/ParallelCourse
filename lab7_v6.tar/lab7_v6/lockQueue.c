//
//  lockQueue.c
//  lab6
//
//  Created by mastornado on 11/2/14.
//  Copyright (c) 2014 mastornado. All rights reserved.
//

#include "lockQueue.h"
#include "queue.h"
#include <pthread.h>
#include <stdlib.h>

typedef struct {
    pthread_mutex_t mutexl;
    void *qp;
}lockNode;


public void* LockQOpen(void) {
    lockNode *lockq =(lockNode*)malloc(sizeof(lockNode));
    void *lockQBegin = qopen();
    pthread_mutex_init(&(lockq->mutexl),  NULL);
    lockq->qp = lockQBegin;
    return (void *)lockq;
}

public void LockQPut(void *qp, void* elementp) {
    lockNode *lockq = (lockNode *)qp;
    pthread_mutex_lock(&(lockq->mutexl));
    qput(lockq->qp, elementp);
    pthread_mutex_unlock(&(lockq->mutexl));
}

public void* LockQGet(void *qp) {
    lockNode *lockq = (lockNode *)qp;
    pthread_mutex_lock(&(lockq->mutexl));
    void *elementp = qget(lockq->qp);
    pthread_mutex_unlock(&(lockq->mutexl));
    return elementp;
}

public void LockQApply(void *qp, void (*fn)(void* elementp)) {
    lockNode *lockq = (lockNode *)qp;
    pthread_mutex_lock(&(lockq->mutexl));
    qapply(lockq->qp, fn);
    pthread_mutex_unlock(&(lockq->mutexl));
}

public void LockQApplyValue(void *qp, void (*fn)(void* elementp, void* key), void* skey){
    lockNode *lockq = (lockNode *)qp;
    pthread_mutex_lock(&(lockq->mutexl));
    qapplyValue(lockq->qp, fn, skey);
    pthread_mutex_unlock(&(lockq->mutexl));
}

public void* LockQSearch(void *qp,
                         int (*searchfn)(void* elementp,void* keyp),
                         void* skeyp) {
    lockNode *lockq = (lockNode *)qp;
    pthread_mutex_lock(&(lockq->mutexl));
    void *searchp = qsearch(lockq->qp, searchfn, skeyp);
    pthread_mutex_unlock(&(lockq->mutexl));
    return searchp;
}

public void* LockQRemove(void *qp,
                         int (*searchfn)(void* elementp,void* keyp),
                         void* skeyp) {
    lockNode *lockq = (lockNode *)qp;
    pthread_mutex_lock(&(lockq->mutexl));
    void* returnValue = qremove(lockq->qp, searchfn, skeyp);
    pthread_mutex_unlock(&(lockq->mutexl));
    return returnValue;
}

public void LockQClose(void *qp) {
    lockNode *lockq = (lockNode *)qp;
    pthread_mutex_lock(&(lockq->mutexl));
    qclose(lockq->qp);
    pthread_mutex_unlock(&(lockq->mutexl));
}
