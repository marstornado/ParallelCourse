#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mpi.h"
#include "unistd.h"
#include <math.h>
#include <pthread.h>
#include "integrate.h"
#include "queue.h"
#include "lockQueue.h"
#include "manager_worker.h"

#define TRUE 1;
#define FALSE 0;
typedef struct gener_type {
    int size;
    void *qBegin;
    int *flag;
}gener_t;

//void* generator(void *key1, void *qBeigin, int *flag);
void* generator(void *gener);
void* worker(void* key2, int *count, int *countp);
void load_balance(void* (*generator)(void* key1), void* (*worker)(void* key2, int *count, int *countp), int *skey);
int* init_board(int size);
int* update_board(int row, int col, int* boardinfor);
void place_queen(int row,int col, void *board, void *qBegin,int *count, int *countp);
void print_board(void *boardinfor);

int main(int argc, char *argv[])
{
    //int size=14;
    int size;
    size = atoi(argv[argc-1]);
    load_balance(generator, worker, &size);
    return 0;
}
void load_balance(void* (*generator)(void* key1), void* (*worker)(void *key2, int *count, int *countp), int *skey) {
    int num, pid, printer;
    int size = *skey;
    MPI_Init(NULL,NULL);
    MPI_Comm_rank(MPI_COMM_WORLD, &pid);
    MPI_Comm_size(MPI_COMM_WORLD, &num);
    printer = num-1;


    //process 1
    if(pid ==0) {
        char buf[5];
        int from, i = 0;
        int flag = 1;
        void *qBegin;
        void *qelem;
        pthread_t thread1;

        qBegin = LockQOpen();
        gener_t *para;
        para = (gener_t *)malloc(sizeof(gener_t));
        para->size = *skey;
        para->flag = &flag;
        para->qBegin = qBegin;
        //generator((void *)para);
        pthread_create(&thread1, NULL, generator, (void *)para);
        //printf("flag is %d\n",flag);


        do {
            msgRecv(from, buf, sizeof(buf));
            qelem = LockQGet(qBegin);
            //printf("get num %d \n", *((int *)qelem));
            if(qelem !=NULL || flag !=0) {
                if(qelem != NULL) {
                    strcpy(buf, "go");
                    msgGo(from, buf);
                    MPI_Send(qelem, 2+7*size, MPI_INT, from, MSGTAG, ALL);
                    //printf("send num %d \n", sizeof(qelem));
                }
                else {
                    printf("wait\n");
                    strcpy(buf, "wait");
                    msgGo(from, buf);
                }
            }
            else {
                strcpy(buf, "done");
                msgGo(from, buf);
                i++;
                //printf("from is %d i is %d\n",from, i);
            }
        } while(i < num-2);

        //printf("finish pid num %d\n", pid);
        pthread_join(thread1, NULL);
    }
    else if (pid == printer) {
        int i, from, count[num-2],coutmp, coutptmp, total=0, totalp=0;
        int counts[2];
        for (i=0; i<num-2; i++) {
            count[i] = 0;
        }
        for (i=0; i<num-2; i++) {
            dataRecv(from, &counts, 2);
            //dataRecv(from, &coutptmp, 1);
            count[from-1] = counts[1];
            total += counts[0];
            totalp += counts[1];
        }
        for (i=0; i<num-2; i++) {
            printf("process id %d calculate  %d place_queen\n",from, count[i]);
        }
        printf("finish \n");
        printf("total is %d, totalp is %d \n", total, totalp);
    }
    //worker process
    else {
        //printf("pid is %d\n", pid);

        char buf[5];
        int from, flag = 1;
        void *qelem;
        int size_count=0;
        MPI_Status status;
        int count = 0;
        int countp = 0;
        int counts[2];
        //printf("worker go");
        strcpy(buf, "go");
        msgGo(0, buf);

        do {
            //printf("pid %d send %s", pid, buf);
            msgWait(from,buf);
            if(!strcmp(buf, "wait")) {
                printf("wait \n");
                msgGo(0, buf);
            }
            else if(!strcmp(buf, "go")) {
                MPI_Probe(0,MSGTAG,ALL,&status);
                MPI_Get_count(&status,MPI_INT,&size_count);
                //printf("receive size %d\n", size_count);
                qelem = (int *)malloc(size_count*sizeof(int));
                MPI_Recv(qelem,size_count,MPI_INT,0,MSGTAG,ALL,&status);
                msgGo(0, buf);
                //worker
                worker(qelem, &count, &countp);
                free(qelem);

            }
            else if (!strcmp(buf, "done")){
                flag = 0;
                //printf("finish pid is %d\n", pid);
                printf("count is %d, countp is %d\n", count, countp);
                counts[0] = count;
                counts[1] = countp;
                dataSend(num-1, &counts, 2);
               // dataSend(num-1, &countp, 1);

            }
        } while (flag);

    }
    MPI_Finalize();
}

/*
 void* generator(void *key1, void *qBegin, int* flag) {
 int size = *(int *)key1;
 int *board;
 int count=0;

 board = init_board(size);
 place_queen(0, 0, board, qBegin, &count);
 *flag = 0;
 printf("finish generate %d.\n", count);
 return NULL;
 }
 */
void* generator(void *gener) {
    gener_t *para = (gener_t *)gener;
    int size = para->size;
    int *board;
    int count=0;
    int countp=0;

    board = init_board(size);
    place_queen(0, 0, board, para->qBegin, &count, &countp);
    *(para->flag) = 0;
    printf("finish generate %d.\n", count);
    pthread_exit(NULL);
    return NULL;
}

void* worker(void* key2, int *count, int *countp) {
    int *board = (int *)key2;
    int depth = board[1];
    //printf("depth num is %d\n", depth);
    place_queen(depth, 0, board, NULL, count, countp);
    //printf("worker num is %d\n", *count);
    return NULL;
}

int* init_board(int size) {
    int *board, i;
    board = (int *)malloc(sizeof(int)*(2+size*2+size*5));
    board[0] = size;
    board[1] = 0;
    for(i=2; i<(2+size*7); i++) {
        board[i] = 0;
    }
    return board;
}

int* update_board(int row, int col, int* boardinfor) {
    int i, size = boardinfor[0];
    int depth = boardinfor[1];
    int *boardinfor2 = (int *)malloc(sizeof(int)*(2+size*2+size*5));
    for(i=0; i<2+size*7; i++ ) {
        boardinfor2[i] = boardinfor[i];
    }
    boardinfor2[2+depth] = row;
    boardinfor2[2+depth+size] = col;
    boardinfor2[2+size*2+col] = TRUE;
    boardinfor2[2+size*3+col-row+size] = TRUE;
    boardinfor2[2+size*5+col+row] = TRUE;
    boardinfor2[1] += 1;
    return boardinfor2;
}

int legal_move(int row,int col, void *board) {
    int* boarddata = (int *)board;
    int size = boarddata[0];
    if(boarddata[2+size*2+col]) {
        return FALSE;
    }
    if(boarddata[2+size*3+col-row+size]) {
        return FALSE;
    }
    if(boarddata[2+size*5+row+col]) {
        return FALSE;
    }
    else {
        return TRUE;
    }
}
void place_queen(int row,int col, void *board, void *qBegin, int *count, int *countp) {
    int *boarddata = (int *)board;
    int size = boarddata[0];
    int part_size = 3;
    if(qBegin == NULL) {
        if(row < size && col < size) {
            if(legal_move(row, col, (void *)boarddata)) {
                int *boardinfor2;
                boardinfor2 = update_board(row, col, boarddata);
                if(boardinfor2[1] == size) {
                    //print_board(boardinfor2);
                    //printf("\nlast q is %d %d \n", boardinfor2[2+size-1], boardinfor2[2+2*size-1]);
                    (*count)++;
                    //printf("finish\n");
                }
                else {
                    place_queen(row+1, 0, (void *)boardinfor2, qBegin, count, countp);
                    (*countp)++;
                }
            }
            place_queen(row,col+1,(void*)boarddata, qBegin, count, countp);
            (*countp)++;
        }
        /*
         else {
         free(board);
         }
         */
    }
    else if(qBegin != NULL) {
        if(row < part_size && col < size) {
            if(legal_move(row, col, (void *)boarddata)) {
                int *boardinfor2;
                boardinfor2 = update_board(row, col, boarddata);
                if(boardinfor2[1] == part_size) {
                    //print_board(boardinfor2);
                    (*count)++;
                    LockQPut(qBegin, boardinfor2);
                }
                else {
                    place_queen(row+1, 0, (void *)boardinfor2, qBegin, count, countp);
                    (*countp)++;
                }
            }
            place_queen(row,col+1,(void*)boarddata, qBegin, count, countp);
            (*countp)++;
        }
        /*
         else {
         free(board);
         }
         */
    }
}


void print_board(void *boardinfor) {

    int i,j;
    int *boarddata = (int *)boardinfor;
    int size = boarddata[0];
    //printf("\nsize q is %d %d \n", boarddata[0], boarddata[1]);
    int *board = (int *)malloc(sizeof(int)*size*size);

    for(i=0; i<size; i++) {
        for (j=0; j<size; j++) {
            board[i*size + j] = 0;
        }
    }

    for(i=0; i<size; i++) {
        int m = boarddata[2+i];
        int n = boarddata[2+i+size];
        board[m*size +n] = 1;
        //printf("m n %d %d \n", m, n);
    }

    for(i=0; i<size; i++) {
        for (j=0; j<size; j++) {
            if(board[i*size+j]) {
                printf("q");
            }
            else {
                printf("-");
            }
        }
        printf("\n");
    }
    printf("\n");

}
