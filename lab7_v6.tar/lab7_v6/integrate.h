#define public
/*
 * integrate: returns the result of approximating the integral of f(x) over
 * the interval [a, b] to a stated level of precision and the number of strips
 * used in the computation.
 */


public void integrate(double (*f)(double x),double a, double b, double precision, double *result, double *strips);

