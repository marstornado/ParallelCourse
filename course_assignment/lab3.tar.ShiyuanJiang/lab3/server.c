#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "./queue.h"

typedef struct user_node {
  char ID[20];
  int isInChatRoom;
  struct sockaddr_in addr;
} userNode;

int sockfd, n;
struct sockaddr_in serverAddr, clientAddr;
socklen_t clientLen;
char tmpMessage[500];
char sendLine[500];
char tmpID[20];
void *userQueue;

int IDMatch(void *in, void *inID) {
  return strcmp(((userNode *) in)->ID, (char *)inID) == 0;
}

void inChatRoomNode(void *in) {
  if (((userNode *) in)->isInChatRoom)
    sprintf(sendLine, "%s %s", sendLine, ((userNode *) in)->ID);
}

void broadcastMessageToNode(void *in) {
  userNode *userP = (userNode *) in;
  if (userP->isInChatRoom == 1 && strcmp(userP->ID, tmpID) != 0) {
    sendto(sockfd, sendLine, strlen(sendLine), 0, (struct sockaddr *)&userP->addr, sizeof(userP->addr));
  }
}


void doCommands(char message[]) {  
  userNode *newUser, *currUser;
  sscanf(message, "%s %s", tmpMessage, tmpID);

  if (strcmp(tmpMessage, "/connect") == 0) {
    if (qsearch(userQueue, &IDMatch, (void *)tmpID) != NULL) {
      sprintf(sendLine, "/0");
      sendto(sockfd, sendLine, strlen(sendLine), 0, (struct sockaddr *)&clientAddr, sizeof(clientAddr));
    }
    else {
      newUser = (userNode *) malloc(sizeof(userNode));
      strcpy(newUser->ID, tmpID);
      newUser->isInChatRoom = 0;
      newUser->addr = clientAddr;
      qput(userQueue, (void *)newUser);
      sprintf(sendLine, "Connection established successfully.\n");
      sendto(sockfd, sendLine, strlen(sendLine), 0, (struct sockaddr *)&clientAddr, sizeof(clientAddr));
    }
  }
  else if (strcmp(tmpMessage, "/ping") == 0) {
    sprintf(sendLine, "The server is up.");
    sendto(sockfd, sendLine, strlen(sendLine), 0, (struct sockaddr *)&clientAddr, sizeof(clientAddr));
  }
  else if (strcmp(tmpMessage, "/join") == 0) {
    currUser = qsearch(userQueue, &IDMatch, (void *)tmpID);
    if ( currUser != NULL && strcmp(currUser->ID, tmpID) == 0 && currUser->isInChatRoom == 1) {
      sprintf(sendLine, "You are already in the chat room.");
      sendto(sockfd, sendLine, strlen(sendLine), 0, (struct sockaddr *)&clientAddr, sizeof(clientAddr));
    }
    else {
      currUser->isInChatRoom = 1;
      sprintf(sendLine, "You have joined the chat room.");
      sendto(sockfd, sendLine, strlen(sendLine), 0, (struct sockaddr *)&clientAddr, sizeof(clientAddr));
    }
  }
  else if (strcmp(tmpMessage, "/leave") == 0) {
    currUser = qsearch(userQueue, &IDMatch, (void *)tmpID);
    if ( currUser != NULL && strcmp(currUser->ID, tmpID) == 0 && currUser->isInChatRoom == 1) {
      currUser->isInChatRoom = 0;
      sprintf(sendLine, "You have left the chat room.");
      sendto(sockfd, sendLine, strlen(sendLine), 0, (struct sockaddr *)&clientAddr, sizeof(clientAddr));
    }
    else {
      sprintf(sendLine, "You are not in the chat room.");
      sendto(sockfd, sendLine, strlen(sendLine), 0, (struct sockaddr *)&clientAddr, sizeof(clientAddr));
    }
  }
  else if (strcmp(tmpMessage, "/who") == 0) {
    strcpy(sendLine, "The list of users in the chat room is:");
    qapply(userQueue, &inChatRoomNode);
    sendto(sockfd, sendLine, strlen(sendLine), 0, (struct sockaddr *)&clientAddr, sizeof(clientAddr));
  }
  else {
    sprintf(sendLine, "Not supported command.");
    sendto(sockfd, sendLine, strlen(sendLine), 0, (struct sockaddr *)&clientAddr, sizeof(clientAddr));
  }
}

void broadcastMessage(char message[]){
  userNode *userP;
  char *enterCharP;

  enterCharP = strchr(message, '\n');
  strncpy(tmpMessage, message, enterCharP - message + 1);
  *(tmpMessage + (enterCharP - message)) = '\0';
  strncpy(tmpID, enterCharP + 1, strlen(message)-(enterCharP - message));
  *(tmpID + (strlen(message) - (enterCharP - message))) = '\0';
  sprintf(sendLine, "%s: %s", tmpID, tmpMessage);
  userP = qsearch(userQueue, &IDMatch, tmpID);
  if (userP->isInChatRoom)
    qapply(userQueue, &broadcastMessageToNode);
}

int main(int argc, char *argv[]) {

  char message[500];

  userQueue = qopen();

  if (argc <= 1) {
    printf("Please input the port number in the argument of the program.\n");
    exit(1);
  }

  sockfd = socket(AF_INET, SOCK_DGRAM, 0);

  memset((char *) &serverAddr, 0, sizeof(serverAddr));
  serverAddr.sin_family = AF_INET;
  serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
  serverAddr.sin_port = htons(atoi(argv[1]));
  bind(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr));

  clientLen = sizeof(clientAddr);
  while (1) {
    n = recvfrom(sockfd, message, 500, 0, (struct sockaddr *)&clientAddr, &clientLen);
    message[n] = 0;

    if (message[0] == '/' && n > 0) {
      doCommands(message);
    }
    else {
      broadcastMessage(message);
    }
  }

  return 0;
}
