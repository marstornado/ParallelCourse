#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <pthread.h>
#include <unistd.h>

int sockfd, n, timeoutFlag = 0;
struct sockaddr_in serverAddr;
char sendLine[500];
char recvLine[500];
char userName[50];
struct timeval timeoutLimited = {3, 0}, timeoutUnlimited = {10000000, 0};
pthread_t readThread, writeThread;

void* readFromSocket() {
  while (1) {
    n = recvfrom(sockfd, recvLine, 500, 0, NULL, NULL);
    recvLine[n] = 0;
    if (strcmp(recvLine, "The server is up.") == 0) 
      timeoutFlag = 0;
    if (n >= 0) 
      printf("%s\n", recvLine);
  }
}

void* writeToSocket() {
  while (1) {
    gets(sendLine);
    if (strcmp(sendLine, "/ping") == 0) {
      timeoutFlag = 1;
    }
    sprintf(sendLine, "%s\n%s", sendLine, userName);
    sendto(sockfd, sendLine, strlen(sendLine), 0, (struct sockaddr *)&serverAddr, sizeof(serverAddr));
    if (timeoutFlag)
      sleep(1);
    if (timeoutFlag) {
      printf("The server is down. The program will quit.\n");
      exit(1);
    }
  }
}

int main(int argc, char *argv[]) {

  if (argc < 4) {
    printf("Please input your ID, the IP address and the port number of the server you want to connect to in the argument of the program.\n");
    exit(1);
  }

  strcpy(userName, argv[1]);
  sockfd = socket(AF_INET, SOCK_DGRAM, 0);

  memset((char *) &serverAddr, 0, sizeof(serverAddr));
  serverAddr.sin_family = AF_INET;
  serverAddr.sin_addr.s_addr = inet_addr(argv[2]);
  serverAddr.sin_port = htons(atoi(argv[3]));

  sprintf(sendLine, "/connect %s", argv[1]);
  sendto(sockfd, sendLine, strlen(sendLine), 0, (struct sockaddr *)&serverAddr, sizeof(serverAddr));
  n = recvfrom(sockfd, recvLine, 500, 0, NULL, NULL);
  recvLine[n] = 0;
  if (strcmp(recvLine, "/0") == 0) {
    printf("ID %s is already used. Please change your ID and try again.\n", argv[1]);
    exit(1);
  }
  else {
    printf("%s", recvLine);
  }

  pthread_create(&readThread, NULL, readFromSocket, NULL);
  pthread_create(&writeThread, NULL, writeToSocket, NULL);
  pthread_join(readThread, NULL);
  pthread_join(writeThread, NULL);

  return 0;
}
