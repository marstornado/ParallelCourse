
int legal_move(int n, int column_board[], int diag1[], int diag2[], int row, int column);

void initial_board(int n, int *column_board, int *diag1, int *diag2, int initial_flag, int *column_board_in, int *diag1_in, int *diag2_in);

int on_board(int row, int column, int n);
