#include "./MPI_module_datastructures.h"

void ManagerWorker(int argc, char *argv[], manager_data *manager_data_in, worker_data *worker_data_in, printer_data *printer_data_in);
