#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "./MPI_module_datastructures.h"
#include "./nqueens_datastructures.h"
#include "./nqueens_shared_functions.h"

int n;
int processes_size;
long total_num_solutions = 0;
long total_queen_placements = 0;
long *total_queen_placements_for_each_process;

int *column_board, *diag1, *diag2;
task_info *curr_entry;
void *lq_head;

void place_queen_manager(int row, int column) {

  if (row >= 2) {
    int i;
    curr_entry = (task_info *) malloc(sizeof(task_info));
    curr_entry->n = n;
    curr_entry->curr_row = row;
    curr_entry->curr_column = column;
    for (i = 0; i < n; i++) {
      curr_entry->column_board[i] = column_board[i];
    }
    for (i = 0; i < 2 * n; i++) {
      curr_entry->diag1[i] = diag1[i];
      curr_entry->diag2[i] = diag2[i];
    }
    
    lqput(lq_head, curr_entry);
    return;
  }

  if (on_board(row, column, n)) {
    if (legal_move(n, column_board, diag1, diag2, row, column)) {
      column_board[column] = row;
      diag1[row + column] = 1;
      diag2[row - column + n] = 1;
      place_queen_manager(row + 1, 0);
      column_board[column] = -1;
      diag1[row + column] = -1;
      diag2[row - column + n] = -1;
    }

    place_queen_manager(row, column + 1);
  }
}

void* generate_partitions(void *in) {

  argu *argument;

  argument = (argu *) in;
  n = atoi(argument->argv[1]);
  printf("generate_patition n: %d\n", n);
  lq_head = argument->lq_head;
  processes_size = argument->size;

  total_queen_placements_for_each_process = (long *) malloc(processes_size * sizeof(long));

  column_board = (int *) malloc(n * sizeof(int));
  diag1 = (int *) malloc(2 * n * sizeof(int));
  diag2 = (int *) malloc(2 * n * sizeof(int));

  initial_board(n, column_board, diag1, diag2, 1, column_board, diag1, diag2);
  place_queen_manager(0, 0);

  *(argument->generation_done) = 1;
  printf("Manager finishes generating partitions.\n");
  pthread_exit(NULL);
}

void update_result(long num_solutions, long load, int idx) {
  total_num_solutions += num_solutions;
  total_queen_placements += load;
  *(total_queen_placements_for_each_process + idx) += load;
}

void print_out_result() {

  long min = LONG_MAX, max = 0, aver = 0;
  int i;

  for (i = 2; i < processes_size; i++) {
    if (min > total_queen_placements_for_each_process[i]) {
      min = total_queen_placements_for_each_process[i];
    }
    if (max < total_queen_placements_for_each_process[i]) {
      max = total_queen_placements_for_each_process[i];
    }
    aver += total_queen_placements_for_each_process[i];
  }

  aver /= (processes_size - 2);

  printf("The total number of solutions for %d queens problem is: %ld.\nThe total number of queen placements is %ld.\n", n, total_num_solutions, total_queen_placements);
  printf("For individual process:\nMax number of queen placements is %ld\nMin number of queen placements is %ld\nAverage number of queen placements is %ld\n",
	  max, min, aver);

}
