
void* generate_partitions(void *in); 

void update_result(long num_solutions, long load, int idx);

void print_out_result();
