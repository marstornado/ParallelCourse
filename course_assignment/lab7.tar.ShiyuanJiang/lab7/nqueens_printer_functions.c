#include <stdio.h>
#include "./nqueens_datastructures.h"

void print_queens(void *in) {

  task_info *print_info;
  int i, j, n;

  print_info = (task_info *) in;
  n = print_info->n;

  for (i = 0; i < n; i++) {
    for (j = 0; j < n; j++) {
      if (print_info->column_board[j] == i)
        printf("Q");
      else
        printf("-");
    }
    printf("\n");
  }
  printf("\n");
}
