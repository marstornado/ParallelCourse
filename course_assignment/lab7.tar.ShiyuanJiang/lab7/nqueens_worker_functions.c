#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include "./nqueens_datastructures.h"
#include "./nqueens_shared_functions.h"

worker_info *worker_information;
long num_solutions;
long queen_placements;
int n;
int *column_board, *diag1, *diag2;

void print_result() {
  int i,j;

  for (i = 0; i < n; i++) {
    for (j = 0; j < n; j++) {
      if (column_board[j] == i)
        printf("Q");
      else
        printf("-");
    }
    printf("\n");
  }
  printf("\n");
}

void place_queen(int row, int column) {

  if (row >= n) {
    task_info print_info;
    int i, j, tag = 1;
    for (i = 0; i < n; i++) 
      print_info.column_board[i] = column_board[i];
    print_info.isDone = 0;
    print_info.n = n;
    MPI_Send(&print_info, sizeof(task_info), MPI_BYTE, 1, tag, MPI_COMM_WORLD);
    /*print_result();*/
    num_solutions++;
    return;
  }

  queen_placements++;

  if (on_board(row, column, n)) {
    if (legal_move(n, column_board, diag1, diag2, row, column)) {
      column_board[column] = row;
      diag1[row + column] = 1;
      diag2[row - column + n] = 1;
      place_queen(row + 1, 0);
      column_board[column] = -1;
      diag1[row + column] = -1;
      diag2[row - column + n] = -1;
    }

    place_queen(row, column + 1);
  }
}

void solve_queen() {

  place_queen(worker_information->task.curr_row, worker_information->task.curr_column);

}

void solve(void *in) {

  int i;
  worker_information = (worker_info *) in;

  /*printf("worker: n %d\ncurr_row: %d, curr_column: %d\n", worker_information->task.n, worker_information->task.curr_row, worker_information->task. curr_column);
  printf("column: ");
  for (i = 0; i < n; i++) {
    printf("%d ",worker_information->task.column_board[i]);
  }
  printf("\n");
  printf("diag1: ");
  for (i = 0; i < n; i++) {
    printf("%d ",worker_information->task.diag1[i]);
  }
  printf("\n");
  printf("diag2: ");
  for (i = 0; i < n; i++) {
    printf("%d ",worker_information->task.diag2[i]);
  }
  printf("\n");*/
  n = worker_information->task.n;

  column_board = (int *) malloc(n * sizeof(int));
  diag1 = (int *) malloc(2 * n * sizeof(int));
  diag2 = (int *) malloc(2 * n * sizeof(int));

  num_solutions = 0;
  queen_placements = 0;

  initial_board(n, column_board, diag1, diag2, 0, worker_information->task.column_board, worker_information->task.diag1, worker_information->task.diag2);
  solve_queen();

  worker_information->result.num_solutions = num_solutions;
  worker_information->result.load = queen_placements;

  /*printf("Total number of solutions is: %ld.\nTotal number of queen placements is: %ld\n", num_solutions, queen_placements);*/
}
