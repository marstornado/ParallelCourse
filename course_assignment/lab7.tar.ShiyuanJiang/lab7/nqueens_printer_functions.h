
void print_queens(void *in);
