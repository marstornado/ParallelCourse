
typedef struct Manager_Data {
  void* (*partition_function)(void *in);
  void (*result_update_function)(long num_solutions, long load, int idx);
  void (*print_function)();
} manager_data;

typedef struct Worker_Data {
  void (*solve_function)(void *in);
} worker_data;

typedef struct Printer_Data {
  void (*print_function)(void *in);
} printer_data;

typedef struct argument {
  int rank;
  int size;
  int argc;
  void *lq_head;
  char **argv;
  int *generation_done;
} argu; 
