#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "./MPI_module_datastructures.h"
#include "./nqueens_datastructures.h"
#include "./lqueue.h"

#define REQUEST_WORK 0
#define SUBMIT_RESULT 1

void manager(int rank, int size, int argc, char *argv[], manager_data *my_manager) {
  pthread_t p_thread;
  MPI_Status status;
  int tag = 1, i, worker_num = size - 2;
  task_info sendInfo;
  task_info *current_p;
  result_info recvInfo;
  void *lq_head; 
  int workers_done = 0;
  int queue_generation_complete = 0;
  argu *argument;
  
  lq_head = lqopen();
  argument = (argu *) malloc(sizeof(argu));
  argument->rank = rank;
  argument->size = size;
  argument->argc = argc;
  argument->argv = argv;
  argument->lq_head = lq_head;
  argument->generation_done = &queue_generation_complete;
  pthread_create(&p_thread, NULL, my_manager->partition_function, (void *)argument);
  
  while (!(workers_done == worker_num && queue_generation_complete)) {
    MPI_Recv(&recvInfo, sizeof(result_info), MPI_BYTE, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
    if (recvInfo.category == REQUEST_WORK) {
      if (!lqempty(lq_head)) {
        current_p = lqget(lq_head);
        sendInfo.isDone = 0;
        sendInfo.n = current_p->n;
        sendInfo.curr_row = current_p->curr_row;
        sendInfo.curr_column = current_p->curr_column;
        for (i = 0; i < current_p->n; i++) {
          sendInfo.column_board[i] = current_p->column_board[i];
        }
        for (i = 0; i < 2 * current_p->n; i++) {
          sendInfo.diag1[i] = current_p->diag1[i];
          sendInfo.diag2[i] = current_p->diag2[i];
        }   
        MPI_Send(&sendInfo, sizeof(task_info), MPI_BYTE, status.MPI_SOURCE, tag, MPI_COMM_WORLD);
      }
      else {
        if (queue_generation_complete) {
          sendInfo.isDone = 1;        
          MPI_Send(&sendInfo, sizeof(task_info), MPI_BYTE, status.MPI_SOURCE, tag, MPI_COMM_WORLD);
          workers_done++;
        }
        else {
          sendInfo.isDone = 2;        
          MPI_Send(&sendInfo, sizeof(task_info), MPI_BYTE, status.MPI_SOURCE, tag, MPI_COMM_WORLD);
        }
      }
    }
    else if (recvInfo.category == SUBMIT_RESULT) {
      (*my_manager->result_update_function)(recvInfo.num_solutions, recvInfo.load, status.MPI_SOURCE);
    }
  }

  sendInfo.isDone = 1;
  MPI_Send(&sendInfo, sizeof(task_info), MPI_BYTE, 1, tag, MPI_COMM_WORLD);
  printf("Manager is done.\n");
}

void worker(int rank, int size, worker_data *my_worker) {
  int tag = 1;
  int isDone = 0;
  worker_info worker_infomation;

  while (!isDone) {
    worker_infomation.result.category = REQUEST_WORK;
    MPI_Send(&worker_infomation.result, sizeof(result_info), MPI_BYTE, 0, tag, MPI_COMM_WORLD);
    MPI_Recv(&worker_infomation.task, sizeof(task_info), MPI_BYTE, 0, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
 
    if (worker_infomation.task.isDone == 0) {
      worker_infomation.result.category = SUBMIT_RESULT;
      (*my_worker->solve_function)(&worker_infomation);
      /*solvePartitions(recvInfo, &sendInfo);*/
      /*printf("Over the interval [%f %f],\n", recvInfo.interval_a, recvInfo.interval_b);
      printf("The total value of the integration is: %f. The total strips used is: %f\n", sendInfo.value, sendInfo.strips);*/
      MPI_Send(&worker_infomation.result, sizeof(result_info), MPI_BYTE, 0, tag, MPI_COMM_WORLD);
    }
    else if (worker_infomation.task.isDone == 1) {
      printf("Worker %d is done.\n", rank);
      isDone = 1;
    }
  }
 
}

void printer(printer_data *printer_data_in) {
  task_info print_info;
  int isDone = 0;
  int tag = 1;

  while (!isDone) {
    MPI_Recv(&print_info, sizeof(task_info), MPI_BYTE, MPI_ANY_SOURCE, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    if (!print_info.isDone)
      (*printer_data_in->print_function)(&print_info);
    else
      isDone = 1;
  }

  printf("Printer is done.\n");
}

void ManagerWorker(int argc, char *argv[], manager_data *manager_data_in, worker_data *worker_data_in, printer_data *printer_data_in) {

  int rank, size;
  double start_time, end_time;

  MPI_Init( &argc, &argv );
  start_time = MPI_Wtime();
  MPI_Comm_rank( MPI_COMM_WORLD, &rank );
  MPI_Comm_size( MPI_COMM_WORLD, &size );

  if (rank == 0) {
    manager(rank, size, argc, argv, manager_data_in);
  }
  else if (rank == 1){
    printer(printer_data_in);
  }
  else {
    worker(rank, size, worker_data_in);
  }

  end_time = MPI_Wtime();
  printf("Time used in rank %d process is: %f\n", rank, end_time - start_time);

  MPI_Finalize();

  if (rank == 0) {
    (*manager_data_in->print_function)();
  }

}
