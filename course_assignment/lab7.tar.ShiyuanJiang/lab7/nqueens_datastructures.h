
typedef struct TASK_INFO {
  int isDone;
  int n;
  int column_board[30];
  int diag1[60];
  int diag2[60];
  int curr_row;
  int curr_column;
} task_info;

typedef struct RESULT_INFO {
  int category;
  long num_solutions;
  long load;
} result_info;

typedef struct WORKER_INFO {
  task_info task;
  result_info result;
} worker_info;
