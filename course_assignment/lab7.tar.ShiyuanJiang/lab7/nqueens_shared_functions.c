
int legal_move(int n, int column_board[], int diag1[], int diag2[], int row, int column) {
  if (column_board[column] != -1 || diag1[row + column] == 1 || diag2[row - column + n] == 1)
    return 0;
  return 1;
}

void initial_board(int n, int *column_board, int *diag1, int *diag2, int initial_flag, int *column_board_in, int *diag1_in, int *diag2_in) {
  int i;

  if (initial_flag == 1) {
    for (i = 0; i < n; i++) {
      column_board[i] = -1;
    }

    for (i = 0; i < 2 * n; i++) {
      diag1[i] = -1;
      diag2[i] = -1;
    }
  }
  else {
    for (i = 0; i < n; i++) {
      column_board[i] = column_board_in[i];
    }

    for (i = 0; i < 2 * n; i++) {
      diag1[i] = diag1_in[i];
      diag2[i] = diag2_in[i];
    }
  }
}

int on_board(int row, int column, int n) {
  return row >= 0 && row < n && column >= 0 && column < n;
}
