#include <stdio.h>
#include <stdlib.h>

int num_solutions;
int n;
int *column_board, *diag1, *diag2;

int legal_move(int row, int column) {
  if (column_board[column] != -1 || diag1[row + column] == 1 || diag2[row - column + n] == 1)
    return 0;
  return 1;
}

void print_result() {
  int i,j;

  for (i = 0; i < n; i++) {
    for (j = 0; j < n; j++) {
      if (column_board[j] == i)
        printf("Q");
      else
        printf("-");
    }
    printf("\n");
  }
  printf("\n");
}

void initial_board() {
  int i;
  for (i = 0; i < n; i++) {
    column_board[i] = -1;
  }

  for (i = 0; i < 2 * n; i++) {
    diag1[i] = -1;
    diag2[i] = -1;
  }
}

int on_board(int row, int column) {
  return row >= 0 && row < n && column >= 0 && column < n;
}

void place_queen(int row, int column) {

  if (row >= n) {
    print_result();
    num_solutions++;
    return;
  }

  if (on_board(row, column)) {
    if (legal_move(row, column)) {
      column_board[column] = row;
      diag1[row + column] = 1;
      diag2[row - column + n] = 1;
      place_queen(row + 1, 0);
      column_board[column] = -1;
      diag1[row + column] = -1;
      diag2[row - column + n] = -1;
    }

    place_queen(row, column + 1);
  }
}

void solve_queen() {

  int init_row = 0, init_column = 0;

  column_board = (int *) malloc(n * sizeof(int));
  diag1 = (int *) malloc(2 * n * sizeof(int));
  diag2 = (int *) malloc(2 * n * sizeof(int));

  initial_board();

  place_queen(init_row, init_column);

}

int main(int argc, char *argv[]) {

  if (argc < 2) {
    printf("Not enough input arguments. Please try again.\n");
    exit(1);
  }

  num_solutions = 0;
  n = atoi(argv[1]);
  solve_queen();

  printf("Total number of solutions is: %d.\n", num_solutions);

  return 0;
}
