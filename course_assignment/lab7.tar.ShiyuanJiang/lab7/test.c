#include <stdio.h>
#include <stdlib.h>
#include "./manager_worker.h"
#include "./nqueens_manager_functions.h"
#include "./nqueens_worker_functions.h"
#include "./nqueens_printer_functions.h"

int main(int argc, char *argv[]) {

  if (argc < 2) {
    printf("Not enough input arguments. Please try again.\n");
    exit(1);
  }

  manager_data *my_manager;
  worker_data *my_worker;
  printer_data *my_printer;
  my_manager = (manager_data *) malloc(sizeof(manager_data));
  my_manager->partition_function = &generate_partitions;
  my_manager->result_update_function = &update_result;
  my_manager->print_function = &print_out_result;
  my_worker = (worker_data *) malloc(sizeof(worker_data));
  my_worker->solve_function = &solve;
  my_printer = (printer_data *) malloc(sizeof(printer_data));
  my_printer->print_function = &print_queens;

  ManagerWorker(argc, argv, my_manager, my_worker, my_printer);

  return 0;
}
