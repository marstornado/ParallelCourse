
void solve(void *in);
