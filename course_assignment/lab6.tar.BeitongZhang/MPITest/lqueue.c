#include <pthread.h>
#include <stdlib.h>
#include "lqueue.h"
#include "queue.h"

typedef struct LQUEUE{
    void *qp;
    pthread_mutex_t mutex;
}lqp;

void * lqopen(){
    lqp *lqBegin = malloc(sizeof(lqp));
    pthread_mutex_init(&(lqBegin->mutex), NULL);
    pthread_mutex_lock(&(lqBegin->mutex));
    lqBegin->qp = qopen();
    pthread_mutex_unlock(&(lqBegin->mutex));
    void *tmpt = (void *)lqBegin;
    return tmpt;
}

void lqclose(void * lqBegin){
    lqp *tmpt = (lqp *)lqBegin;
    pthread_mutex_lock(&(tmpt->mutex));
    qclose(tmpt->qp);
    pthread_mutex_unlock(&(tmpt->mutex));
    return;
}

void lqput(void *lqBegin, void * elementp)
{
    lqp *tmpt = (lqp *)lqBegin;
    pthread_mutex_lock(&(tmpt->mutex));
    qput(tmpt->qp, elementp);
    pthread_mutex_unlock(&(tmpt->mutex));
}

void * lqget(void * lqBegin) {
    lqp *tmpt = (lqp *)lqBegin;
    pthread_mutex_lock(&(tmpt->mutex));
    void *elementp = qget(tmpt->qp);
    pthread_mutex_unlock(&(tmpt->mutex));
    return elementp;
}

void *lqsearch(void *lqBegin, int (*search)(void* elementp,void* keyp), void * skeyp){
    lqp *tmpt = (lqp *)lqBegin;
    pthread_mutex_lock(&(tmpt->mutex));
    void *elementp = qsearch(tmpt->qp, search, skeyp);
    pthread_mutex_unlock(&(tmpt->mutex));
    return elementp;
}

void * lqremove(void *lqBegin, int (*search)(void* elementp,void* keyp), void * skeyp){
    lqp *tmpt = (lqp *)lqBegin;
    pthread_mutex_lock(&(tmpt->mutex));
    void *elementp = qremove(tmpt->qp, search, skeyp);
    pthread_mutex_unlock(&(tmpt->mutex));
    return elementp;
}

void lqapply(void *lqBegin, void (*fn)(void* elementp)) {
    lqp *tmpt = (lqp *)lqBegin;
    pthread_mutex_lock(&(tmpt->mutex));
    qapply(tmpt->qp, fn);
    pthread_mutex_unlock(&(tmpt->mutex));
}
void lqapply_arg(void*lqBegin, void (*fn)(void * elementp, void * arg),void * p1){
    lqp *tmpt = (lqp *)lqBegin;
    pthread_mutex_lock(&(tmpt->mutex));
    qapply_arg(tmpt->qp, fn, p1);
    pthread_mutex_unlock(&(tmpt->mutex));
}

