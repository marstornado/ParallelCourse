//
// integrate.c
// implementation of integrate.h
// F00227J Beitong Zhang
//
#include <math.h>
#include <stdio.h>
#include "integrate.h"

//calculate the area of single strip
public double stripArea(double (*f)(double x), double a, double b)
{
    return (f(a)+f(b))* (b-a)/2;
}

/*
 * integrate: returns the result of approximating the integral of f(x) over
 * the interval [a,b] to a stated level of precision and the number of strips
 * used in the computation.
 */
public void integrate(double (*f)(double x),
                      double a, double b, double precision,
                      double *result, double *strips)
{
    //initial the sum with the result of first iteration
    double preResult=stripArea(f, a, b);
    double diff=precision+100;
    double itrTimes=2;
    //loop until precision is enough
    while (diff>precision) {
        int i;
        double tempSum=0;
        double width=(b-a)/((double)itrTimes);
        //loop for all the strips
        for (i=0; i<itrTimes; i++)
            tempSum+= stripArea(f, a+width*i, a+width*(i+1));
        diff=fabs(fabs(tempSum)-fabs(preResult));
        //printf("%e %e\n",width,tempSum);
        preResult=tempSum;
        itrTimes=itrTimes+1;
    }
    *result=preResult;
    *strips=itrTimes-1;
}
