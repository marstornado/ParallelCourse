/*************************************************************************
	> File Name: simple.c
	> Author: Noelzhang
	> Mail: beitong.zhang.gr@dartmouth.edu
	> Created Time: Tue 04 Nov 2014 07:46:20 PM EST
 ************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include "mpi.h"
#include "mpi_func.h"
#include "MultThreadIntegrate.h"
#include "lqueue.h"

#define DataTAG 70
#define ResultTAG 71
#define ManagerPID 0

typedef struct initialqueue
{
    int processMark;
    int NumOfProcess;//Strips
    double a;//results
    double b;//wtime
    double precision;
    //double (*f)(double x);
}QueueArgs;

typedef struct status1
{
    void * queue;
    double itgrtResult;
    double stripAmount;
    int processLeft;
    int * processStrips;
}OverallStatus1;

OverallStatus1 overallStatus1;
//argv---begin,end,precise,balanceSize,threadNumPerProcess,threadBalance
//like---3,30,0.0001,15,10,5
int main(int argc, char * argv[]){
    int pid, numProc,threadNum,MultTime,BalanceSize;
    double begin, end, precise,startTime,finishTime;
    threadNum=atof(argv[5]);
    MultTime=atof(argv[6]);
    BalanceSize=atof(argv[4]);
    precise=atof(argv[3]);
    begin=atof(argv[1]);
    end=atof(argv[2]);
    msgInit(&argc,&argv,&numProc,&pid);
	startTime=MPI_Wtime();
    if (pid==ManagerPID){
		QueueArgs * recvBuf=malloc(sizeof(QueueArgs));
        overallStatus1.queue=lqopen();
        overallStatus1.itgrtResult=0.0;
        overallStatus1.stripAmount=0;
        overallStatus1.processLeft=numProc-1;
        overallStatus1.processStrips=malloc((numProc-1)*sizeof(int));
		int i,j,from,sourceTag,totalStrip=0,maxStrip=0,minStrip=999999;
		double result=0;
		for(i=0;i<numProc-1;i++){
			msgRecvTag(&from,recvBuf,sizeof(QueueArgs),&sourceTag);
            overallStatus1.stripAmount+=recvBuf->NumOfProcess;
            overallStatus1.itgrtResult+=recvBuf->a;
            overallStatus1.processStrips[from-1]=recvBuf->NumOfProcess;
			if(recvBuf->NumOfProcess>maxStrip)
				maxStrip=recvBuf->NumOfProcess;
			if(recvBuf->NumOfProcess<minStrip)
				minStrip=recvBuf->NumOfProcess;
            printf("process %d result %d %f\n",i+1,recvBuf->NumOfProcess,recvBuf->a);
		}
		printf("finished\nresult:%f\nstrips:%f\navgStrip:%f\nmaxStrip:%d\nminStrip%d\n",overallStatus1.itgrtResult,overallStatus1.stripAmount,(double)overallStatus1.stripAmount/(double)(numProc-1),maxStrip,minStrip);
		finishTime=MPI_Wtime();
		printf("Running time %f\n",finishTime-startTime);
    }
    else{
		double width=(end-begin)/(double)(numProc-1)/BalanceSize;
		double result;
		int strip;
		QueueArgs * buf=malloc(sizeof(QueueArgs));
		multThreadIntegrate(begin+(pid-1)*width,begin+pid*width,precise,threadNum,MultTime,&strip,&result);
		buf->NumOfProcess=strip;
		buf->a=result;
		msgSendTag(ManagerPID,buf,sizeof(QueueArgs),ResultTAG);
	}
    msgFinalize();
}
