//  main.c
//  Paralell_LAB2
//
//  Created by zhangNoel on 10/4/14.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "integrate.h"
#include "MultThreadIntegrate.h"
#include "lqueue.h"
#include <pthread.h>
#include <math.h>
//----------------interval functions-----------------
double function1(double x)
{
    return x+5;
}

double function2(double x)
{
    return x*sin(x*x); 
}
//-----------------argument structure-----------------
//struct for arguments of initIntervalQueue
typedef struct initialQueue
{
    int NumOfThread;
    double a;
    double b;
    double precision;
    double (*f)(double x);
}InitialQueue;

//struct for arguments of intervalThread! Element in the queue
typedef struct initialInterval
{
    double (*f)(double x);
    double a;
    double b;
    double precision;
}InitialInterval;
void freeArg(void * p){
    free(p);
}

//-----------------------------------------------------
//overall status
typedef struct status
{
    void * queue;
    double itgrtResult;
    double stripAmount;
}OverallStatus;

OverallStatus overallStatus;
int generateEndMark=0;
pthread_mutex_t mutexSum;
int MultTimes=10;

//thread to initial a queue of interval with queue.h
void* threadQueue(void* args)
{
    InitialQueue * queueArgs=args;
    //printf("thread %f,%f,%f,%d,%d\n",queueArgs->a,queueArgs->b,queueArgs->precision,queueArgs->NumOfThread,MultTimes);
    double width= (queueArgs->b-queueArgs->a)/(double)queueArgs->NumOfThread/(double)MultTimes;
    //overallStatus.queue =lqopen();
    int i = 0;
    for (i=1; i<=queueArgs->NumOfThread*MultTimes; i++) {
        InitialInterval * tempArgs = malloc(sizeof(InitialInterval));
        tempArgs->f= queueArgs->f;
        tempArgs->precision=queueArgs->precision;
        tempArgs->a=queueArgs->a+(double)(i-1)*width;
        tempArgs->b=queueArgs->a+(double)i*width;
        lqput(overallStatus.queue,tempArgs);
    }
    generateEndMark=1;
    pthread_exit(NULL);
}

//thread to interval
void* threadInterval()
{
    InitialInterval* intervalArgs=lqget(overallStatus.queue);
    while (intervalArgs!=NULL||generateEndMark==0) {
        if (intervalArgs!=NULL){
            double result,strips;
            integrate(((InitialInterval*)intervalArgs)->f,
                      ((InitialInterval*)intervalArgs)->a,
                      ((InitialInterval*)intervalArgs)->b,
                      ((InitialInterval*)intervalArgs)->precision, &result, &strips);
            pthread_mutex_lock(&mutexSum);
            overallStatus.stripAmount+=strips;
            overallStatus.itgrtResult+=result;
            pthread_mutex_unlock(&mutexSum);
            intervalArgs=lqget(overallStatus.queue);
        }
        else{
            intervalArgs=lqget(overallStatus.queue);
            continue;
        }
    }
    pthread_exit(NULL);
}

int multThreadIntegrate(double from,double to, double epsilon, int threadNum, int time,
                        int *strips,double * results) {
    overallStatus.itgrtResult=0;
    overallStatus.stripAmount=0;
    overallStatus.queue =lqopen();
    pthread_mutex_init(& mutexSum, NULL);
    void * status;
    int rc,i;
    MultTimes=time;
    int NUM_THREADS=threadNum;
    double PRECISIION=epsilon;
    
    
    InitialQueue QueueArgs;     //initial queue args
    QueueArgs.a =from;
    QueueArgs.b = to;
    QueueArgs.f=&function2;
    QueueArgs.NumOfThread=NUM_THREADS;
    QueueArgs.precision=PRECISIION;
    
    pthread_t threads[NUM_THREADS+1];//to store m+1 threads
    //initial the attribute
    pthread_attr_t thread_Attr;
    pthread_attr_init(&thread_Attr);
    pthread_attr_setdetachstate(&thread_Attr, PTHREAD_CREATE_JOINABLE);
    //create thread 0 to execute threadQueue()
    pthread_create(&threads[0], &thread_Attr, threadQueue, (void*)&QueueArgs);
    //wait thread 0 to join, wait the finishing of creating the argQueue
    pthread_join(threads[0], &status);
    //create threads to execute threadInterval()
    for(i=1; i<NUM_THREADS+1; i++){
        rc = pthread_create(&threads[i], &thread_Attr, threadInterval, NULL);
        if (rc){
            printf("ERROR! Return code from pthread_create() is %d\n", rc);
            return -1;
        }
    }
    //wait interval threads to join
    for(i=1; i<NUM_THREADS+1; i++)
    {
        rc = pthread_join(threads[i], &status);
        if (rc)
        {
            printf("ERROR; return code from pthread_join() is %d\n", rc);
            exit(-1);
        }
    }
    //printf("result:%f\nstrips:%f\n",overallStatus.itgrtResult,overallStatus.stripAmount);
    lqapply(overallStatus.queue, &freeArg);
    lqclose(overallStatus.queue);
    *strips=overallStatus.stripAmount;
    *results=overallStatus.itgrtResult;
    
    //pthread_exit(NULL);
    return 0;
}
