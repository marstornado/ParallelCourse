//  main.c
//  Paralell_LAB2
//
//  Created by zhangNoel on 10/4/14.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "integrate.h"
#include "queue.h"
#include <pthread.h>
//----------------interval functions-----------------
double function1(double x)
{
    return x+5;
}

double function2(double x)
{
    return 2*x*x+9*x+4;
}
//-----------------argument structure-----------------
//struct for arguments of initIntervalQueue
typedef struct initialQueue
{
    int NumOfThread;
    double a;
    double b;
    double precision;
    double (*f)(double x);
}InitialQueue;

//struct for arguments of intervalThread! Element in the queue
typedef struct initialInterval
{
    double (*f)(double x);
    double a;
    double b;
    double precision;
}InitialInterval;
void freeArg(void * p){
    free(p);
}

//-----------------------------------------------------
//overall status
typedef struct status
{
    void * queue;
    double itgrtResult;
    double stripAmount;
}OverallStatus;

OverallStatus overallStatus;
pthread_mutex_t mutexSum;

//thread to initial a queue of interval with queue.h
void* threadQueue(void* args)
{
    InitialQueue * queueArgs=args;
    double width= (queueArgs->b-queueArgs->a)/(double)queueArgs->NumOfThread/15.0;
    pthread_mutex_lock(&mutexSum);
    overallStatus.queue =qopen();
    int i = 0;
    for (i=1; i<=queueArgs->NumOfThread*15; i++) {
        InitialInterval * tempArgs = malloc(sizeof(InitialInterval));
        tempArgs->f= queueArgs->f;
        tempArgs->precision=queueArgs->precision;
        tempArgs->a=queueArgs->a+(double)(i-1)*width;
        tempArgs->b=queueArgs->a+(double)i*width;
        qput(overallStatus.queue,tempArgs);
    }
    pthread_mutex_unlock(&mutexSum);
    
    pthread_exit(NULL);
}

//thread to interval
void* threadInterval()
{
    pthread_mutex_lock(&mutexSum);
    InitialInterval* intervalArgs=qget(overallStatus.queue);
    pthread_mutex_unlock(&mutexSum);
    while (intervalArgs!=NULL) {
        double result,strips;
        integrate(((InitialInterval*)intervalArgs)->f,
                  ((InitialInterval*)intervalArgs)->a,
                  ((InitialInterval*)intervalArgs)->b,
                  ((InitialInterval*)intervalArgs)->precision, &result, &strips);
        pthread_mutex_lock(&mutexSum);
        overallStatus.stripAmount+=strips;
        overallStatus.itgrtResult+=result;
        intervalArgs=qget(overallStatus.queue);
        pthread_mutex_unlock(&mutexSum);
        
    }
    pthread_exit(NULL);
}

int main(int argc, const char * argv[]) {
	if(argc<4)
	{
		printf("%s\n","Error arguments!");
		return -1;
	}
    overallStatus.itgrtResult=0;
    overallStatus.stripAmount=0;
    void * status;
    int rc,i;
    
    int NUM_THREADS=10;
    double PRECISIION=0.01;
    
    InitialQueue QueueArgs;     //initial queue args
    QueueArgs.a =atof(argv[2]);
    QueueArgs.b = atof(argv[3]);
    if (atoi(argv[1])==1)
        QueueArgs.f=&function1;
    else if (atoi(argv[1])==2)
        QueueArgs.f=&function2;
    for (i=4; i<argc; i++) {
        if (strcmp(argv[i],"-p")==0) {
            i++;
            PRECISIION=atof(argv[i]);
        }
        if (strcmp(argv[i],"-m")==0) {
            i++;
            NUM_THREADS=atof(argv[i]);
        }
    }
    QueueArgs.NumOfThread=NUM_THREADS;
    QueueArgs.precision=PRECISIION;
    
    pthread_t threads[NUM_THREADS+1];//to store m+1 threads
    //initial the attribute
    pthread_attr_t thread_Attr;
    pthread_attr_init(&thread_Attr);
    pthread_attr_setdetachstate(&thread_Attr, PTHREAD_CREATE_JOINABLE);
    //initial the mutex
    pthread_mutex_init(&mutexSum, NULL);
    //create thread 0 to execute threadQueue()
    pthread_create(&threads[0], &thread_Attr, threadQueue, (void*)&QueueArgs);
    //wait thread 0 to join, wait the finishing of creating the argQueue
    pthread_join(threads[0], &status);
    //create threads to execute threadInterval()
    for(i=1; i<NUM_THREADS+1; i++){
        rc = pthread_create(&threads[i], &thread_Attr, threadInterval, NULL);
        if (rc){
            printf("ERROR! Return code from pthread_create() is %d\n", rc);
            return -1;
        }
    }
    //wait interval threads to join
    for(i=1; i<NUM_THREADS+1; i++)
    {
        rc = pthread_join(threads[i], &status);
        if (rc)
        {
            printf("ERROR; return code from pthread_join() is %d\n", rc);
            exit(-1);
        }
    }
//    double result=0;
//    double strips=0;
//    integrate(&function1, 3, 3000, 0.001, &result, &strips);
//    printf("%e %e\n",result,strips);
    printf("result:%f\nstrips:%f\n",
           overallStatus.itgrtResult,
           overallStatus.stripAmount);
    qapply(overallStatus.queue, &freeArg);
    qclose(overallStatus.queue);
    pthread_exit(NULL);
    return 0;
}
