/*************************************************************************
	> File Name: mpi_func.h
	> Author: Noelzhang
	> Mail: beitong.zhang.gr@dartmouth.edu
	> Created Time: Mon 27 Oct 2014 07:13:25 PM EDT
 ************************************************************************/


#define MYTAG 77
#define ALL MPI_COMM_WORLD
#define ANY MPI_ANY_SOURCE
#define MSGNULL ((MPI_CHAR*)0)

#define msgInit(argc,argv,n,pid)\
	{	MPI_Init(argc,argv);\
		MPI_Comm_size(ALL, n);\
		MPI_Comm_rank(ALL,pid);\
	}

#define msgFinalize()\
    MPI_Finalize()
#define msgSendTag(to,buffer,size, TAG)\
    MPI_Send(buffer,size,MPI_CHAR,to,TAG,ALL)
#define msgSend(to,buffer,size)\
    MPI_Send(buffer,size,MPI_CHAR,to,MYTAG,ALL)
#define msgRecvTag(from,buffer,size, tag)\
    {   MPI_Status status;\
        MPI_Recv(buffer,size,MPI_CHAR,ANY,MPI_ANY_TAG,ALL,&status);\
        *from=status.MPI_SOURCE;\
        *tag=status.MPI_TAG;\
    }
#define msgRecv(from,buffer,size)\
    {	MPI_Status status;\
        MPI_Recv(buffer,size,MPI_CHAR,ANY,MPI_ANY_TAG,ALL,&status);\
        *from=status.MPI_SOURCE;\
    }

//Sync Msgs
#define msgGo(to)\
	msgSend(to,MSGNULL,0)
#define msgWait(from)\
	msgRecv(from,MSGNULL,0)
#define msgAny()\
	{	int from;\
		msgRecv(from,MSGNULL,0);\
	}


#define mpi_send(buffer, size, dest) ({				\
		MPI_Send(buffer,size,MPI_CHAR,dest,MYTAG,MPI_COMM_WORLD);	\
		})

#define mpi_recv(buffer, size, source, status) ({	\
		MPI_Recv(buffer,size,MPI_CHAR,source,MYTAG,MPI_COMM_WORLD,status);		\
		})




