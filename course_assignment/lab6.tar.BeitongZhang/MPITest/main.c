#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include "mpi.h"
#include "mpi_func.h"
#include "MultThreadIntegrate.h"
#include "lqueue.h"

#define DataTAG 70
#define ResultTAG 71
#define ManagerPID 0

typedef struct initialqueue
{
    int processMark;
    int NumOfProcess;//Strips
    double a;//results
    double b;//wtime
    double precision;
    //double (*f)(double x);
}QueueArgs;

typedef struct managerArgs{
    int NumOfProcess;
    int balanceSize;
    double precision;
    double a;
    double b;
}ManagerArgs;

typedef struct status1
{
    void * queue;
    double itgrtResult;
    double stripAmount;
    int processLeft;
    int * processStrips;
}OverallStatus1;

OverallStatus1 overallStatus1;
int generateEndMark1=0;
int loopMark=0;

void* generator(void* args)
{
    ManagerArgs * Args=args;
    double width= (Args->b-Args->a)/(double)(Args->NumOfProcess-1)/(double)Args->balanceSize;
    //overallStatus.queue =lqopen();
    int i = 0;
    for (i=1; i<=(Args->NumOfProcess-1)*Args->balanceSize; i++) {
        QueueArgs * tempArgs = malloc(sizeof(QueueArgs));
        tempArgs->precision=Args->precision;
        tempArgs->a=Args->a+(double)(i-1)*width;
        tempArgs->b=Args->a+(double)i*width;
        tempArgs->NumOfProcess=Args->NumOfProcess;
        tempArgs->processMark=1;
        //printf("process %f,%f\n",tempArgs->a,tempArgs->b);
        lqput(overallStatus1.queue,tempArgs);
    }
    //generateEndMark1=1;
    pthread_exit(NULL);
}

void * msgHandler(void * args){
    QueueArgs * recvBuf=malloc(sizeof(QueueArgs));
    int from,sourceTag;
    while (1) {
        msgRecvTag(&from, recvBuf, sizeof(QueueArgs), &sourceTag);
		loopMark=0;
        if (sourceTag==DataTAG) {
            QueueArgs * qArg=lqget(overallStatus1.queue);
            while (qArg!=NULL||generateEndMark1!=0) {
                if (qArg!=NULL){
                    msgSendTag(from, qArg, sizeof(QueueArgs), DataTAG);
					generateEndMark1--;
					loopMark=1;
                    break;
                }
                else{//wait
                    qArg=lqget(overallStatus1.queue);
                    continue;
                }
            }
            if(qArg==NULL && generateEndMark1==0&& loopMark==0){
                recvBuf->processMark=0;
                msgSendTag(from, recvBuf, sizeof(QueueArgs), DataTAG);
            }
        }
        if (sourceTag==ResultTAG) {
            overallStatus1.stripAmount+=recvBuf->NumOfProcess;
            overallStatus1.itgrtResult+=recvBuf->a;
            overallStatus1.processStrips[from-1]=recvBuf->NumOfProcess;
            //printf("received process result %d %f\n",recvBuf->NumOfProcess,recvBuf->a);
            overallStatus1.processLeft--;
            if (overallStatus1.processLeft==0)
                break;
        }
    }
    pthread_exit(NULL);
}

void Manager(int myID,int numProc,int BalanceSize,double begin,double end, double precise){
    void *status;
    pthread_t generatorThread,msgHandleThread;
    //initial the attribute
    pthread_attr_t thread_Attr;
    pthread_attr_init(&thread_Attr);
    pthread_attr_setdetachstate(&thread_Attr, PTHREAD_CREATE_JOINABLE);
    //create generator thread
    ManagerArgs * genArg=malloc(sizeof(ManagerArgs));
    genArg->a=begin;
    genArg->b=end;
    genArg->balanceSize=BalanceSize;
    genArg->NumOfProcess=numProc;
    genArg->precision=precise;
    pthread_create(&generatorThread, &thread_Attr, generator, genArg);
    
    pthread_create(&msgHandleThread, &thread_Attr, msgHandler, NULL);
    pthread_join(generatorThread, &status);
    pthread_join(msgHandleThread, &status);
    printf("ALL finished!-------------------------------------------\nstrips: %f\nresult: %f\n"
           ,overallStatus1.stripAmount,overallStatus1.itgrtResult);
    int k,minStrip=999999,maxStrip=0;
    double stanDev=0.0,avg=overallStatus1.stripAmount/(double)(numProc-1);
    for (k=0; k<numProc-1; k++) {
		if(overallStatus1.processStrips[k]>maxStrip)
			maxStrip=overallStatus1.processStrips[k];
		if(overallStatus1.processStrips[k]<minStrip)
			minStrip=overallStatus1.processStrips[k];
        printf("process %d calculated %d strips\n",k+1,overallStatus1.processStrips[k]);
        stanDev+=(overallStatus1.processStrips[k]-avg)*(overallStatus1.processStrips[k]-avg);
    }
    stanDev=sqrt(stanDev/(numProc-1));
    printf("average strips: %f, standard deviation: %f\n, min:%d\nmax:%d\n",avg,stanDev,minStrip,maxStrip);
}

void Worker(int myID,int numProc,int threadNum,int MultTime){
    int localStrips=0,strips=0;
    double localResult=0.0,results = 0.0;
    QueueArgs * ask4work = malloc(sizeof(QueueArgs));
    ask4work->processMark=1;
    msgSendTag(ManagerPID, ask4work, sizeof(QueueArgs), DataTAG);
    while (1) {
        QueueArgs * args=malloc(sizeof(QueueArgs));
        int rcvSource;
        msgRecv(&rcvSource, args, sizeof(QueueArgs));
        if (args->processMark==1) {
            msgSendTag(ManagerPID, ask4work, sizeof(QueueArgs), DataTAG);;
            multThreadIntegrate(args->a, args->b, args->precision,
                                threadNum, MultTime, &strips, &results);
            localStrips+=strips;
            localResult+=results;
        }
        else{
            QueueArgs * rslt=malloc(sizeof(QueueArgs));
            rslt->NumOfProcess=localStrips;
            rslt->a=localResult;
			char name[100];
			int al;
			MPI_Get_processor_name(name,&al);
            //printf("finished in process %d result= %f strips=%d %s\n",myID,localResult,localStrips,name);
            msgSendTag(ManagerPID, rslt, sizeof(QueueArgs), ResultTAG);
            return;
        }
    }
}
//argv---begin,end,precise,balanceSize,threadNumPerProcess,threadBalance
//like---3,30,0.0001,15,10,5
int main(int argc, char * argv[]){
    int pid, numProc,threadNum,MultTime,BalanceSize;
    double begin, end, precise,startTime,finishTime;
    threadNum=atof(argv[5]);
    MultTime=atof(argv[6]);
    BalanceSize=atof(argv[4]);
    precise=atof(argv[3]);
    begin=atof(argv[1]);
    end=atof(argv[2]);
    msgInit(&argc,&argv,&numProc,&pid);
	startTime=MPI_Wtime();
	generateEndMark1=(numProc-1)*BalanceSize;
    if (pid==ManagerPID){
        overallStatus1.queue=lqopen();
        overallStatus1.itgrtResult=0.0;
        overallStatus1.stripAmount=0;
        overallStatus1.processLeft=numProc-1;
        overallStatus1.processStrips=malloc((numProc-1)*sizeof(int));
        Manager(pid, numProc,BalanceSize,begin,end,precise);
		finishTime=MPI_Wtime();
		printf("Running time %f\n",finishTime-startTime);
    }
    else
        Worker(pid, numProc,threadNum,MultTime);
    msgFinalize();
}
