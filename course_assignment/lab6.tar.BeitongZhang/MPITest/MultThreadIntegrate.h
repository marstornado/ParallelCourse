//
//  MultThreadIntegrate.h
//  MPIStart
//
//  Created by zhangNoel on 11/3/14.
//  Copyright (c) 2014 Dartmouth. All rights reserved.
//

int multThreadIntegrate(double from,double to, double epsilon, int threadNum, int time,
                        int *strips,double * results);


