//
//  main.c
//  pLab4_Client
//
//  Created by zhangNoel on 10/17/14.
//  Copyright (c) 2014 Dartmouth. All rights reserved.
//

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

#define MAXLENTH 1024
#define MAXRCV 4
int client_sockfd;
int rcvFlag=1;
void * status;
void * rcvHandler(void * args)
{
    long msgRcvLen;
    char localBuf[MAXRCV+1];
    char buf[MAXLENTH];
    memset(localBuf, 0, sizeof(localBuf));
    memset(buf, 0, sizeof(buf));
    while ((msgRcvLen=recv(client_sockfd,localBuf,MAXRCV,0))>0 && rcvFlag) {
        if (msgRcvLen==MAXRCV) {
            if (localBuf[MAXRCV-1]=='#') {
                localBuf[MAXRCV-1]='\0';
                strcat(buf, localBuf);
                memset(localBuf, 0, sizeof(localBuf));
            }
            else{
                localBuf[msgRcvLen]='\0';
                strcat(buf, localBuf);
                memset(localBuf, 0, sizeof(localBuf));
                continue;
            }
        }
        else{
            if(localBuf[0]!='#'){
                localBuf[msgRcvLen-1]='\0';
                strcat(buf, localBuf);
            }
        }
        //buf[msgRcvLen]='\0';
        //if (msgRcvLen>0) {
        printf("%s\n",buf);
        //memset(localBuf, 0, sizeof(localBuf));
        memset(buf, 0, sizeof(buf));
    }
    pthread_exit(NULL);
}

int main(int argc, const char * argv[]) {
    long len;
    struct sockaddr_in remote_addr; //server addr
    char buf[MAXLENTH];
    memset(&remote_addr,0,sizeof(remote_addr)); //initilize the addr
    remote_addr.sin_family=AF_INET; //IP protocl
    remote_addr.sin_addr.s_addr=inet_addr(argv[2]);//server IP_addr
    remote_addr.sin_port=htons(atoi(argv[3])); //server port
    if((client_sockfd=socket(PF_INET,SOCK_STREAM,0))<0){//create socket
        perror("socket");
        return 1;
    }
    //connect with server addr
    if(connect(client_sockfd,(struct sockaddr *)&remote_addr,sizeof(struct sockaddr))<0){
        perror("connect");
        return 1;
    }
    printf("connected to server\n");
    pthread_t localThread;
    pthread_create(&localThread,NULL,(void*)(&rcvHandler),NULL);
    
    while(1){//sending loop, keep sending!
        //scanf("%s",buf);
        fgets(buf, sizeof(buf), stdin);
        buf[strlen(buf)-1]='\0';
        if(strcmp(buf,"/quit")==0){
            rcvFlag=0;
            break;
        }
        if (strcmp("/join", buf)==0) {
            strcat(buf, argv[1]);
        }
        strcat(buf, "#");
        len=send(client_sockfd,buf,strlen(buf),0);
        //len=send(client_sockfd,buf,strlen(buf),0);
        memset(buf,0,sizeof(buf));
    }
    close(client_sockfd);//close socket
    printf("connection closed! Bye~\n");
    pthread_join(localThread, &status);
    return 0;
}
