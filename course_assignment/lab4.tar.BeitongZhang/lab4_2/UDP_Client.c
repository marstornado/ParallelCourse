//
//  main.c
//  parallel_lab3_Client
//
//  Created by zhangNoel on 10/12/14.
//  Copyright (c) 2014 Dartmouth. All rights reserved.
//

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/mman.h>
#include <unistd.h>

#define MAX_BUFF 1024
int rcvFlag=1;
int s;
int timers=3;

void closer(int a){
    if (timers==0) {
        rcvFlag=0;
        printf("Connection failed\n");
        exit(EXIT_SUCCESS);
    }
    else{
        timers--;
        printf("trying to connect, %d times left!\n",timers+1);
        signal(SIGALRM, closer);
        alarm(5);
    }
}
//initial a server socket
int sock_init(in_port_t port)
{
    int sfd;
    struct sockaddr_in serv_addr;
    
    sfd = socket(AF_INET, SOCK_DGRAM, 0);
    if(sfd == -1){
        perror("create failed");
        return -1;
    }
    
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    
    if(bind(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == -1)
        return -1;
    return sfd;
}

void * rcvHandler(void * args)
{
    long msgRcvLen;
    char buffer[MAX_BUFF];
    socklen_t len= sizeof(struct sockaddr_in);
    struct sockaddr_in client_addr;
    while (rcvFlag) {
        memset(buffer, 0, sizeof(buffer));
        msgRcvLen = recvfrom(s, buffer, 1024, 0,(struct sockaddr *)&client_addr, &len);
        if (msgRcvLen>0) {
            alarm(0);
            buffer[msgRcvLen] = '\0';
            printf("%s\n",buffer);
        }
        
    }
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    char name[256];
    strcpy(name, argv[1]);
    char SERV_IP[256];
    strcpy(SERV_IP, argv[2]);
    unsigned short int SERV_PORT= (unsigned short int)atoi(argv[3]);
    struct sockaddr_in serverAddr;
    socklen_t addrlen = sizeof(serverAddr);
    char message[MAX_BUFF];
    
    //char a[256];
    /*create a UDP socket*/
    if ((s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
        perror("create socket failed");
        return 0;
    }
    
    /*initialize the serverAddr*/
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(SERV_PORT);
    inet_aton(SERV_IP, &serverAddr.sin_addr);
    pthread_t localThread;
    pthread_create(&localThread,NULL,(void*)(&rcvHandler),NULL);
    /*send message to server*/
    while (1) {
        //scanf("%s", message);
        fgets(message, sizeof(message), stdin);
        //gets(a);
        message[strlen(message)-1]='\0';
        if (strcmp("/quit", message)==0) {
            rcvFlag=0;
            break;
        }
        if (strcmp("/join", message)==0) {
            strcat(message, name);
        }
        signal(SIGALRM, closer);
        alarm(5);
        sendto(s, message, strlen(message), 0, (struct sockaddr *)&serverAddr, addrlen);
        //printf("Client -- Sent message:%s\n", message);
        memset(message,0,sizeof(message));
    }
    pthread_join(localThread, NULL);
    return 0;
}

