#include "queue.h"
#include <pthread.h>
pthread_mutex_t mutexl = PTHREAD_MUTEX_INITIALIZER;


#define lqopen() ({                         \
    pthread_mutex_lock(&mutexl);            \
    void *lqBegin = qopen();                \
    pthread_mutex_unlock(&mutexl);          \
    lqBegin;                                \
    })

#define lqclose(lqp) {                      \
    pthread_mutex_lock(&mutexl);            \
    qclose(lqp);                            \
    pthread_mutex_lock(&mutexl);            \
}

#define lqput(lqp, elementp)                \
{                                           \
    pthread_mutex_lock(&mutexl);            \
    qput(lqp, elementp);                    \
    pthread_mutex_unlock(&mutexl);          \
}

#define lqget(lqp) ({                       \
    pthread_mutex_lock(&mutexl);            \
    void *elementp = qget(lqp);             \
    pthread_mutex_unlock(&mutexl);          \
    elementp;                               \
})

#define lqsearch(lqp, search, skeyp) ({                     \
    pthread_mutex_lock(&mutexl);                            \
    void *elementp = qsearch(lqp, search, skeyp);           \
    pthread_mutex_unlock(&mutexl);                          \
    elementp;                                               \
})

#define lqremove(lqp, search, skeyp) ({                     \
    pthread_mutex_lock(&mutexl);                            \
    void *elementp = qremove(lqp, search, skeyp);           \
    pthread_mutex_unlock(&mutexl);                          \
    elementp;                                               \
})

#define lqapply(lqp, fn) {                  \
    pthread_mutex_lock(&mutexl);            \
    qapply(lqp, fn);                        \
    pthread_mutex_unlock(&mutexl);          \
}

#define lqapply_arg(lqp, fn, arg) {         \
    pthread_mutex_lock(&mutexl);            \
    qapply_arg(lqp, fn, arg);               \
    pthread_mutex_unlock(&mutexl);          \
}




