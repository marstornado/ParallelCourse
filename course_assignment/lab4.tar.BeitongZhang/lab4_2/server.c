//
//  main.c
//  pLab4_Server
//
//  Created by zhangNoel on 10/17/14.
//  Copyright (c) 2014 Dartmouth. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include "lqueue.h"

#define MAXLENTH 1024
#define MAXRCV 4
#define THREAD_MAX 20

int server_sockfd;//server socket
void * clientQueue;//queue of clients, containing
int quitFlag=1;

typedef struct user_def{
    char usr_name[256];
    int client_sockfd;
    pthread_t client_thread;
    int inRoomFlag;
}User;

void join_handler(void * elmt){
    void *p;
    if (elmt==NULL)
        return;
    pthread_join(((User*)elmt)->client_thread, &p);
}
void close_handle(void * elmt){
    if (elmt==NULL)
        return;
    close(((User*)elmt)->client_sockfd);
}
//quit_handler
void * quit(void * n){
    while (1) {
        char buf[256];
        scanf("%s",buf);
        if (strcmp("/quit",buf)==0) {
            quitFlag=0;
            break;
        }
    }
    lqapply(clientQueue, & close_handle);
    lqapply(clientQueue, &join_handler);
    exit(EXIT_SUCCESS);
}

void broadCast_arg(void * usr, void * msg){
    if (usr==NULL)
        return;
    char * letters=(char *) msg;
    char temp[BUFSIZ];
    strcpy(temp, letters);
    strcat(temp, "#");
    if(((User*)usr)->inRoomFlag)
        if(send(((User*)usr)->client_sockfd,temp,strlen(temp),0)<0)
            perror("write");
}
//socket is equal
int socketIsEqual(void * elmt, void * key){
    return ((User*)elmt)->client_sockfd==*((int*)key);
}
//name is equal
int nameIsEqual(void * elmt, void * key){
    return strcmp(((User*)elmt)->usr_name, (char*)key)==0;
}

void who_handler(void * elmt, void * usr){
    if (elmt==NULL) {
        return;
    }
    if(((User*)elmt)->inRoomFlag){
        char temp[BUFSIZ];
        strcpy(temp, ((User*)elmt)->usr_name);
        strcat(temp, "#");
        send(((User*)usr)->client_sockfd,temp,strlen(temp),0);
    }
}

//receive msg thread function
void* msgHandler(void * args){
    User* clientArg=(User*)args;
    long len;
    char localBuf[MAXRCV+1];
    char buffer[MAXLENTH];
    memset(localBuf, 0, sizeof(localBuf));
    memset(buffer, 0, sizeof(buffer));
    //printf("%d\n",clientArg->client_sockfd);
    send(clientArg->client_sockfd,"Welcome to Beitong's server#",29,0);
    while((len=recv(clientArg->client_sockfd,localBuf,MAXRCV,0))>0 && quitFlag){
        if (len==MAXRCV) {
            if (localBuf[MAXRCV-1]=='#') {
                localBuf[MAXRCV-1]='\0';
                strcat(buffer, localBuf);
                memset(localBuf, 0, sizeof(localBuf));
            }
            else{
                localBuf[len]='\0';
                strcat(buffer, localBuf);
                memset(localBuf, 0, sizeof(localBuf));
                continue;
            }
        }
        else{
            if(localBuf[0]!='#'){
                localBuf[len-1]='\0';
                strcat(buffer, localBuf);
            }
        }
        
        //buffer[len]='\0';
        char temp[1024],temp1[1024];
        strcpy(temp, buffer);
        strcpy(temp1,buffer);
        temp[5]='\0';
        temp1[6]='\0';
        printf("%s\n",buffer);
        if (strcmp("/ping",buffer)==0) {
            char welcm[256]="Server is on, welcome!#";
            send(clientArg->client_sockfd,welcm,strlen(welcm),0);
        }
        else if(strcmp("/who",buffer)==0){
            //printf("%d\n",clientArg->client_sockfd);
            lqapply_arg(clientQueue, &who_handler, clientArg);
        }
        else if(strcmp("/join",temp)==0){
            char *name=buffer+5;
            User* localUsr=lqsearch(clientQueue, &nameIsEqual, name);
            if(localUsr==NULL){//address not exist
                strcpy(clientArg->usr_name,name);
                clientArg->inRoomFlag=1;
                char finish[256]="Welcom ";
                strcat(finish, name);
                strcat(finish, "! Chat in the room now!#");
                send(clientArg->client_sockfd,finish,strlen(finish),0);
            }
            else{
                char existed[256]="User existed, change your nick name or ip address :)#";
                send(clientArg->client_sockfd,existed,strlen(existed),0);
            }
        }
        else if(strcmp("/leave",temp1)==0){
            if(clientArg->inRoomFlag==0){
                char existed[256]="User not existed, you can't leave without joining in!#";
                send(clientArg->client_sockfd,existed,strlen(existed),0);
            }
            else{
                send(clientArg->client_sockfd,"bye~#",6,0);
                clientArg->inRoomFlag=0;
                strcpy(clientArg->usr_name,"");
            }
        }
        else{
            if(clientArg->inRoomFlag==0){//address not exist
                char existed[256]="You are not in the chating room now!#";
                send(clientArg->client_sockfd,existed,strlen(existed),0);
            }
            else{
                char temp[1024];
                strcpy(temp, clientArg->usr_name);
                strcat(temp, ": ");
                strcat(temp, buffer);
                clientArg->inRoomFlag=0;
                lqapply_arg(clientQueue, &broadCast_arg, temp);
                clientArg->inRoomFlag=1;
            }
        }
        memset(buffer, 0, sizeof(buffer));
    }
    lqremove(clientQueue, &socketIsEqual, &(clientArg->client_sockfd));
    close(clientArg->client_sockfd);
    pthread_exit(NULL);
}


int main(int argc, const char * argv[]) {
    int cl_sockfd = 0;//client socket
    clientQueue=lqopen();
    pthread_create(malloc(sizeof(pthread_t)), NULL, &quit, NULL);
    struct sockaddr_in my_addr, remote_addr;
    unsigned int sin_size=sizeof(struct sockaddr_in);
    memset(&my_addr,0,sizeof(my_addr)); //Initialize my_addr
    my_addr.sin_family=AF_INET; //IP
    my_addr.sin_addr.s_addr=INADDR_ANY;//any IP addr
    my_addr.sin_port=htons((unsigned short int)atoi(argv[1])); //port number
    if((server_sockfd=socket(PF_INET,SOCK_STREAM,0))<0){//create TCP socket
        perror("socket");
        return 1;
    }
    if (bind(server_sockfd,(struct sockaddr *)&my_addr,sizeof(struct sockaddr))<0){
        perror("bind");
        return 1;
    }
    listen(server_sockfd,10);//listen!
    while ((cl_sockfd=accept(server_sockfd,(struct sockaddr *)&remote_addr,&sin_size))>=0 && quitFlag) {
//        if((cl_sockfd=accept(server_sockfd,(struct sockaddr *)&remote_addr,&sin_size))<0){
//            perror("accept");
//            return 1;
//        }
        printf("accept client %s\n",inet_ntoa(remote_addr.sin_addr));
        //printf("%d\n",cl_sockfd);
        User *localUsr=malloc(sizeof(User));
        localUsr->client_sockfd=cl_sockfd;
        localUsr->inRoomFlag=0;
        lqput(clientQueue, localUsr);
        pthread_create(&(localUsr->client_thread), NULL, &msgHandler, localUsr);
        memset(&remote_addr,0,sizeof(remote_addr));
    }
    return 0;
}
