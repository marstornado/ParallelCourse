#include <stdio.h>
#include <mpi.h>
#include <string.h>

void printStatus(int size,int rank)
{
    printf("Hello: %d processes, process %d\n", size, rank);
}

void ManagerWorker( int argc, char *argv[] )
{
    int rank, size;
    int sendBuf;
    int recvBuf;
    int tag = 1;
    int i = 1;

    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &size );

    if(rank == 0)
    {   
    	while(i < size){
    	    MPI_Send(&sendBuf, 1, MPI_INT, i, tag, MPI_COMM_WORLD); 
            i++;
    	}
        i = 1;
    	while(i < size){
    	    MPI_Recv(&recvBuf, 1, MPI_INT, MPI_ANY_SOURCE, tag, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
            i++;
    	}
    }
    else {
    	MPI_Recv(&recvBuf, 1, MPI_INT, 0, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    	printStatus(size,rank);
    	MPI_Send(&sendBuf, 1, MPI_INT, 0, tag, MPI_COMM_WORLD); 
    }
    MPI_Finalize();
}


void TokenPassing( int argc, char *argv[] ){
    int rank, size;
    int token;
    int recvBuf;
    int tag = 1;
    int i = 1;

    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &size );

    if(rank == 0)
    {
    	printStatus(size,rank);
        if(rank != size-1)
        {
    	   MPI_Send(&token, 1, MPI_INT, rank + 1, tag, MPI_COMM_WORLD);
        }
        while(i<size){
            MPI_Recv(&recvBuf, 1, MPI_INT, i, tag + 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            printStatus(size,i);
            i++;
        }

    }else{
    	MPI_Recv(&recvBuf, 1, MPI_INT, rank-1, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Send(&token, 1, MPI_INT, 0 , tag + 1, MPI_COMM_WORLD);
    	if(rank != size - 1)
    	{
    	    MPI_Send(&token, 1, MPI_INT, rank + 1, tag, MPI_COMM_WORLD);
    	}
    	
    }
    MPI_Finalize();
}

void ReverseTokenPassing( int argc, char *argv[] ){
    int rank, size, i;
    int token;
    int recvBuf;
    int tag = 1;

    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &size );
    i = size - 2;

    if(rank == size - 1)
    {
    	printStatus(size,rank);
        if(rank != 0)
        {
    	   MPI_Send(&token, 1, MPI_INT, rank - 1, tag, MPI_COMM_WORLD);
        }
        while(i >= 0){
            MPI_Recv(&recvBuf, 1, MPI_INT, i, tag + 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            printStatus(size,i);
            i--;
        }

    }else{
    	MPI_Recv(&recvBuf, 1, MPI_INT, rank + 1, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Send(&token, 1, MPI_INT, size-1 , tag + 1, MPI_COMM_WORLD);
    	if(rank != 0)
    	{
    	    MPI_Send(&token, 1, MPI_INT, rank-1, tag, MPI_COMM_WORLD);
    	}
    	
    }
    MPI_Finalize();
}

int main( int argc, char *argv[] )
{

    if(argc < 2){
    	printf("Not enough arguments. Please try again.\n");
    	return 0;
    }
    switch(argv[1][0]){
    	case '1':
    		ManagerWorker(argc,argv);
    		break;
    	case '2':
    		TokenPassing(argc,argv);
    		break;
    	case '3':
    		ReverseTokenPassing(argc,argv);
    		break;
    	default:
    		printf("Parameter not supported!\n");
    		break;
    }
    return 0;
}
