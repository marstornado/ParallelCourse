#include "stdio.h"
#include "mpi.h"

int main(int argc, char *argv[]) 
{
	int p_id, p_num;
	
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &p_id);
	MPI_Comm_size(MPI_COMM_WORLD, &p_num);
	
	printf("Hello: %d processes, process %d\n", p_num, p_id);

	MPI_Finalize();
	return 0;
}