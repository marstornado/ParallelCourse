#include "stdio.h"
#include "mpi.h"

/* print the messages */
void message_printer (int p_id, int p_num) 
{
    printf("Hello: %d processes, process %d\n", p_num, p_id);
}

void manager_worker (int argc, char *argv[]) 
{
	int p_id, p_num;

	int message_size = 1;
	int message_buffer[message_size];

	int manager_id = 0;
	int tag = 1;
	MPI_Status status;

	/* initialize MPI */
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &p_id);
	MPI_Comm_size(MPI_COMM_WORLD, &p_num);

	if (p_id == manager_id) 
	{
		/* manager send messages to workers */
		for(int worker_id = 1; worker_id < p_num; worker_id++) {
			MPI_Send(message_buffer, message_size, MPI_INT, worker_id, tag, MPI_COMM_WORLD);
		}

		/* manager recieve feedback from workers */
		for(int worker_id = 1; worker_id < p_num; worker_id++) {
			MPI_Recv(message_buffer, message_size, MPI_INT, MPI_ANY_SOURCE, tag, MPI_COMM_WORLD, &status);
		}

	} else {
		/* workers recieve messages from manager */
		MPI_Recv(message_buffer, message_size, MPI_INT, manager_id, tag, MPI_COMM_WORLD, &status);

		/* print the messages */
		message_printer(p_id, p_num);

		/* workers send messages to manager */
		MPI_Send(message_buffer, message_size, MPI_INT, manager_id, tag, MPI_COMM_WORLD);
	}

	/* finalize MPI */
	MPI_Finalize();
}

void token_passing (int argc, char *argv[]) 
{
	int p_id, p_num;

    int message_size = 1;
    int message_buffer[message_size];
    
    int token;
    int token_size = 1;

	int tag = 1;
	MPI_Status status;

	/* initialize MPI */
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &p_id);
	MPI_Comm_size(MPI_COMM_WORLD, &p_num);

	if (p_id == 0)
	{
        message_printer(p_id, p_num);
        
        if(p_id != p_num - 1) {
            MPI_Send(&token, 1, MPI_INT, p_id + 1, tag, MPI_COMM_WORLD);
        }
        
        for (int id = 1; id < p_num; id++) {
            MPI_Recv(message_buffer, message_size, MPI_INT, id, tag + 1, MPI_COMM_WORLD, &status);
            message_printer(id, p_num);
        }
    } else {
        MPI_Recv(message_buffer, message_size, MPI_INT, p_id - 1, tag, MPI_COMM_WORLD, &status);
        MPI_Send(&token, token_size, MPI_INT, 0, tag + 1, MPI_COMM_WORLD);
        
        if(p_id != p_num - 1) {
            MPI_Send(&token, token_size, MPI_INT, p_id + 1, tag, MPI_COMM_WORLD);
        }
    }

	/* finalize MPI */
	MPI_Finalize();
}


void token_passing_reverse_order (int argc, char *argv[])
{
    int p_id, p_num;
    
    int message_size = 1;
    int message_buffer[message_size];
    
    int token;
    int token_size = 1;
    
    int tag = 1;
    MPI_Status status;
    
    /* initialize MPI */
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &p_id);
    MPI_Comm_size(MPI_COMM_WORLD, &p_num);
    
    if (p_id == p_num - 1)
    {
        message_printer(p_id, p_num);
        
        if(p_id != 0) {
            MPI_Send(&token, 1, MPI_INT, p_id - 1, tag, MPI_COMM_WORLD);
        }
        
        for (int id = p_num - 2; id >= 0; id--) {
            MPI_Recv(message_buffer, message_size, MPI_INT, id, tag + 1, MPI_COMM_WORLD, &status);
            message_printer(id, p_num);
        }
    } else {
        MPI_Recv(message_buffer, message_size, MPI_INT, p_id + 1, tag, MPI_COMM_WORLD, &status);
        MPI_Send(&token, token_size, MPI_INT, p_num - 1, tag + 1, MPI_COMM_WORLD);
        
        if(p_id != 0) {
            MPI_Send(&token, token_size, MPI_INT, p_id - 1, tag, MPI_COMM_WORLD);
        }
    }
    
    /* finalize MPI */
    MPI_Finalize();
}

/* main function */
int main( int argc, char *argv[] )
{
    
    if(argc < 2){
        printf("Not enough arguments \n");
        return 0;
    }
    switch(argv[1][0]){
        case '1':
            manager_worker(argc,argv);
            break;
        case '2':
            token_passing(argc,argv);
            break;
        case '3':
            token_passing_reverse_order(argc,argv);
            break;
        default:
            printf("Wrong input! \n");
            break;
    }
    return 0;
}
