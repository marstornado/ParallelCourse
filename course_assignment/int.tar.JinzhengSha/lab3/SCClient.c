/*
 * client of simple chat
 * ID          ==   argv[1]
 * Server IP   ==   argv[2]
 * Port Number ==   argv[3]
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <pthread.h>
#define MAXSIZE 512
#define M 2048

typedef struct Message{
    char id[MAXSIZE];
    char content[MAXSIZE];
}message;

struct sockaddr_in serverAddr;
socklen_t addrlen;
char recvContent[MAXSIZE], sendContent[M];
int s, recvlen, flag;
message m;

void *recvMessage(void *p);

void *sendMessage(void *p);

int main(int argc, char *argv[]) {
    /*define 2 threads*/
    
    flag = 1;
    pthread_t thread[2];
    
    addrlen = sizeof(serverAddr);
    
    /*get the id*/
    strcpy(m.id, argv[1]);
    
    /*create a UDP socket*/
    if ((s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
        perror("Client -- create socket failed");
        return 0;
    }
    
    /*initialize the serverAddr*/
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(atoi(argv[3]));
    inet_aton(argv[2], &serverAddr.sin_addr);
    
 
    /*send message to server*/
    pthread_create(&thread[0], NULL, sendMessage, NULL);
    
    /*receive message from server*/
    pthread_create(&thread[1], NULL, recvMessage, NULL);
    
    pthread_join(thread[0], NULL);
    pthread_join(thread[1], NULL);
    pthread_exit(NULL);
    return 0;
}

void *recvMessage(void *p){
    while (flag) {
        recvlen = (int)recvfrom(s, recvContent, sizeof(message), 0, (struct sockaddr *)&serverAddr, &addrlen);
        printf("Server -- Received message:%s\n", recvContent);
        memset(recvContent, 0, MAXSIZE);
    }
    return NULL;
}

void *sendMessage(void *p){
    while (flag) {
        printf("Client -- input message: \n");
        scanf("%s", m.content);
        memset(sendContent, 0, sizeof(sendContent));
        memcpy(sendContent, (char *)&m, sizeof(message));
        if (sendto(s, sendContent, sizeof(message), 0, (struct sockaddr *)&serverAddr, addrlen) < 0){
            printf("send failed!\n");
            return 0;
        }
        if (!strcmp(m.content, "\\leave"))
            flag = 0;
        printf("Client -- Sent message:%s\n", m.content);
        memset(m.content, 0, MAXSIZE);
    }
    return NULL;
}


