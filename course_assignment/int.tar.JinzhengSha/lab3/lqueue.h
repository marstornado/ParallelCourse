#include "queue.h"
#include <pthread.h>
pthread_mutex_t mutex2 = PTHREAD_MUTEX_INITIALIZER;


#define LQOPEN() ({                         \
    pthread_mutex_lock(&mutex2);            \
    void *lqBegin = qopen();                \
    pthread_mutex_unlock(&mutex2);          \
    lqBegin;                                \
    })

#define LQCLOSE(lqp) {                      \
    pthread_mutex_lock(&mutex2);            \
    qclose(lqp);                            \
    pthread_mutex_lock(&mutex2);            \
}

#define LQPUT(lqp, elementp)                \
{                                           \
    pthread_mutex_lock(&mutex2);            \
    qput(lqp, elementp);                    \
    pthread_mutex_unlock(&mutex2);          \
}

#define LQGET(lqp) ({                       \
    pthread_mutex_lock(&mutex2);            \
    void *elementp = qget(lqp);             \
    pthread_mutex_unlock(&mutex2);          \
    elementp;                               \
})

#define LQSEARCH(lqp, search, skeyp) ({                     \
    pthread_mutex_lock(&mutex2);                            \
    void *elementp = qsearch(lqp, search, skeyp);           \
    pthread_mutex_unlock(&mutex2);                          \
    elementp;                                               \
})

#define LQREMOVE(lqp, search, skeyp) ({                     \
    pthread_mutex_lock(&mutex2);                            \
    void *elementp = qremove(lqp, search, skeyp);           \
    pthread_mutex_unlock(&mutex2);                          \
    elementp;                                               \
})

#define LQAPPLY(lqp, fn) {                  \
    pthread_mutex_lock(&mutex2);            \
    qapply(lqp, fn);                        \
    pthread_mutex_unlock(&mutex2);          \
}





