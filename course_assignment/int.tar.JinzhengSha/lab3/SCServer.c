/*
 * server of simple chat
 * Port Number == argv[1]
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <pthread.h>
#include "lqueue.h"
#define MAXSIZE 512
#define M 2048

typedef struct User{
    char id[MAXSIZE];
    struct sockaddr_in clientAddr;
}user;

typedef struct Work{
    char content[MAXSIZE];
    char id[MAXSIZE];
    struct sockaddr_in clientAddr;
}work;

typedef struct Message{
    char id[MAXSIZE];
    char content[MAXSIZE];
}message;


char ping[] = "\\ping";
char join[] = "\\join";
char leave[] = "\\leave";
char who[] = "\\who";
char ping_reply[] = "Server is up!";
char join_fail[] = "Join fails because of same IDs";

void *qClient, *qWork;
socklen_t addrlen;
message recvStruct;
char handleBuffer[MAXSIZE], recvBuffer[M];
int recvlen, fd, flag;
struct sockaddr_in serverAddr, clientAddr, *activeAddr, *tmptAddr;

pthread_t thread[2];


int search_user(void *elementp, void *keyp);

int search_addr(void *elementp, void *keyp);

int search_id(void *elementp, void *keyp);

void print_addr(void* elementp);

void broadcast_addr(void *elementp);

void *recvMessage(void *p);

void *handleMessage(void *p);

int main(int argc, char *argv[]){
    flag = 1;
    addrlen = sizeof(clientAddr);
    qClient = LQOPEN();
    qWork = LQOPEN();
    
    /*create a UDP socket*/
    if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("create socket failed");
        return 0;
    }
    /*bind fd to any IP address provided by the operating system and a specific port*/
    memset((char *)&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    /*serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);*/
    inet_aton(argv[2], &serverAddr.sin_addr);
    serverAddr.sin_port = htons(atoi(argv[1]));
    if (bind(fd, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("bind failed");
        return 0;
    }
    
    /*initialize the two threads*/
    pthread_create(&thread[0], NULL, recvMessage, NULL);
    pthread_create(&thread[1], NULL, handleMessage, NULL);
    pthread_join(thread[0], NULL);
    pthread_join(thread[1], NULL);
    close(fd);
}

int search_addr(void *elementp, void *keyp)
{
    user *elementpTmpt = (user *)elementp;
    user *keypTmpt = (user *)keyp;
    if (elementpTmpt->clientAddr.sin_addr.s_addr == keypTmpt->clientAddr.sin_addr.s_addr)
        return 1;
    return 0;
}

int search_id(void *elementp, void *keyp)
{
    user *elementpTmpt = (user *)elementp;
    char *keypTmpt = (char *)keyp;
    if (!strcmp(elementpTmpt->id, keypTmpt))
        return 1;
    return 0;
}

void print_addr(void *elementp){
    user *t = (user*)elementp;
    printf("%d\n", t->clientAddr.sin_addr.s_addr);
}

void print_id(void *elementp){
    user *t = (user*)elementp;
    printf("%s\n", t->id);
}

void broadcast_addr(void *elementp){
    user *t = (user*)elementp;
    if (t->clientAddr.sin_addr.s_addr != activeAddr->sin_addr.s_addr) {
        printf("broadcasting ... !\n");
        sendto(fd, handleBuffer, strlen(handleBuffer), 0, (struct sockaddr *)&t->clientAddr, addrlen);
    }
}

void *recvMessage(void *p){
    while (flag) {
        /*for incoming data, decide which client it is*/
        memset(recvBuffer, 0, sizeof(recvBuffer));
        recvlen = (int)recvfrom(fd, (char *)recvBuffer, sizeof(recvBuffer), 0, (struct sockaddr *)&clientAddr, &addrlen);
        memcpy(&recvStruct, recvBuffer, sizeof(message));
        tmptAddr = malloc(sizeof(struct sockaddr_in));
        if (recvlen > 0) {
            /*recvBuffer->content[recvlen] = 0;*/
            printf("Server -- Received message: %s\n", recvStruct.content);
        }
        memcpy(tmptAddr, &clientAddr, sizeof(struct sockaddr_in));
        
        /*create a work struct and put it into qWork*/
        work *w = malloc(sizeof(work));
/*
        printf("recvStruct.content ---> %s\n", recvStruct.content);
        printf("recvStruct.id ---> %s\n", recvStruct.id);
        printf("addr ---> %d\n", tmptAddr->sin_addr.s_addr);
*/
        memcpy(&(w->clientAddr), tmptAddr, sizeof(struct sockaddr_in));
        memcpy(w->content, recvStruct.content, MAXSIZE * sizeof(char));
        memcpy(w->id, recvStruct.id, MAXSIZE * sizeof(char));
        LQPUT(qWork, w);
        
        /*reset the recvBuffer*/
        memset(recvStruct.content, 0, sizeof(recvStruct.content));
        memset(recvStruct.id, 0, sizeof(recvStruct.id));
    }
    return NULL;
}

void *handleMessage(void *p){
    while (flag) {
        work *tmpt = LQGET(qWork);
        user *tmpt_user;
        if (tmpt != NULL) {
            activeAddr = &(tmpt->clientAddr);
            memcpy(handleBuffer, tmpt->content, sizeof(tmpt->content));
            if (!memcmp(handleBuffer, ping, sizeof(ping))) {
                sendto(fd, ping_reply, sizeof(ping_reply), 0, (struct sockaddr *)activeAddr, addrlen);
                printf("Server -- \\ping OK!\n");
            }
            /* /join */
            else if (!memcmp(handleBuffer, join, sizeof(join))) {
                if (LQSEARCH(qClient, search_id, tmpt->id) == NULL) {
                    tmpt_user = malloc(sizeof(user));
                    memcpy(&(tmpt_user->clientAddr), &(tmpt->clientAddr), sizeof(struct sockaddr));
                    strcpy(tmpt_user->id, tmpt->id);
                    LQPUT(qClient, tmpt_user);
                    printf("Server -- \\join OK!\n");
                }
                else
                    sendto(fd, join_fail, sizeof(join_fail), 0, (struct sockaddr *)activeAddr, addrlen);
            }
            /* /leave */
            else if (!memcmp(handleBuffer, leave, sizeof(leave))) {
                LQREMOVE(qClient, search_addr, activeAddr);
                printf("Server -- \\leave OK!\n");
            }
            /* /who */
            else if (!memcmp(handleBuffer, who, sizeof(who))) {
                LQAPPLY(qClient, print_id);
                printf("Server -- \\who OK!\n");
            }
            else if (atoi(handleBuffer) == -1) {
                flag = 0;
                printf("Port is going to close!!!\n");
            }
            /* normal message */
            else {
                printf("broadcast OK!\n");
                LQAPPLY(qClient, broadcast_addr);
            }
        }
        memset(handleBuffer, 0, MAXSIZE * sizeof(char));
    }
    return NULL;
}


