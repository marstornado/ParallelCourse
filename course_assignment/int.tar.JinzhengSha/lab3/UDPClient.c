/*simple UDP client*/
/*IP address of port number are passed through command line arguments*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#define MAXSIZE 512

int main(int argc, char *argv[]) {
    struct sockaddr_in serverAddr;
    socklen_t addrlen = sizeof(serverAddr);
    char message[MAXSIZE];
    int s;
    
    /*create a UDP socket*/
    if ((s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
        perror("create socket failed");
        return 0;
    }
    
    /*initialize the serverAddr*/
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(atoi(argv[2]));
    inet_aton(argv[1], &serverAddr.sin_addr);
    
    /*send message to server*/
    while (1) {
        scanf("%s", message);
        sendto(s, message, strlen(message), 0, (struct sockaddr *)&serverAddr, addrlen);
        printf("Client -- Sent message:%s\n", message);
    }
}

