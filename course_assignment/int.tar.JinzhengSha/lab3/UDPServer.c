/*implementing a simple UDP server*/
/*PORT number is from a command line argument*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

#define MAXSIZE 512

int main(int argc, char *argv[]){
    struct sockaddr_in serverAddr, clientAddr;
    socklen_t addrlen = sizeof(clientAddr);
    char buffer[MAXSIZE];
    int recvlen, fd;
    int sum = 0;
    
    /*create a UDP socket*/
    if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("create socket failed");
        return 0;
    }
    
    /*bind fd to any IP address provided by the operating system and a specific port*/
    memset((char *)&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
   /* serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);*/
    inet_aton(argv[2], &serverAddr.sin_addr);
    serverAddr.sin_port = htons(atoi(argv[1]));
    if (bind(fd, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("bind failed");
        return 0;
    }
   
    /*loop for incoming data*/
    while (1) {
        /*printf("Server -- Waiting for data on port: %d\n", portNum);*/
        recvlen = (int)recvfrom(fd, buffer, MAXSIZE, 0, (struct sockaddr *)&clientAddr, &addrlen);
        /*printf("Server -- received %d bytes\n", recvlen);*/
        if (recvlen > 0) {
            buffer[recvlen] = 0;
            printf("Server -- received message: %s\n", buffer);
        }
        if (atoi(buffer) == 0)
            sum = 0;
        else if (atoi(buffer) == -1)
            break;
        else
            sum += atoi(buffer);
        printf("Server -- total number is %d\n", sum);
        memset(buffer, 0, MAXSIZE * sizeof(char));
    }
   close(fd); 
}

