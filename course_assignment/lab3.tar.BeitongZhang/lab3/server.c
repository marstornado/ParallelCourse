//
//  server.c
//  Parallel_Lab3
//
//  Created by zhangNoel on 10/12/14.
//  Copyright (c) 2014 Dartmouth. All rights reserved.
//
#include "queue.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define MAX_BUFF 1024

void * usrQueue;//queue of users
int quitFlag=1;
int serverFD;//socket for server
pthread_mutex_t mutexQ=PTHREAD_MUTEX_INITIALIZER;

//----------------------structs and functions------------
//user structure
typedef struct user_def
{
    char *usr_name;
    struct sockaddr_in addr;
    int is_online;
}User;

//msgHandler's argument struct
typedef struct MsgArg
{
    char msg[MAX_BUFF];
    struct sockaddr_in addr;
}msgArg;

//whether two socket addr are equal
int is_equal(void * a, void * b)
{
    struct sockaddr_in *p=&((User*)a)->addr;
    struct sockaddr_in *q=&((User*)b)->addr;
    return (p->sin_family == q->sin_family && p->sin_port == q->sin_port && p->sin_addr.s_addr == q->sin_addr.s_addr) || (strcmp(((User*)a)->usr_name,((User*)b)->usr_name)==0);
}
//
int is_equal_addr(void * a, void * b)
{
    struct sockaddr_in *p=&((User*)a)->addr;
    struct sockaddr_in *q=&((User*)b)->addr;
    return p->sin_family == q->sin_family &&
            p->sin_port == q->sin_port &&
            p->sin_addr.s_addr == q->sin_addr.s_addr;
}
//initial a server socket
int sock_init(in_port_t port)
{
    int sfd;
    struct sockaddr_in serv_addr;
    
    sfd = socket(AF_INET, SOCK_DGRAM, 0);
    if(sfd == -1){
        perror("create failed");
        return -1;
    }
    
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    
    if(bind(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == -1)
        return -1;
    return sfd;
}
//broadCast message
void broadCast_arg(void * usr, void * msg)
{
    if (usr==NULL) {
        return;
    }
    sendto(serverFD, msg, strlen(msg), 0,(struct sockaddr *)&((User*)usr)->addr, sizeof(((User*)usr)->addr));
}
//send "who" info
void who_handler(void * usr, void * addr)
{
    if (usr==NULL) {
        return;
    }
    sendto(serverFD, ((User*)usr)->usr_name, strlen(((User*)usr)->usr_name), 0,(struct sockaddr *)addr, sizeof(*((struct sockaddr *)addr)));

}
void* quit(void * p)
{
    while (1) {
        char quit1[256];
        scanf("%s",quit1);
        if (strcmp("/quit", quit1)==0) {
            quitFlag=0;
            close(serverFD);
            
            break;
        }
    }
    
    exit(EXIT_SUCCESS);
}
//receive msg thread function
void* msgHandler(void * args){
    msgArg * message=args;
    long n;
    char temp[1024];
    strcpy(temp, message->msg);
    temp[5]='\0';
    char temp1[1024];
    strcpy(temp1, message->msg);
    temp1[6]='\0';
    printf("%s\n",message->msg);
    if (strcmp("/ping",message->msg)==0) {
        char welcm[256]="Server is on, welcome!";
        n=sendto(serverFD, welcm, strlen(welcm), 0,(struct sockaddr *)&message->addr, sizeof(message->addr));
    }
    else if(strcmp("/who",message->msg)==0){
        qapply_arg(usrQueue, &who_handler, &message->addr);
    }
    else if(strcmp("/join",temp)==0)
    {
        char name[256];
        int i;
        for (i=5;i<=strlen(message->msg);i++)
            name[i-5]=message->msg[i];
        User* usr=malloc(sizeof(User));
        usr->addr=message->addr;
        usr->is_online=1;
        usr->usr_name=malloc(256*sizeof(char));
        strcpy(usr->usr_name, name);
        pthread_mutex_lock(&mutexQ);
        User* localUsr=qsearch(usrQueue, &is_equal, usr);
        if(localUsr==NULL)//address not exist
            qput(usrQueue, usr);
        else
        {
            char existed[256]="User existed, change your nick name or ip address :)\n";
            n=sendto(serverFD, existed, strlen(existed), 0,(struct sockaddr *)&message->addr, sizeof(message->addr));
            pthread_mutex_unlock(&mutexQ);
            pthread_exit(NULL);
        }
        pthread_mutex_unlock(&mutexQ);
        char finish[256]="Welcom ";
        strcat(finish, name);
        strcat(finish, "! Chat in the room now!");
        n=sendto(serverFD, finish, strlen(finish), 0,(struct sockaddr *)&message->addr, sizeof(message->addr));
    }
    else if(strcmp("/leave",temp1)==0)
    {
        char name[256];
        int i;
        for (i=6;i<=strlen(message->msg);i++)
            name[i-6]=message->msg[i];
        User* usr=malloc(sizeof(User));
        usr->addr=message->addr;
        usr->is_online=1;
        usr->usr_name=malloc(256*sizeof(char));
        strcpy(usr->usr_name, name);
        pthread_mutex_lock(&mutexQ);
        User* localUsr=qremove(usrQueue, &is_equal, usr);
        if(localUsr==NULL)
        {
            char existed[256]="User not existed, you can't leave without joining in!\n";
            n=sendto(serverFD, existed, strlen(existed), 0,(struct sockaddr *)&message->addr, sizeof(message->addr));
            pthread_mutex_unlock(&mutexQ);
            pthread_exit(NULL);
        }
        else
        {
            char existed[256]="Bye~\n";
            n=sendto(serverFD, existed, strlen(existed), 0,(struct sockaddr *)&message->addr, sizeof(message->addr));
            pthread_mutex_unlock(&mutexQ);
            pthread_exit(NULL);
        }
    }
    else
    {
        User* usr=malloc(sizeof(User));
        usr->addr=message->addr;
        usr->is_online=1;
        usr->usr_name=NULL;
        pthread_mutex_lock(&mutexQ);
            User* localUsr=qsearch(usrQueue, &is_equal_addr, usr);
        if(localUsr==NULL)//address not exist
        {
            char existed[256]="You are not in the chating room now!\n";
            n=sendto(serverFD, existed, strlen(existed), 0,(struct sockaddr *)&message->addr, sizeof(message->addr));
            pthread_mutex_unlock(&mutexQ);
            pthread_exit(NULL);
        }
        else
        {
            char temp[1024];
            strcpy(temp, localUsr->usr_name);
            strcat(temp, ": ");
            strcat(temp, message->msg);
            User * tempUsr=qremove(usrQueue, &is_equal_addr, usr);
            qapply_arg(usrQueue, &broadCast_arg,temp);
            qput(usrQueue, tempUsr);
            pthread_mutex_unlock(&mutexQ);
        }
    }
    pthread_exit(NULL);
}

//--------------------------------------------------------

int main(int argc, char *argv[])
{
    usrQueue=qopen();
    pthread_t localThread_quit;
    pthread_create(&localThread_quit,NULL,(void*)(&quit),NULL);
    long msgRcvLen;
    char buffer[MAX_BUFF];
    unsigned short int portNum=(unsigned short int)atoi(argv[1]);
    
    socklen_t len= sizeof(struct sockaddr_in);
    struct sockaddr_in client_addr; //initialed by (recvfrom) function
    serverFD = sock_init(portNum);  //initial the server socket
    
    while(quitFlag){
        //keep receive msg from given port
        msgRcvLen = recvfrom(serverFD, buffer, 1024, 0,(struct sockaddr *)&client_addr, &len);
        //if there's a message, create a thread and handle with the message
        if (msgRcvLen>0) {
            buffer[msgRcvLen] = '\0';
            msgArg localMsgArg;//create thread arg struct
            //sendto(serverFD, buffer, 1024, 0, (struct sockaddr *)&client_addr, len);
            localMsgArg.addr=client_addr;
            strcpy(localMsgArg.msg, buffer);
            pthread_t localThread;
            pthread_create(&localThread,NULL,(void*)(&msgHandler),(void*)&localMsgArg);//open a thread to handle with this msg
            memset(buffer, 0, sizeof(buffer));
        }
    }
    close(serverFD);
    pthread_exit(NULL);
    return 0;
}


