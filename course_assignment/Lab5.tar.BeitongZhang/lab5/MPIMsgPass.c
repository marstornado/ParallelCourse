/*************************************************************************
	> File Name: MPIHello.c
	> Author: Noelzhang
	> Mail: beitong.zhang.gr@dartmouth.edu
	> Created Time: Sun 26 Oct 2014 04:31:36 PM EDT
 ************************************************************************/

#include<stdio.h>
#include<mpi.h>
#include<string.h>
#include <unistd.h>
#include "mpi_func.h"

void Manager(int myID,int numProc){
	MPI_Status status;
		
	int i;
	char Msg[]="Print Begin!";
	char recvBuf[100];
	for(i=0;i<numProc;++i){
		if(i!=myID){
			mpi_send(Msg,sizeof(Msg),i);
			mpi_recv(recvBuf,sizeof(recvBuf),MPI_ANY_SOURCE,&status);
		}
	}
}

void Worker(int myID,int numProc){
	MPI_Status status;
		
	int i,nameLen;
	char Msg[]="Print Finished!";
	char recvBuf[100];
	char name[100];
	mpi_recv(recvBuf,sizeof(recvBuf),MPI_ANY_SOURCE,&status);
	MPI_Get_processor_name(name,&nameLen);
	printf("Hello: %d processes, process %d %s\n",numProc,myID,name);
	usleep(10000);
	mpi_send(Msg,sizeof(Msg),0);
}

void Token_Pass(int myID,int numProc){
	MPI_Status status;
	int nameLen;
	char begin[]="Print Begin";
	char recvBuf[100];
	char name[100];
	if(myID!=0){
		mpi_recv(recvBuf,sizeof(recvBuf),MPI_ANY_SOURCE,&status);
		MPI_Get_processor_name(name,&nameLen);
		printf("Hello: receive from %d, in process %d %s\n",status.MPI_SOURCE,myID,name);
	}
	else
		printf("Begin from process %d\n",myID);
	usleep(10000);
	if(myID!=numProc-1)
		mpi_send(begin,sizeof(begin),myID+1);
}

void Token_Pass_Reverse(int myID,int numProc){
	MPI_Status status;
	int nameLen;
	char begin[]="Print Begin";
	char recvBuf[100];
	char name[100];
	if(myID!=numProc-1){
		mpi_recv(recvBuf,sizeof(recvBuf),MPI_ANY_SOURCE,&status);
		MPI_Get_processor_name(name,&nameLen);
		printf("Hello: receive from %d, in process %d %s\n",status.MPI_SOURCE,myID,name);
	}
	else
		printf("Begin from process %d\n",myID);
	usleep(10000);
	if(myID!=0)
		mpi_send(begin,sizeof(begin),myID-1);
}

int main(int argc, char * argv[]){
	int myID, numProc;
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD,&myID);
	MPI_Comm_size(MPI_COMM_WORLD,&numProc);
	int modeArg=atoi(argv[1]);
	if(modeArg==1){//Manager-worker 
		if(myID==0)
			Manager(myID,numProc);
		else
			Worker(myID,numProc);
	}
	else if(modeArg==2)//token
		Token_Pass(myID,numProc);
	else if(modeArg==3)//reverse token
		Token_Pass_Reverse(myID,numProc);
	else
		printf("Wrong Argument\n");
	MPI_Finalize();
}
