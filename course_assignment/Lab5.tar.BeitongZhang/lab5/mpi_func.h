/*************************************************************************
	> File Name: mpi_func.h
	> Author: Noelzhang
	> Mail: beitong.zhang.gr@dartmouth.edu
	> Created Time: Mon 27 Oct 2014 07:13:25 PM EDT
 ************************************************************************/

#include<stdio.h>
#include<mpi.h>

#define MYTAG 77

#define mpi_send(buffer, size, dest) ({				\
		MPI_Send(buffer,size,MPI_CHAR,dest,MYTAG,MPI_COMM_WORLD);	\
		})

#define mpi_recv(buffer, size, source, status) ({	\
		MPI_Recv(buffer,size,MPI_CHAR,source,MYTAG,MPI_COMM_WORLD,status);		\
		})




