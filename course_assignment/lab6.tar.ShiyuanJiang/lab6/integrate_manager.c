#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include "./MPI_module_datastructures.h"
#include "./integrate_datastructures.h"

double total_value = 0.0;
double total_strips = 0.0;
double *total_strips_for_each_process;
int number_of_processes;

void* generatePartitions(void *in) {
  
  int i, number_of_threads = 10;
  task_info *currEntry;
  double tmp1, tmp2;
  int processes_size, argc; 
  char **argv;
  void *lq_head;
  argu *argument;

  double (*f)(double x);
  int ratio = 100;
  double upperBound, lowerBound, precision = 0.01;

  argument = (argu *) in;
  processes_size = argument->size;
  argc = argument->argc;
  argv = argument->argv;
  lq_head = argument->lq_head;

  if (argc < 4) {
    printf("At least 3 arguments are required. They are:\nfunc a b\n");
    return;
  }

  total_strips_for_each_process = (double *) malloc((processes_size) * sizeof(double));
  number_of_processes = processes_size;

  tmp1 = atof(argv[2]);
  tmp2 = atof(argv[3]);

  if (tmp1 > tmp2) {
    lowerBound = tmp2;
    upperBound = tmp1;
  }
  else {
    lowerBound = tmp1;
    upperBound = tmp2;
  }

  for (i = 4; i < argc; i++) {
    if (argv[i][0] == '-') {
      if (argv[i][1] == 'p') {
        precision = atof(argv[i+1]);
      }
      if (argv[i][1] == 'm') {
        number_of_threads = atoi(argv[i+1]);
      }
    }
  }

  for (i = 0; i < (processes_size - 1) * ratio; i++) {
    currEntry = (task_info *) malloc(sizeof(task_info));
    currEntry->isDone = 0;
    currEntry->func_number = atoi(argv[1]);
    currEntry->number_of_threads = number_of_threads;
    currEntry->precision = precision;
    currEntry->interval_a = lowerBound + i * (upperBound - lowerBound) / ((processes_size - 1) * ratio);
    currEntry->interval_b = lowerBound + (i + 1) * (upperBound - lowerBound) / ((processes_size - 1) * ratio);

    lqput(lq_head, currEntry);
  }

  *(argument->generation_done) = 1;
  printf("Manager finishes generating partitions.\n");
  pthread_exit(NULL);
}

void updateResult(double value, double strips, int idx) {
  total_value += value;
  total_strips += strips;
  *(total_strips_for_each_process + idx) += strips;
}

void printOutResult() {
  double min = DBL_MAX, max = -DBL_MAX, aver = 0;
  int i;

  for (i = 1; i < number_of_processes; i++) {
    if (min > total_strips_for_each_process[i]) {
      min = total_strips_for_each_process[i];
    }
    if (max < total_strips_for_each_process[i]) {
      max = total_strips_for_each_process[i];
    }
    aver += total_strips_for_each_process[i];
  }

  aver /= (number_of_processes - 1);

  printf("The total value of the integration is: %f.\nThe total number of strips used is %f.\n", total_value, total_strips);
  printf("For individual process:\nMax number of strips used is %f\nMin number of strips used is %f\nAverage number of strips used is %f\n",
	  max, min, aver);
}
