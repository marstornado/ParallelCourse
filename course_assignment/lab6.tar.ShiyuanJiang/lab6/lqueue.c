#include <stdlib.h>
#include "lqueue.h"
#include "queue.h"
#include <pthread.h>

typedef struct LQUEUE_HEAD {
  pthread_mutex_t queue_mutex;
  void* queue_head;
} lqueueHead;

/* create an empty locked queue */
void* lqopen(void) {
  lqueueHead *lqhead = (lqueueHead *) malloc(sizeof(lqueueHead));
  pthread_mutex_init(&lqhead->queue_mutex, NULL);
  lqhead->queue_head = qopen();
  return (void *)lqhead;
}        

/* deallocate a queue, assuming every element has been removed and deallocated */
void lqclose(void *lqp) {
  lqueueHead *lqhead = (lqueueHead *)lqp;
  pthread_mutex_destroy(&lqhead->queue_mutex);
  qclose(lqhead->queue_head);
  free(lqhead);
}   

/* check if a queue is empty */
int lqempty(void *lqp) {
  int result = -1;
  pthread_mutex_lock(&((lqueueHead *) lqp)->queue_mutex);
  result = qempty(((lqueueHead *) lqp)->queue_head);
  pthread_mutex_unlock(&((lqueueHead *) lqp)->queue_mutex);
  return result;
}

/* put element at end of queue */
void lqput(void *lqp, void *elementp) {
  pthread_mutex_lock(&((lqueueHead *) lqp)->queue_mutex);
  qput(((lqueueHead *) lqp)->queue_head, elementp);
  pthread_mutex_unlock(&((lqueueHead *) lqp)->queue_mutex);
}

/* get first element from a queue */
void* lqget(void *lqp) {
  void *result;
  pthread_mutex_lock(&((lqueueHead *) lqp)->queue_mutex);
  result = qget(((lqueueHead *) lqp)->queue_head);
  pthread_mutex_unlock(&((lqueueHead *) lqp)->queue_mutex);
  return result;
}

/* apply a void function (e.g. a printing fn) to every element of a queue */
void lqapply(void *lqp, void (*fn)(void* elementp)) {
  pthread_mutex_lock(&((lqueueHead *) lqp)->queue_mutex);
  qapply(((lqueueHead *) lqp)->queue_head, fn);
  pthread_mutex_unlock(&((lqueueHead *) lqp)->queue_mutex);
}

/* search a queue using a supplied boolean function, returns an element */
void* lqsearch(void *lqp, 
	       int (*searchfn)(void* elementp,void* keyp),
	       void* skeyp) {
  void *result;
  pthread_mutex_lock(&((lqueueHead *) lqp)->queue_mutex);
  result = qsearch(((lqueueHead *) lqp)->queue_head, searchfn, skeyp);
  pthread_mutex_unlock(&((lqueueHead *) lqp)->queue_mutex);
  return result;
}

/* search a queue using a supplied boolean function, removes an element */
void* lqremove(void *lqp,
	       int (*searchfn)(void* elementp,void* keyp),
	       void* skeyp) {
  void *result;
  pthread_mutex_lock(&((lqueueHead *) lqp)->queue_mutex);
  result = qremove(((lqueueHead *) lqp)->queue_head, searchfn, skeyp);
  pthread_mutex_unlock(&((lqueueHead *) lqp)->queue_mutex);
  return result;
}

/* concatenatenates q2 onto q1, q2 may not be subsequently used */
void lqconcat(void *lq1p, void *lq2p) {
  pthread_mutex_lock(&((lqueueHead *) lq1p)->queue_mutex);
  pthread_mutex_lock(&((lqueueHead *) lq2p)->queue_mutex);
  qconcat(((lqueueHead *) lq1p)->queue_head, ((lqueueHead *) lq2p)->queue_head);
  pthread_mutex_unlock(&((lqueueHead *) lq1p)->queue_mutex);
  pthread_mutex_unlock(&((lqueueHead *) lq2p)->queue_mutex);

  free((lqueueHead *) lq2p);
}

