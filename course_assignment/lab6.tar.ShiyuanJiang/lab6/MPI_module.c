#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "./MPI_module_datastructures.h"
#include "./integrate_manager.h"
#include "./integrate_worker.h"
#include "./lqueue.h"

#define REQUEST_WORK 0
#define SUBMIT_RESULT 1

int workers_all_done(int workers[], int length) {
  int i;
  for (i = 1; i < length; i++) {
    if (workers[i] == 0)
      return 0;
  }
  return 1;
}

void manager(int rank, int size, int argc, char *argv[]) {
  pthread_t p_thread;
  MPI_Status status;
  int tag = 1, i, worker_num = size - 1;
  task_info sendInfo;
  task_info *current_p;
  result_info recvInfo;
  void *lq_head; 
  int workers_done = 0;
  int queue_generation_complete = 0;
  argu *argument;
  
  lq_head = lqopen();
  argument = (argu *) malloc(sizeof(argu));
  argument->rank = rank;
  argument->size = size;
  argument->argc = argc;
  argument->argv = argv;
  argument->lq_head = lq_head;
  argument->generation_done = &queue_generation_complete;
  pthread_create(&p_thread, NULL, generatePartitions, (void *)argument);
  /*generatePartitions(size, argc, argv, lq_head); */
  
  while (!(workers_done == worker_num && queue_generation_complete)) {
    MPI_Recv(&recvInfo, sizeof(result_info), MPI_BYTE, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
    if (recvInfo.category == REQUEST_WORK) {
      if (!lqempty(lq_head)) {
        current_p = lqget(lq_head);
        sendInfo.isDone = 0;
        sendInfo.func_number = current_p->func_number;
        sendInfo.number_of_threads = current_p->number_of_threads;
        sendInfo.precision = current_p->precision;
        sendInfo.interval_a = current_p->interval_a;
        sendInfo.interval_b = current_p->interval_b;      
        MPI_Send(&sendInfo, sizeof(task_info), MPI_BYTE, status.MPI_SOURCE, tag, MPI_COMM_WORLD);
      }
      else {
        if (queue_generation_complete) {
          sendInfo.isDone = 1;        
          MPI_Send(&sendInfo, sizeof(task_info), MPI_BYTE, status.MPI_SOURCE, tag, MPI_COMM_WORLD);
          workers_done++;
        }
        else {
          sendInfo.isDone = 2;        
          MPI_Send(&sendInfo, sizeof(task_info), MPI_BYTE, status.MPI_SOURCE, tag, MPI_COMM_WORLD);
        }
      }
    }
    else if (recvInfo.category == SUBMIT_RESULT) {
      updateResult(recvInfo.value, recvInfo.strips, status.MPI_SOURCE);
    }
  }

  printf("Manager is done.\n");
}

void worker(int rank, int size) {
  int tag = 1;
  int isDone = 0;
  result_info sendInfo;
  task_info recvInfo;

  while (!isDone) {
    sendInfo.category = REQUEST_WORK;
    MPI_Send(&sendInfo, sizeof(result_info), MPI_BYTE, 0, tag, MPI_COMM_WORLD);
    MPI_Recv(&recvInfo, sizeof(task_info), MPI_BYTE, 0, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
 
    if (recvInfo.isDone == 0) {
      sendInfo.category = SUBMIT_RESULT;
      solvePartitions(recvInfo, &sendInfo);
      /*printf("Over the interval [%f %f],\n", recvInfo.interval_a, recvInfo.interval_b);
      printf("The total value of the integration is: %f. The total strips used is: %f\n", sendInfo.value, sendInfo.strips);*/
      MPI_Send(&sendInfo, sizeof(result_info), MPI_BYTE, 0, tag, MPI_COMM_WORLD);
    }
    else if (recvInfo.isDone == 1) {
      printf("Worker %d is done.\n", rank);
      isDone = 1;
    }
  }
 
}

int main(int argc, char *argv[]) {

  int rank, size;
  double start_time, end_time;

  MPI_Init( &argc, &argv );
  start_time = MPI_Wtime();
  MPI_Comm_rank( MPI_COMM_WORLD, &rank );
  MPI_Comm_size( MPI_COMM_WORLD, &size );

  if (rank == 0) {
    manager(rank, size, argc, argv);
  }
  else {
    worker(rank, size);
  }

  end_time = MPI_Wtime();
  printf("Time used in rank %d process is: %f\n", rank, end_time - start_time);

  MPI_Finalize();

  if (rank == 0) {
    printOutResult();
  }

  return 0;
}
