#include "./integrate.h"
#include <math.h>
#include <stdint.h>
#include <stdio.h>

void integrate(double (*fn)(double x), double a, double b, double p, double *result, double *strips) {

  int i, stripsi;
  double w, currP, currValue, prevValue;

  if (b < a) {
    printf("Wrong interval input.\n");
    (*result) = 0.0;
    (*strips) = 0.0;
    return;
  }

  w = (b - a);
  stripsi = 2;
  currP = 10000000000.0;
  prevValue = ((*fn)(a) + (*fn)(b)) / 2 * w;

  while (p < currP) {
    currValue = 0;
    
    for (i = 1; i <= stripsi; i++) {
      currValue += ((*fn)(a + w * (i - 1) / stripsi) + (*fn)(a + w * i / stripsi)) / 2 * w / stripsi;
    }

    currP = fabs(currValue - prevValue);
    /*printf("currValue:%f prevValue:%f stripsi:%d currP:%f\n", currValue, prevValue, stripsi, currP);*/
    prevValue = currValue;
    stripsi *= 2;
  }

  (*result) = currValue;
  (*strips) = (double) (stripsi/2);

  return;
}
