
void integrate(double (*fn)(double x), double a, double b, double p, double *result, double *strips);

