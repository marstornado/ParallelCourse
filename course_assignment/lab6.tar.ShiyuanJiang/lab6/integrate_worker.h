#include "./integrate_datastructures.h"

void solvePartitions(task_info task, result_info *result);
