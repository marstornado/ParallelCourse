#include <stdlib.h>
#include "./queue.h"

typedef struct QUEUE_NODE {
  void *addr;
  struct QUEUE_NODE *next;
} queueNode;

typedef struct QUEUE_HEAD {
  void *addr;
} queueHead;

/* create an empty queue */
void* qopen(void) {
  queueHead *head = (queueHead *) malloc(sizeof(queueHead));
  head->addr = NULL;
  return head;
}        

/* deallocate a queue, assuming every element has been removed and deallocated */
void qclose(void *qp) {
  queueHead *head = (queueHead *) qp;
  free(head);
}

/* check if a queue is empty */
int qempty(void *qp) {
  queueHead *head = (queueHead *) qp;
  return head->addr == NULL;
}

/* put element at end of queue */
void qput(void *qp, void *elementp) {
  queueHead *head = ((queueHead *) qp);
  queueNode *currentNode;

  if (head->addr == NULL) {
    head->addr = malloc(sizeof(queueNode)); 
    currentNode = (queueNode *) head->addr; 
    currentNode->addr = elementp;
    currentNode->next = NULL;
    return;
  }

  currentNode = (queueNode *) head->addr;
  while (currentNode->next != NULL)
    currentNode = currentNode->next;
  currentNode->next = (queueNode *) malloc(sizeof(queueNode));
  currentNode = currentNode->next;
  currentNode->addr = elementp;
  currentNode->next = NULL;

}

/* get first element from a queue */
void* qget(void *qp) {
  queueHead *head = (queueHead *) qp;
  queueNode *currentNode = (queueNode *) head->addr;
  void* result;

  if (currentNode != NULL) {
    head->addr = currentNode->next;
    result = currentNode->addr;
    free(currentNode);
    return result;
  }
  else
    return NULL;
}

/* apply a void function (e.g. a printing fn) to every element of a queue */
void qapply(void *qp, void (*fn)(void* elementp)) {
  queueHead *head = (queueHead *) qp;
  queueNode *currentNode = (queueNode *) head->addr;
  
  while (currentNode != NULL) {
    (*fn)(currentNode->addr);
    currentNode = currentNode->next;
  }

}

/* search a queue using a supplied boolean function, returns an element */
void* qsearch(void *qp, 
              int (*searchfn)(void* elementp,void* keyp),
	      void* skeyp) {
  queueHead *head = (queueHead *) qp;
  queueNode *currentNode = (queueNode *) head->addr;

  while (currentNode != NULL) {
    if ((*searchfn)(currentNode->addr,skeyp) == 1) {
      return currentNode->addr;
    }
    currentNode = currentNode->next;
  }
  
  return NULL;
}

/* search a queue using a supplied boolean function, removes an element */
void* qremove(void *qp,
              int (*searchfn)(void* elementp,void* keyp),
	      void* skeyp) {
  queueHead *head = (queueHead *) qp;
  queueNode *currentNode = (queueNode *) head->addr;
  queueNode *prevNode = NULL;

  while (currentNode != NULL) {
    if ((*searchfn)(currentNode->addr,skeyp) == 1) {
      if (prevNode == NULL && currentNode->next == NULL) {
        head->addr = NULL;
      }
      else if (prevNode == NULL) {
        head->addr = currentNode->next;
      }
      else {
        prevNode->next = currentNode->next;
      }
      return currentNode->addr;
    }
    prevNode = currentNode;
    currentNode = currentNode->next;
  }

  return NULL;
}

/* concatenatenates q2 onto q1, q2 may not be subsequently used */
void qconcat(void *q1p, void *q2p) {
  queueHead *head1 = (queueHead *) q1p, *head2 = (queueHead *) q2p;
  queueNode *currentNode1 = (queueNode *) head1->addr, *currentNode2 = (queueNode *) head2->addr;
  queueNode *prevNode = NULL;

  while (currentNode1 != NULL) {
    prevNode = currentNode1;
    currentNode1 = currentNode1->next;
  }

  if (prevNode != NULL) {
    prevNode->next = currentNode2;
  }
  else {
    head1->addr = currentNode2;
  }

  free(head2);
}


