
void* generatePartitions(void *in); 

void updateResult(double value, double strips, int idx);

void printOutResult();
