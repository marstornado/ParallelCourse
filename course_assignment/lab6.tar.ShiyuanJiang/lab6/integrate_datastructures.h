#include <math.h>

typedef struct TASK_INFO {
  int isDone;
  int func_number;
  int number_of_threads;
  double precision;
  double interval_a;
  double interval_b;
} task_info;

typedef struct RESULT_INFO {
  int category;
  double value;
  double strips;
} result_info;

static double fn1(double x) {
  return x + 5;
}

static double fn2(double x) {
  return 2 * x * x + 9 * x + 4;
}

static double fn3(double x) {
  return x * sin(x * x);
}
