typedef struct argument {
  int rank;
  int size;
  int argc;
  void *lq_head;
  char **argv;
  int *generation_done;
} argu; 
