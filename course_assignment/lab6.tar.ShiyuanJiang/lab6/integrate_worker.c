#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "./integrate_datastructures.h"
#include "./integrate.h"

double value, strips;
double (*f)(double x);
pthread_mutex_t result_mutex = PTHREAD_MUTEX_INITIALIZER;

void* multithread_integration(void *in) {

  task_info *task;
  double currValue, currStrips;
  int rc;
  
  task = (task_info *) in;
  integrate(f, task->interval_a, task->interval_b, task->precision, &currValue, &currStrips);

  rc = pthread_mutex_lock(&result_mutex);
  if (rc) { 
    perror("pthread_mutex_lock");
    pthread_exit(NULL);
  }

  value += currValue;
  strips += currStrips;

  rc = pthread_mutex_unlock(&result_mutex);
  if (rc) {
    perror("pthread_mutex_unlock");
    pthread_exit(NULL);
  }  

  pthread_exit(NULL);
}

void solvePartitions(task_info task, result_info *result) {

  int number_of_threads, i;
  pthread_t p_thread[100];
  task_info *tasks;
  double upper_bound, lower_bound, precision;

  /*printf("task:\nfunc_number: %d, number_of_threads: %d, precision: %f, interval: [%f %f]\n",
          task.func_number, task.number_of_threads, task.precision, task.interval_a, task.interval_b);*/
  number_of_threads = task.number_of_threads;
  value = 0.0;
  strips = 0.0;
  upper_bound = task.interval_b;
  lower_bound = task.interval_a;
  precision = task.precision;

  switch (task.func_number) {
    case 1:
      f = &fn1;
      break;
    case 2:
      f = &fn2;
      break;
    case 3:
      f = &fn3;
      break;
    default:
      printf("Wrong function selection.\n");
      return;
  }
  
  tasks = (task_info *) malloc(100 * sizeof(task_info));
  
  for (i = 0; i < number_of_threads; i++) {
    (tasks + i)->interval_a = lower_bound + i * (upper_bound - lower_bound) / number_of_threads;
    (tasks + i)->interval_b = lower_bound + (i + 1) * (upper_bound - lower_bound) / number_of_threads;
    (tasks + i)->precision = precision;
    
    pthread_create(&p_thread[i], NULL, multithread_integration, (void *)(tasks + i));    
  }

  for (i = 0; i < number_of_threads; i++) {
    pthread_join(p_thread[i], NULL);
  }

  result->value = value;
  result->strips = strips;
}
