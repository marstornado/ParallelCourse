/*
 * integrate: returns the result of approximating the integral of f(x) over * the interval [a,b] to a stated level of precision and the number of strips * used in the computation.
 * return value: the total number of trapezoid calculations
 */
void integrate (double (*f)(double x),
                double a, double b, double precision,
                double *result, double *strips, double *num_trapezoid_cal);