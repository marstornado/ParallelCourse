#include "lqueue.h"
#include "queue.h"
#include <pthread.h>
#include <stdlib.h>

typedef struct LQUEUE{
    void *qp;
    pthread_mutex_t mutex;
}lqp;

/* create an empty queue */
public void* lqopen(void) {
    lqp *lqBegin = malloc(sizeof(struct LQUEUE));
    lqBegin->qp = qopen();
    pthread_mutex_init(&(lqBegin->mutex), NULL);
    void *tmpt = (void *)lqBegin;
    return tmpt;
}

/* deallocate a queue, assuming every element has been removed and deallocated */
public void lqclose(void *lqBegin) {
    lqp *tmpt = (lqp *)lqBegin;
    pthread_mutex_lock(&(tmpt->mutex));
    qclose(tmpt->qp);
    pthread_mutex_unlock(&(tmpt->mutex));
}

/* put element at end of queue */
public void lqput(void *lqBegin, void *elementp) {
    lqp *tmpt = (lqp *)lqBegin;
    pthread_mutex_lock(&(tmpt->mutex));
    qput(tmpt->qp, elementp);
    pthread_mutex_unlock(&(tmpt->mutex));
}

/* get first element from a queue */
public void* lqget(void *lqBegin) {
    lqp *tmpt = (lqp *)lqBegin;
    void *v;
    pthread_mutex_lock(&(tmpt->mutex));
    v = qget(tmpt->qp);
    pthread_mutex_unlock(&(tmpt->mutex));
    return v;
}

/* apply a void function (e.g. a printing fn) to every element of a queue */
public void lqapply(void *lqBegin, void (*fn)(void* elementp)) {
    lqp *tmpt = (lqp *)lqBegin;
    pthread_mutex_lock(&(tmpt->mutex));
    qapply(tmpt->qp, fn);
    pthread_mutex_unlock(&(tmpt->mutex));
}

/* search a queue using a supplied boolean function, returns an element */
public void* lqsearch(void *lqBegin,
                      int (*searchfn)(void* elementp,void* keyp),
                      void* skeyp) {
    lqp *tmpt = (lqp *)lqBegin;
    void *elementp;
    pthread_mutex_lock(&(tmpt->mutex));
    elementp = qsearch(tmpt->qp, searchfn, skeyp);
    pthread_mutex_unlock(&(tmpt->mutex));
    return elementp;
}

/* search a queue using a supplied boolean function, removes an element */
public void* lqremove(void *lqBegin,
                      int (*searchfn)(void* elementp,void* keyp),
                      void* skeyp) {
    lqp *tmpt = (lqp *)lqBegin;
    void *elementp;
    pthread_mutex_lock(&(tmpt->mutex));
    elementp = qremove(tmpt->qp, searchfn, skeyp);
    pthread_mutex_unlock(&(tmpt->mutex));
    return elementp;
}

