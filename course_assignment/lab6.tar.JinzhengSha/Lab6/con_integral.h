/* 
 * con_integrate: return the result of integrate using multiple threads 
   return value: the total number of trapezoid calculations in con_integrate */
void con_integrate (double (*f)(double x),
                    double a, double b, double precision,
                    double *result, double *strips, double * num_trapezoid_cal, int num_threads, int times);