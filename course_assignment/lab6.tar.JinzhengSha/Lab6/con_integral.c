#include "con_integral.h"
#include "integral.h"
#include "lqueue.h"
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
typedef struct PAR {
    void *qp;
    int numSubPartitions;
    double a;
    double b;
    double precision;
    double (*f)(double);
    double *result;
    double *strips;
    double *num_trapezoid_cal;
    pthread_mutex_t mutex;
}par;

typedef struct VAR4INTEGRAL
{
    double (*f)(double);
    double a;
    double b;
    double precision;
    double *result;
    double *strips;
    double *num_trapezoid_cal;
}var4integral;


/* divide a partition in each process into subpartitions and put them into a queue */
void *gen(void *g)
{
    par *partition1 = (par *)g;
    int i;
    int numSubPartitions = partition1->numSubPartitions;
    double a = partition1->a, b = partition1->b, precision = partition1->precision;
    double w = (b - a) / numSubPartitions;
    for (i = 0; i < numSubPartitions; i++) {
		var4integral *tmpt = malloc(sizeof(var4integral));
        tmpt->f = partition1->f;
        tmpt->a = a + w * i;
        tmpt->b = a + w * (i+1);
        tmpt->precision = precision;
        tmpt->result = partition1->result;
        tmpt->strips = partition1->strips;
        tmpt->num_trapezoid_cal = partition1->num_trapezoid_cal;
        lqput(partition1->qp, (void *)tmpt);
    }
    return NULL;
}

/* each thread in the process handle on sub-partition */
void *multiThreadIntegrateFromQueue(void *p)
{
    par *partition2 = (par *)p;
    var4integral * tmp;
    double result, strips, num_trapezoid_cal;
    int flag = 0;
    while (1) {
        tmp = lqget(partition2->qp);
        if (tmp != NULL) {
            integrate(tmp->f, tmp->a, tmp->b, tmp->precision, &result, &strips, &num_trapezoid_cal);
            pthread_mutex_lock(&(partition2->mutex));
            *(tmp->result) += result;
            *(tmp->strips) += strips;
            *(tmp->num_trapezoid_cal) += num_trapezoid_cal;
            partition2->numSubPartitions--;
            pthread_mutex_unlock(&(partition2->mutex));
        }
        pthread_mutex_lock(&(partition2->mutex));
        if (partition2->numSubPartitions <= 0)
            flag = 1;
        pthread_mutex_unlock(&(partition2->mutex));
        if (flag)
            break;
    }
    return NULL;
}

/* con_integrate: return the result of integrate using multiple threads */
void con_integrate (double (*f)(double x),
                    double a, double b, double precision,
                    double *result, double *strips, double *num_trapezoid_cal, int num_threads, int times) {
    int i;
    par *t = malloc(sizeof(par));
    pthread_t generator, work_thread[num_threads];
    
    /* initialize the struct par */
    t->qp = lqopen();
    t->numSubPartitions = num_threads * times;
    t->a = a;
    t->b = b;
    t->precision = precision;
    t->f = f;
    t->result = malloc(sizeof(double));
    *(t->result) = 0;
    t->strips = malloc(sizeof(double));
    *(t->strips) = 0;
    t->num_trapezoid_cal = malloc(sizeof(double));
    *(t->num_trapezoid_cal) = 0;
    pthread_mutex_init(&(t->mutex), NULL);

    /* create threads */
    pthread_create(&generator, NULL, gen, t);
    for (i = 0; i < num_threads; i++)
        pthread_create(&work_thread[i], NULL, multiThreadIntegrateFromQueue, t);
    
    /* wait for all the threads to stop */
   pthread_join(generator, NULL);
    for (i = 0; i < num_threads; i++)
        pthread_join(work_thread[i], NULL);
    
    *result = *(t->result);
    *strips = *(t->strips);
    *num_trapezoid_cal = *(t->num_trapezoid_cal);
    free(t);
}
