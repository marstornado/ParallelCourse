#include "utility.h"
#include "lqueue.h"
#include "msg.h"
#include "mpi.h"
#include "con_integral.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <math.h>
#include <unistd.h>
#define MAXSIZE 512

/* 
 * test functions 
 */
double f1(double x) {return x+5;}

double f2(double x) {return 2*x*x + 9*x + 4;}

double f3(double x) {return x * sin(x * x);}

/*
 *  structs used in communication
 *  1.      w        is the struct we pass to two threads in manager
 *  2.     wfp       is the struct we store partitions and put into queue
 *  3. returnResult  is the struct workers use to pass integral results back to manager
 */
typedef struct W {
    void *lqp;
    int isDone;
    double a;
    double b;
    double precision;
    double num_partitions;
    double result;
    double strips;
    double num_trapezoid_cal;
    pthread_mutex_t mutex;
}w;

typedef struct WORKFORPROCESS
{
    double a;
    double b;
    double precision;
}wfp;

typedef struct RETURNRESULT {
    double result;
    double strips;
    double num_partitions;
    double num_trapezoid_cal;
    double elapsedTime;
}returnResult;

/*
 * fuctions
 * 1. manager    ----   manager process
 * 2. partition  ----   manager calls it to partition original problems into small ones
 * 3. handout    ----   manager calls it to hand out partitions to workers
 * 4. worker     ----   worker process
 * 5. solve      ----   worker calls it to solve a partition from manager
 */

/****************************************/
/************  manager  *****************/
/****************************************/
void manager(double a, double b, double precision, double num_partition) {
    double start, end, elapsedTime;
    start = MPI_Wtime();
    pthread_t threads[2];
    w *work_tmpt = malloc(sizeof(w));
    
    /* initialize the work struct */
    work_tmpt->lqp = lqopen();
    work_tmpt->isDone = 0;
    work_tmpt->a = a;
    work_tmpt->b = b;
    work_tmpt->precision = precision;
    work_tmpt->num_partitions = num_partition;
    work_tmpt->result = 0;
    work_tmpt->strips = 0;
    work_tmpt->num_trapezoid_cal = 0;
    pthread_mutex_init(&(work_tmpt->mutex), NULL);
    
    /* create two threads to partition and handout partitions concurrently */
    pthread_create(&threads[0], NULL, partition, (void *)work_tmpt);
    pthread_create(&threads[1], NULL, handout, (void *)work_tmpt);
    pthread_join(threads[0], NULL);
    pthread_join(threads[1], NULL);
    printf("total result is %lf\n", work_tmpt->result);
    end = MPI_Wtime();
    elapsedTime = start - end;
}


/****************************************/
/************  partition  ***************/
/****************************************/
/* partition a problem and put the partitions into a locked queue */
void* partition(void *p) {
    w *w_tmpt = (w *)p;
    double width = (w_tmpt->b - w_tmpt->a) / w_tmpt->num_partitions;
    int i;
    for (i = 0; i < w_tmpt->num_partitions; i++) {
        wfp *tmpt = malloc(sizeof(wfp));
        tmpt->a = w_tmpt->a + width * i;
        tmpt->b = w_tmpt->a + width * (i+1);
        tmpt->precision = w_tmpt->precision;
        lqput(w_tmpt->lqp, (void *)tmpt);
    }
    w_tmpt->isDone = 1;
    return NULL;
}

/****************************************/
/************  handout  *****************/
/****************************************/
/* hand out partitions to different processes */
void *handout(void *p) {
    char buf[MAXSIZE];
    w *w_tmpt = (w *)p;
    void *w_from_queue;
    int from, tag, size, left_process;
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    double num_trapezoid_cal_all[size], min, max, average, elapsedTime = 0;
    /*  test */
    int i;
    for (i = 1; i < size; i++)
        num_trapezoid_cal_all[i] = -1;
    
    returnResult *r_t_r = malloc(sizeof(returnResult));
    left_process = size;
    while (left_process > 1)
    {
        memset(buf, 0, sizeof(buf));
        msgRecvTag(&from, buf, sizeof(buf), &tag);
        switch (tag)
        {
            case 0:
                memset(buf, 0, sizeof(buf));
                if (((w_from_queue = lqget(w_tmpt->lqp)) != NULL) || (w_tmpt->isDone == 0))
                {
                    if (w_from_queue != NULL)
                    {
                        memcpy(buf, w_from_queue, sizeof(wfp));
                        msgSendTag(from, buf, sizeof(buf), 2);
                    }
                    else
                        msgSendTag(from, buf, sizeof(buf), 0);
                }
                else
                    msgSendTag(from, buf, sizeof(buf), 1);
                break;
            case 1:
                left_process -= 1;
                memset(r_t_r, 0, sizeof(returnResult));
                memcpy(r_t_r, buf, sizeof(returnResult));
                pthread_mutex_lock(&(w_tmpt->mutex));
                w_tmpt->result += r_t_r->result;
                w_tmpt->strips += r_t_r->result;
                w_tmpt->num_partitions -= r_t_r->num_partitions;
                w_tmpt->num_trapezoid_cal += r_t_r->num_trapezoid_cal;
                num_trapezoid_cal_all[from] = r_t_r->num_trapezoid_cal;
                elapsedTime = elapsedTime < r_t_r->elapsedTime?r_t_r->elapsedTime:elapsedTime;
                pthread_mutex_unlock(&(w_tmpt->mutex));
                break;
        }
    }
    
    /* analysis */
    average = w_tmpt->num_trapezoid_cal / (size-1);
    min = num_trapezoid_cal_all[1], max = num_trapezoid_cal_all[1];
    for (i = 1; i < size; i++) {
        max = max > num_trapezoid_cal_all[i]?max:num_trapezoid_cal_all[i];
        min = min < num_trapezoid_cal_all[i]?min:num_trapezoid_cal_all[i];
    }
    printf("max num of trapezoid calculation is %lf\n", max);
    printf("min num of trapezoid calculation is %lf\n", min);
    printf("average num of trapezoid calculation is %lf\n", average);
    printf("elapsed time is %lf\n", elapsedTime);
    return NULL;
}

/****************************************/
/*************  worker   ****************/
/****************************************/
void worker(double num_thread, double times) {
    double start, end, elapsedTime;
    start = MPI_Wtime();
    char replyBuf[MAXSIZE];
    int src, tag, rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    returnResult *returnPerProcess = malloc(sizeof(returnResult));
    returnPerProcess->result = 0;
    returnPerProcess->strips = 0;
    returnPerProcess->num_partitions = 0;
    returnPerProcess->num_trapezoid_cal = 0;
    
    msgSendTag(0, "1", sizeof("1"), 0);
    
    while (1) {
        memset(replyBuf, 0, sizeof(replyBuf));
        msgRecvTag(&src, replyBuf, sizeof(replyBuf), &tag);
        if (tag == 0)
        {
            msgSendTag(0, "1", sizeof("1"), 0);
            continue;
        }
        else if (tag == 1)
        {
            break;
        }
        else if (tag == 2)
        {
            msgSendTag(0, "1", sizeof("1"), 0);
            returnResult *returnTmpt = malloc(sizeof(returnResult));
            solve((void *)replyBuf, (void *)returnTmpt, num_thread, times, rank);
            returnPerProcess->result += returnTmpt->result;
            returnPerProcess->strips += returnTmpt->strips;
            returnPerProcess->num_trapezoid_cal += returnTmpt->num_trapezoid_cal;
            returnPerProcess->num_partitions++;
        }
    }
    end = MPI_Wtime();
    elapsedTime = end - start;
    returnPerProcess->elapsedTime = elapsedTime;
    /* send integral result to manager */
    memset(replyBuf, 0, sizeof(replyBuf));
    memcpy(replyBuf, returnPerProcess, sizeof(returnResult));
    msgSendTag(0, replyBuf, sizeof(replyBuf), 1);
    /*printf("process %d terminated, integral result is %lf, num of trapezoid cal is %lf\n", rank, returnPerProcess->result, returnPerProcess->num_trapezoid_cal);*/
    
}

/****************************************/
/**************  solve  *****************/
/****************************************/
/* solve a partition in a process by dividing the partition into smaller sub-partitions and solving each one with a thread */
void* solve(void *partition, void *returnTmpt, int num_thread, int times, int rank) {
    double result, strips, num_trapezoid_cal;
    wfp *wfp_tmpt = (wfp *)partition;
    returnResult *rt = (returnResult *)returnTmpt;
    con_integrate(&f3, wfp_tmpt->a, wfp_tmpt->b, wfp_tmpt->precision, &result, &strips, &num_trapezoid_cal, num_thread, times);
    rt->result = result;
    rt->strips = strips;
    rt->num_trapezoid_cal = num_trapezoid_cal;
    return NULL;
}
