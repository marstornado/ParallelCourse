#include <stdio.h>
#include <math.h>
#include "integral.h"

void integrate (double (*f)(double x),
                double a, double b, double precision,
                double *result, double *strips, double * num_trapezoid_cal)
{
    int numOfStrips, i;
    double res1, res2, w, num_trapezoid_cal_thread = 0;
    /*number of strip == 1*/
    numOfStrips = 1;
    res1 = (f(a) + f(b)) / 2 * (b - a) / numOfStrips;
    num_trapezoid_cal_thread += 1;
    /*number of strip == 2*/
    numOfStrips = 2;
    res2 = (f(a)/2 + f(b)/2 + f((a+b)/2)) * (b - a) / numOfStrips;
    num_trapezoid_cal_thread += 2;
    /*increasing number of strips until precision satisfied*/
    while (fabs(res2 - res1) >= precision)
    {
        res1 = res2;
        res2 = 0;
        numOfStrips++;
        w = (b-a)/numOfStrips;
        for (i = 1; i <= numOfStrips; i++)
            res2 += (f(a + w * i) + f(a + w * (i-1)))/2;
        res2 = res2 * w;
        num_trapezoid_cal_thread += numOfStrips;
    }
    *result = res2;
    *strips = numOfStrips;
    *num_trapezoid_cal = num_trapezoid_cal_thread;
}

