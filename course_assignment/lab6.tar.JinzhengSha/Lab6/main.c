#include "msg.h"
#include "mpi.h"
#include "utility.h"
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
    int size, pid, num_partition, num_thread, times;
    double a, b, precision;
    msgInit(&argc, &argv, &size, &pid);
    if (pid == 0) {
        a = atof(argv[1]);
        b = atof(argv[2]);
        precision = atof(argv[3]);
        num_partition = (size - 1 ) * atoi(argv[4]);
        manager(a, b, precision, num_partition);
    }
    else {
        num_thread = atoi(argv[5]);
        times = atoi(argv[6]);
        worker(num_thread, times);
    }
    msgFinalize();
    return 0;
}

