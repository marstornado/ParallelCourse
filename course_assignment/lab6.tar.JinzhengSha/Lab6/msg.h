#define ALL MPI_COMM_WORLD
#define ANY_SRC MPI_ANY_SOURCE
#define ANY_TAG MPI_ANY_TAG

/*
 * use different tags to mark different types of messages
 * 1. manager receives message from worker
 * if (tag == 0), means requesting for work and handing out work
 * if (tag == 1), means sending back finished work
 *
 * 2. worker receive message from worker
 * if (tag == 0), means there is no work in queue currently, you have to wait
 * if (tag == 1), all work has been done
 * if (tag == 2), receive work
 */

#define msgInit(argc, argv, n, pid){        \
    MPI_Init(argc, argv);                   \
    MPI_Comm_size(ALL, n);                  \
    MPI_Comm_rank(ALL, pid);                \
}

#define msgFinalize()                       \
    MPI_Finalize();


#define msgSendTag(to, buf, size, tag)      \
    MPI_Send(buf, size, MPI_CHAR, to, tag, ALL);


#define msgRecvTag(from, buf, size, tag) {                          \
    MPI_Status status;                                              \
    memset(buf, 0, size);                                           \
    MPI_Recv(buf, size, MPI_CHAR, ANY_SRC, ANY_TAG, ALL, &status);  \
    *from = (int)status.MPI_SOURCE;                                 \
    *tag = (int)status.MPI_TAG;                                     \
}


