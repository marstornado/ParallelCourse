#include "msg.h"
#include "mpi.h"
#include "utility.h"
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
    int size, pid, num_thread, times;
    double a, b, precision, start, end, elapsedTime;
    msgInit(&argc, &argv, &size, &pid);
    start = MPI_Wtime();
    if (pid == 0) {
        a = atof(argv[1]);
        b = atof(argv[2]);
        precision = atof(argv[3]);
        manager(a, b, precision, size);
    }
    else {
        num_thread = atoi(argv[4]);
        times = atoi(argv[5]);
        worker(num_thread, times);
    }
    end = MPI_Wtime();
    msgFinalize();
    elapsedTime = end - start;
    /*printf("elapsed time in process %d is %lf\n", pid, elapsedTime);*/
    return 0;
}

