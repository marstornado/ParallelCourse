/* manager process */
void manager(double a, double b, double precision, int size);

/* worker process */
void worker(double num_thread, double times);

/* partition a problem and put the partitions into a locked queue */
void* partition(void *p);

/* hand out partitions to different processes */
void *handout(void *p);

/* solve a partition in a process by dividing the partition into smaller sub-partitions and solving each one with a thread */
void* solve(void *partition, void *returnTmpt, int num_thread, int times, int rank);