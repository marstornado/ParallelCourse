#include "utility.h"
#include "lqueue.h"
#include "msg.h"
#include "mpi.h"
#include "con_integral.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <math.h>
#include <unistd.h>
#define MAXSIZE 512

/* 
 * test functions 
 */
double f1(double x) {return x+5;}

double f2(double x) {return 2*x*x + 9*x + 4;}

double f3(double x) {return x * sin(x * x);}

/*
 *  structs used in communication
 *  1.      w        is the struct we pass to two threads in manager
 *  2.     wfp       is the struct we store partitions and put into queue
 *  3. returnResult  is the struct workers use to pass integral results back to manager
 */
typedef struct W {
    void *lqp;
    int isDone;
    double a;
    double b;
    double precision;
    double num_partitions;
    double result;
    double strips;
    double num_trapezoid_cal;
    pthread_mutex_t mutex;
}w;

typedef struct WORKFORPROCESS
{
    double a;
    double b;
    double precision;
}wfp;

typedef struct RETURNRESULT {
    double result;
    double strips;
    double num_partitions;
    double num_trapezoid_cal;
    double elapsedTime;
}returnResult;

/*
 * fuctions
 * 1. manager    ----   manager process
 * 2. partition  ----   manager calls it to partition original problems into small ones
 * 3. handout    ----   manager calls it to hand out partitions to workers
 * 4. worker     ----   worker process
 * 5. solve      ----   worker calls it to solve a partition from manager
 */

/****************************************/
/************  manager  *****************/
/****************************************/
void manager(double a, double b, double precision, int size) {
    int num_partition = size - 1, i, from, tag;
    double result = 0, num_trapezoid_cal = 0;
    double num_trapezoid_cal_all[size], min, max, average, elapsedTime = 0;
    char buf[MAXSIZE];
    wfp *tmpt;
    returnResult *r_r = malloc(sizeof(returnResult));
    double width = (b - a)/num_partition;
    for (i = 1; i < size; i++) {
        tmpt = malloc(sizeof(wfp));
        tmpt->a = a + width * (i-1);
        tmpt->b = a + width * i;
        tmpt->precision = precision;
        memset(buf, 0, sizeof(buf));
        memcpy(buf, tmpt, sizeof(wfp));
        msgSendTag(i, buf, sizeof(buf), 1);
    }
    i = size;
    while (i > 1) {
        memset(buf, 0, sizeof(buf));
        memset(r_r, 0, sizeof(returnResult));
        msgRecvTag(&from, buf, sizeof(buf), &tag);
        memcpy(r_r, buf, sizeof(returnResult));
        if (tag == 1) {
            result += r_r->result;
            num_trapezoid_cal += r_r->num_trapezoid_cal;
            num_trapezoid_cal_all[from] = r_r->num_trapezoid_cal;
            elapsedTime = elapsedTime > r_r->elapsedTime?elapsedTime:r_r->elapsedTime;
            i--;
        }
    }
    /*printf("total result is %lf\n", result);*/
    average = num_trapezoid_cal / num_partition;
    min = num_trapezoid_cal_all[1], max = num_trapezoid_cal_all[1];
    for (i = 1; i < size; i++) {
        max = max > num_trapezoid_cal_all[i]?max:num_trapezoid_cal_all[i];
        min = min < num_trapezoid_cal_all[i]?min:num_trapezoid_cal_all[i];
    }
    printf("max num of trapezoid calculation is %lf\n", max);
    printf("min num of trapezoid calculation is %lf\n", min);
    printf("average num of trapezoid calculation is %lf\n", average);
    printf("elapsed time is %lf\n", elapsedTime);
    printf("total result is %lf\n", result);
    
}

/****************************************/
/*************  worker   ****************/
/****************************************/
void worker(double num_thread, double times) {
    double start, end, elapsedTime;
    start = MPI_Wtime();
    char replyBuf[MAXSIZE];
    int src, tag, rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    returnResult *returnPerProcess = malloc(sizeof(returnResult));
    returnPerProcess->result = 0;
    returnPerProcess->strips = 0;
    returnPerProcess->num_partitions = 0;
    returnPerProcess->num_trapezoid_cal = 0;
    
    msgSendTag(0, "1", sizeof("1"), 0);
    msgRecvTag(&src, replyBuf, sizeof(replyBuf), &tag);
    returnResult *returnTmpt = malloc(sizeof(returnResult));
    solve((void *)replyBuf, (void *)returnTmpt, num_thread, times, rank);
    returnPerProcess->result += returnTmpt->result;
    returnPerProcess->strips += returnTmpt->strips;
    returnPerProcess->num_trapezoid_cal += returnTmpt->num_trapezoid_cal;
    returnPerProcess->num_partitions++;
    end = MPI_Wtime();
    elapsedTime = end - start;
    returnPerProcess->elapsedTime = elapsedTime;
    
    /* send integral result to manager */
    memset(replyBuf, 0, sizeof(replyBuf));
    memcpy(replyBuf, returnPerProcess, sizeof(returnResult));
    msgSendTag(0, replyBuf, sizeof(replyBuf), 1);
    /*printf("process %d terminated, num of trapezoid cal is %lf\n", rank, returnPerProcess->num_trapezoid_cal);*/
}

/****************************************/
/**************  solve  *****************/
/****************************************/
/* solve a partition in a process by dividing the partition into smaller sub-partitions and solving each one with a thread */
void* solve(void *partition, void *returnTmpt, int num_thread, int times, int rank) {
    double result, strips, num_trapezoid_cal;
    wfp *wfp_tmpt = (wfp *)partition;
    returnResult *rt = (returnResult *)returnTmpt;
    con_integrate(&f3, wfp_tmpt->a, wfp_tmpt->b, wfp_tmpt->precision, &result, &strips, &num_trapezoid_cal, num_thread, times);
    rt->result = result;
    rt->strips = strips;
    rt->num_trapezoid_cal = num_trapezoid_cal;
    return NULL;
}
