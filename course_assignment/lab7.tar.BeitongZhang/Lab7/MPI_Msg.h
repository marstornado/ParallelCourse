//
//  MPI_Msg.h
//  MPIStart
//
//  Created by zhangNoel on 11/16/14.
//  Copyright (c) 2014 Dartmouth. All rights reserved.
//

#ifndef __MPIStart__MPI_Msg__
#define __MPIStart__MPI_Msg__

#include <stdio.h>
#include "mpi.h"
#include "mpi_func.h"

#define ManagerPID 0

typedef struct _MWArg{
    int argc;
    char ** argv;
    int pid;
    int numProc;
    int boardLimit;
    int genTerminate;
}MWArg;

void MWScheme(void (*manager)(int myID,int numProc,int boardLimit,int genTerminate),
              void (*worker) (int,int), void * mwArgs);

#endif /* defined(__MPIStart__MPI_Msg__) */
