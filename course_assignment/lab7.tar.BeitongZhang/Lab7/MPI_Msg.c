//
//  MPI_Msg.c
//  MPIStart
//
//  Created by zhangNoel on 11/16/14.
//  Copyright (c) 2014 Dartmouth. All rights reserved.
//

#include "MPI_Msg.h"

void MWScheme(void (*Manager)(int,int,int,int), void (*Worker) (int,int), void * mwArgs){
    MWArg * _arg=(MWArg*) mwArgs;
    msgInit(&_arg->argc,&_arg->argv,&_arg->numProc,&_arg->pid);
    if (_arg->pid==ManagerPID){
        Manager(_arg->pid, _arg->numProc, _arg->boardLimit,_arg->genTerminate);
    }
    else
        Worker(_arg->pid, _arg->numProc);
    msgFinalize();
}