//
//  Queens.h
//  MPIStart
//
//  Created by zhangNoel on 11/8/14.
//  Copyright (c) 2014 Dartmouth. All rights reserved.
//

#ifndef __MPIStart__Queens__
#define __MPIStart__Queens__

#define MAXSCALE 16
#include <stdio.h>

typedef struct queenArg{
    int runningMark;
    int startRow;
    int rowLimit;
    int BoardLevel;
    int placeNum;
    int solutionCount;
    int map[MAXSCALE][MAXSCALE];
}QueenArg;

int Queens(void * arg);
int QueensGenerator(void * queue, int n, int termLevel);
void pack(void * buff,void * args);
void unpack(void * buff, void * args);
#endif /* defined(__MPIStart__Queens__) */
