#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include "mpi.h"
#include "mpi_func.h"
#include "lqueue.h"
#include "Queens.h"
#include "MPI_Msg.h"

#define DataTAG 70
#define ResultTAG 71

typedef struct managerArgs{
    int _boardLimit;
    int _genTerminate;
}ManagerArgs;

typedef struct resultTrans{
    int _queenPlacement;
    int _resultCount;
    int _runningMark;
}ResultTrans;

void * generateQueue;
void * resultQueue;

int globPlace=0;
int globSolutionCount=0;
int placeMax=0;
int placeMin=999999;

int generateEndMark1=0;
int processLeft;

void* generator(void* args)
{
    ManagerArgs * Args=args;
    QueensGenerator(generateQueue, Args->_boardLimit, Args->_genTerminate);
    generateEndMark1=1;
    pthread_exit(NULL);
}

void * msgHandler(void * args){
    QueenArg * recvBuf=malloc(sizeof(QueenArg));
    int from,sourceTag;
    while (1) {
        msgRecvTag(&from, recvBuf, sizeof(QueenArg), &sourceTag);
        if (sourceTag==DataTAG) {
            QueenArg * qArg=lqget(generateQueue);
            while (qArg!=NULL||generateEndMark1==0) {
                if (qArg!=NULL){
                    msgSendTag(from, qArg, sizeof(QueenArg), DataTAG);
                    break;
                }
                else{//wait
                    qArg=lqget(generateQueue);
                    continue;
                }
            }
            if(qArg==NULL && generateEndMark1==1){
                recvBuf->runningMark=0;
                msgSendTag(from, recvBuf, sizeof(QueenArg), DataTAG);
            }
        }
        if (sourceTag==ResultTAG) {
            globPlace+=recvBuf->placeNum;
            globSolutionCount+=recvBuf->solutionCount;
            printf("received process result %d %d from process %d\n",recvBuf->placeNum,recvBuf->solutionCount, from);
            processLeft--;
            if (processLeft==0)
                break;
        }
    }
    pthread_exit(NULL);
}

void Manager(int myID,int numProc,int boardLimit,int genTerminate){
    void *status;
    processLeft=numProc-1;
    generateEndMark1=0;
    generateQueue=lqopen();
    resultQueue=lqopen();
    globPlace=0;
    globSolutionCount=0;
    pthread_t generatorThread,msgHandleThread;
    //initial the attribute
    pthread_attr_t thread_Attr;
    pthread_attr_init(&thread_Attr);
    pthread_attr_setdetachstate(&thread_Attr, PTHREAD_CREATE_JOINABLE);
    //create generator thread
    ManagerArgs * genArg=malloc(sizeof(ManagerArgs));
    genArg->_genTerminate=genTerminate;
    genArg->_boardLimit=boardLimit;
    
    pthread_create(&generatorThread, &thread_Attr, generator, genArg);
    pthread_create(&msgHandleThread, &thread_Attr, msgHandler, NULL);
    pthread_join(generatorThread, &status);
    pthread_join(msgHandleThread, &status);
    printf("place: %d, solution: %d\n", globPlace, globSolutionCount);
}

void Worker(int myID,int numProc){
    int localPlace=0,localSolutionCount=0;
    QueenArg * ask4work = malloc(sizeof(QueenArg));
    ask4work->runningMark=1;
    msgSendTag(ManagerPID, ask4work, sizeof(QueenArg), DataTAG);
    while (1) {
        QueenArg * args=malloc(sizeof(QueenArg));
        int rcvSource;
        msgRecv(&rcvSource, args, sizeof(QueenArg));
        if (args->runningMark==1) {
            msgSendTag(ManagerPID, ask4work, sizeof(QueenArg), DataTAG);;
            Queens(args);
            localPlace+=args->placeNum;
            localSolutionCount+=args->solutionCount;
        }
        else{
            QueenArg * rslt=malloc(sizeof(QueenArg));
            rslt->placeNum=localPlace;
            rslt->solutionCount=localSolutionCount;
            //printf("finished in process %d strips=%d\n",localPlace,localSolutionCount);
            msgSendTag(ManagerPID, rslt, sizeof(QueenArg), ResultTAG);
            return;
        }
    }
}

int main(int argc, char * argv[]){
    int pid, numProc, boardLimit=atoi(argv[1]), genTerminate=atoi(argv[2]);
    MWArg * _mwArg=malloc(sizeof(MWArg));
    _mwArg->argc=argc;
    _mwArg->argv=argv;
    _mwArg->boardLimit=boardLimit;
    _mwArg->genTerminate=genTerminate;
    _mwArg->numProc=numProc;
    _mwArg->pid=pid;
    MWScheme(Manager, Worker, _mwArg);
}
