//
//  Queens.c
//  MPIStart
//
//  Created by zhangNoel on 11/8/14.
//  Copyright (c) 2014 Dartmouth. All rights reserved.
//

#include "Queens.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lqueue.h"

#define QUEEN 1
#define NOQUEEN 0


//int BoardLevel;
//int rowLimit;
//int ** map;
//int resultTable;

typedef struct setArg{
    int start;
    int end;
}SetArg;

void setStartNEnd(void * element,void * args){
    ((QueenArg *)element)->startRow=((SetArg *)args)->start;
    ((QueenArg *)element)->rowLimit=((SetArg *)args)->end;
}

int legal_move(QueenArg * arg, int row,int col){
    int i;
    for (i=0; i<arg->BoardLevel; i++) {
        if((arg->map[row][i]==QUEEN && i!=col)||(arg->map[i][col]==QUEEN && i!=row))
            return 0;
    }
    for (i=1; i<arg->BoardLevel; i++) {
        if (row-i>=0 || col-i>=0 || row+i<arg->BoardLevel || col+i<arg->BoardLevel) {
            if (row+i<arg->BoardLevel && col+i<arg->BoardLevel&&arg->map[row+i][col+i]==QUEEN)
                return 0;
            if (row+i<arg->BoardLevel && col-i>=0&&arg->map[row+i][col-i]==QUEEN)
                return 0;
            if (row-i>=0 && col+i<arg->BoardLevel&&arg->map[row-i][col+i]==QUEEN)
                return 0;
            if (row-i>=0 && col-i>=0&&arg->map[row-i][col-i]==QUEEN)
                return 0;
        }
        else
            break;
    }
    return 1;
}

void place_Queen(void* queue, QueenArg * arg,int row, int col){
    if (row<arg->rowLimit && col < arg->BoardLevel) {
        if (legal_move(arg,row, col)) {
            arg->map[row][col]=QUEEN;
            place_Queen(queue,arg,row+1, 0);
            arg->map[row][col]=NOQUEEN;
        }
        place_Queen(queue, arg,row, col+1);
    }
    else if (row==arg->rowLimit) {
        QueenArg * local=malloc(sizeof(QueenArg));//copy the current args and put into the queue
        memcpy(local, arg, sizeof(QueenArg));
        lqput(queue, local);
    }
    return;
}
void place_Queen_work(QueenArg * arg,int row, int col){
    arg->placeNum++;
    if (row<arg->rowLimit && col < arg->BoardLevel) {
        if (legal_move(arg,row, col)) {
            arg->map[row][col]=QUEEN;
            place_Queen_work(arg,row+1, 0);
            arg->map[row][col]=NOQUEEN;
        }
        place_Queen_work(arg,row, col+1);
    }
    else if (row==arg->rowLimit) {
        arg->solutionCount++;
    }
    return;
}
//solve subproblem
int Queens(void * args){
    QueenArg * localArg=(QueenArg*)args;
    place_Queen_work(localArg,localArg->startRow, 0);
    return 1;
}

//generate subproblems
int QueensGenerator(void * queue, int n, int termLevel){
    QueenArg * localArg=malloc(sizeof(QueenArg));
    //resultTable=0;
    localArg->placeNum=0;
    localArg->runningMark=1;
    localArg->solutionCount=0;
    localArg->BoardLevel=n;
    localArg->rowLimit=termLevel;
    localArg->startRow=0;
    memset(localArg->map, 0, MAXSCALE*MAXSCALE*sizeof(int));
    place_Queen(queue,localArg,0, 0);
    SetArg * s=malloc(sizeof(SetArg));
    s->start=termLevel;
    s->end=n;
    lqapply_arg(queue, setStartNEnd, s);
    return 0;
}
