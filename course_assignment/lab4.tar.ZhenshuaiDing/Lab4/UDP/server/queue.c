/*
 * FILE: shop.c
 * DESCRIPTION:
 *      Implementation of a linked-list based queue;
 *
 * Author: Zhenshuai Ding
 * LAST REVISED: Sep-27-2014
 *
 */

#include "./queue.h"

#define ZERO 0

/* create an empty queue */
public void* qopen(void){
    Queue *qp = (Queue *) malloc(sizeof(Queue));
    memset(qp, ZERO, sizeof(Queue));
    return qp;
}

/* deallocate a queue, assuming every element has been removed and deallocated */
public void qclose(void *qp){
    free(qp), qp = NULL;
}

/* put element at end of queue */
public void qput(void *qp, void *elementp){
    /* Get a queue. */
    Queue *q = (Queue *)qp;
    
    /* Initialize a new node. */
    Node *new_node = (Node *) malloc(sizeof(Node));
    
    if (qp == NULL) return;
    
    memset(new_node, ZERO, sizeof(Node));
    new_node->elem = elementp;
    
    /* Check if qp is empty*/
    if ((q->first == NULL) && (q->last == NULL)){
        new_node->prev = NULL;
        q->last = q->first = new_node;
    } else {
        
        /* Add new node to the end of queue. */
        new_node->prev = q->last;
        q->last = q->last->next = new_node;
    }
    
    new_node->next = NULL;
}

/* get first element from a queue */
public void* qget(void *qp){
    /* Get a queue and its first element. */
    Queue *q = (Queue *)qp; Node *e; void *res;
    
    if (qp == NULL) return NULL; e = q->first;
    
    /* Exit if the queue is empty. */
    if (e == NULL) return NULL;
    
    /* Remove the first element from the queue. */
    q->first = e->next;
    
    if (q->first != NULL) q->first->prev = NULL;
    else q->last = NULL;
    
    res = e->elem, free(e);
    return res;
}

/* apply a void function (e.g. a printing fn) to every element of a queue */
public void qapply_plus(void *qp, void (*fn)(void* e1, void* e2d),
                        void *ptr){
    /* Get a queue and its first element. */
    Queue *q = (Queue *)qp; Node *e;
    
    if (qp == NULL) return; e = q->first;
    
    /* Apply function fn to all elements. */
    while(e != NULL){
        (*fn)(e->elem, ptr);
        e = e->next;
    }
}

/* search a queue using a supplied boolean function, returns an element */
public void* qsearch(void *qp,
                     int (*searchfn)(void* elementp, void* keyp),
                     void* skeyp){
    /* Get a queue and its first element. */
    Queue *q = (Queue *)qp; Node *e;
    
    if (qp == NULL) return NULL; e = q->first;
    
    while (e != NULL){
        if ((*searchfn)(e->elem, skeyp))
            return e->elem;
        e = e->next;
    }
    
    /* Cannot find required element */
    return NULL;
}

/* search a queue using a supplied boolean function, removes an element */
public void* qremove(void *qp,
                     int (*searchfn)(void* elementp,void* keyp),
                     void* skeyp){
    /* Get a queue and its first element. */
    Queue *q = (Queue *)qp; Node *e; void *res;
    if (qp == NULL) return NULL; e = q->first;
    
    /* Find the element */
    while (e != NULL){
        if ((*searchfn)(e->elem, skeyp))
            break;
        e = e->next;
    }
    
    /* Cannot find required element. */
    if (e == NULL) return NULL; res = e->elem;
    
    /* Remove element e from the queue. */
    if (e->prev == NULL && e->next == NULL){
        
        /* e is the only element in the queue. */
        q->first = q->last = NULL;
    } else if (e->prev == NULL) {
        
        /* e is the first element in the queue. */
        q->first = e->next; e->next->prev = NULL;
    } else if (e->next == NULL) {
        
        /* e is the last element in the queue. */
        q->last = e->prev; e->prev->next = NULL;
    } else {
        e->prev->next = e->next; e->next->prev = e->prev;
    }
    
    free(e);
    return res;
}

