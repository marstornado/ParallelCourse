/*
 * FILE: server.h
 * DESCRIPTION:
 *
 *
 * Author: Zhenshuai Ding
 * LAST REVISED: Oct-12-2014
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/errno.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <signal.h>
#include "./queue.h"

#define ZERO 0
#define ONE 1
#define MAGIC_TIME 200
#define MAX_LINE_LEN 100
#define MAX_STRING_LEN 500
#define MAX_MSG_NUM 800000
#define SPLIT printf("|-------------------------------------------|\n")
#define ERROR_OCCUR(s) SPLIT, perror(s);\
    exit(EXIT_FAILURE)

typedef struct chatroom_elem_{
    char user_id[MAX_STRING_LEN];
    struct sockaddr_in *user_addr;
} ChatUser;

/* Judge if a client is in the chat room at present. */
int is_in_chatroom(char *clnt_id, void *chat_list);

/* Compare to users' ID to see if they are the same client. */
int cmp_user(void *e1, void *e2);

/* Display current user's ID and append it in a list. */
void display_user(ChatUser *user);

/* Broadcast to all clients in the chat room except the originator. */
void fmsg(char *clnt_id, void *chat_list, char *clnt_msg);

/* Receive ping from a client, reply server is up. */
void fping(char *clnt_id, struct sockaddr_in *addr);

/* Add a client to the chat room. */
void fjoin(char *clnt_id, void *chat_list, struct sockaddr_in *addr);

/* Remove a client from chat room. */
void fleave(char *clnt_id, void *chat_list, struct sockaddr_in *addr);

/* Returns a list of id of all clients in the chat room. */
void fwho(void *chat_list, struct sockaddr_in *addr);

int sock_fd;

