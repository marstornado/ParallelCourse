/*
 * FILE: function.c
 * DESCRIPTION: Process various task and messages 
 * from clients.
 *
 * Author: Zhenshuai Ding
 * LAST REVISED: Oct-12-2014
 *
 */

#include "./function.h"

/* Judge if a client is in the chat room at present. */
int is_in_chatroom(char *clnt_id, void *chat_list){
    return (qsearch(chat_list, (int (*)(void *, void *))cmp_user, clnt_id) != NULL);
}

/* Compare to users' ID to see if they are the same client. */
int cmp_user(void *e1, void *e2){
    return (strcmp(((ChatUser *)e1)->user_id, ((ChatUser *)e2)->user_id) == 0);
}

/* Display current user's ID and append it in a list. */
void show_user(ChatUser *user, char *id_list){
    strcat(id_list, user->user_id); strcat(id_list, ".");
}

/* Broadcast to all clients in the chat room except the originator. */
void broadcast(ChatUser *user, char *broadcast_msg){
    char *clnt_id = malloc(sizeof(char) * MAX_STRING_LEN);
    sscanf(broadcast_msg, "%s", clnt_id);
    
    /* if it is the originator of the message. */
    if (strcmp(clnt_id, user->user_id) != 0)
        if (sendto(sock_fd, broadcast_msg, strlen(broadcast_msg) + 1, 0,
                   (struct sockaddr *)(user->user_addr), (socklen_t)sizeof(*user->user_addr)) < ZERO)
            {ERROR_OCCUR("\n\tFail to sent message to client.\n");}
}

/* Broadcast to all clients in the chat room. */
void fmsg(char *clnt_id, void *chat_list, char *clnt_msg){
    char *broad_msg = malloc(sizeof(char) * MAX_STRING_LEN);
    
    if (is_in_chatroom(clnt_id, chat_list)){
        strcat(broad_msg, clnt_id); strcat(broad_msg, " says : "); strcat(broad_msg, clnt_msg);
        
        qapply_plus(chat_list, (void (*)(void *, void *))broadcast, (void *)broad_msg);
    }
}

/* Receive ping from a client, reply server is up. */
void fping(char *clnt_id, struct sockaddr_in *addr){
    
    char *serv_msg = (char *)malloc(sizeof(char) * MAX_STRING_LEN);
    SPLIT, printf("\n\tServer gets ping from client %s\n", clnt_id);
    sprintf(serv_msg, "\tHello %s, I am Server Mr.D :) Ping success!\n", clnt_id);
    
    if (sendto(sock_fd, serv_msg, strlen(serv_msg) + 1, 0,
               (struct sockaddr *)addr, (socklen_t)sizeof(*addr)) < ZERO)
        {ERROR_OCCUR("\n\tFail to sent message to client.\n");}
}

/* Add a client to the chat room. */
void fjoin(char *clnt_id, void *chat_list,
           struct sockaddr_in *addr){
    
    char *serv_msg = (char *)malloc(sizeof(char) * MAX_STRING_LEN);
    ChatUser *new_user = malloc(sizeof(ChatUser));
    
    if (!is_in_chatroom(clnt_id, chat_list)){
        SPLIT, printf("\n\tUser %s enters chat room.\n", clnt_id);

        strcpy(new_user->user_id, clnt_id);
        new_user->user_addr = addr;
        qput(chat_list, new_user);
        
        sprintf(serv_msg, "\tJoin chat room success.\n");
    } else {sprintf(serv_msg, "\tJoin chat room fail.\n");}
    
    if (sendto(sock_fd, serv_msg, strlen(serv_msg) + 1, 0,
               (struct sockaddr *)addr, (socklen_t)sizeof(*addr)) < ZERO)
        {ERROR_OCCUR("\n\tFail to sent message to client.\n");}
}

/* Remove a client from chat room. */
void fleave(char *clnt_id, void *chat_list,
            struct sockaddr_in *addr){
    char *serv_msg = (char *)malloc(sizeof(char) * MAX_STRING_LEN);
    ChatUser *user = (ChatUser *)qremove(chat_list,
                                         (int (*)(void *, void *))cmp_user, clnt_id);
    
    if (user != NULL){
        SPLIT, printf("\tUser %s leaves chat room.\n", clnt_id);
        
        sprintf(serv_msg, "\n\tLeave chat room success.\n");
        if (sendto(sock_fd, serv_msg, strlen(serv_msg) + 1, 0,
                   (struct sockaddr *)addr, (socklen_t)sizeof(*addr)) < ZERO)
            {ERROR_OCCUR("\n\tFail to sent message to client.\n");}
    }
}

/* Returns a list of id of all clients in the chat room. */
void fwho(void *chat_list, struct sockaddr_in *addr){
    char *id_list = malloc(sizeof(char) * MAX_STRING_LEN);
    strcat(id_list, "User in chat room:");
    qapply_plus(chat_list, (void (*)(void *, void *))show_user, id_list);
    
    if (sendto(sock_fd, id_list, strlen(id_list) + 1, 0,
               (struct sockaddr *)addr, (socklen_t)sizeof(*addr)) < ZERO)
        {ERROR_OCCUR("\n\tFail to sent message to client.\n");}
}

