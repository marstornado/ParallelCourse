
/* 
 * queue.h -- public interface to the queue module
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define public
#define private static

/* Denodes an element in the queue; */
typedef struct _element_of_queue{
    void *elem;
    struct _element_of_queue *prev;
    struct _element_of_queue *next;
} Node;

typedef struct _queue{
    Node *first;
    Node *last;
} Queue;

/* create an empty queue */
public void* qopen(void);        

/* deallocate a queue, assuming every element has been removed and deallocated */
public void qclose(void *qp);   

/* put element at end of queue */
public void qput(void *qp, void *elementp); 

/* get first element from a queue */
public void* qget(void *qp);

/* apply a void function with a parameter to every element of a queue */
public void qapply_plus(void *qp, void (*fn)(void* e1, void* e2),
                        void *ptr);

/* search a queue using a supplied boolean function, returns an element */
public void* qsearch(void *qp, 
		     int (*searchfn)(void* elementp,void* keyp),
		     void* skeyp);

/* search a queue using a supplied boolean function, removes an element */
public void* qremove(void *qp,
		     int (*searchfn)(void* elementp,void* keyp),
		     void* skeyp);


