/*
 * FILE: server.c
 * DESCRIPTION: UDP server that repeatly gets message 
 * from clients, put each message in a task queue, and 
 * processes each message.
 *
 * Author: Zhenshuai Ding
 * LAST REVISED: Oct-10-2014
 *
 */

#include "./server.h"

typedef struct clnt_data_{
    struct sockaddr_in clnt_addr;
    char msg[MAX_STRING_LEN]; /* Recode the message grabed from clients*/
} Cdata;

void *task_queue;
void *chat_list;

void* generator(void *ptr);
void* consumer();

int main(int argc, char *argv[]) {

    struct sockaddr_in serv_addr;
    pthread_t thread;
    uint16_t serv_port;
    
    /* Input failure. */
    if (argc != 2)
        {ERROR_OCCUR("\n\tFailed to get socket port.\n");}
    
    serv_port = atoi(argv[1]);
    memset((char *)&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(serv_port);
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    /* Built server socket. */
    if((sock_fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
        {ERROR_OCCUR("\nFailed to create server socket\n");}
    
    if(bind(sock_fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
        {ERROR_OCCUR("\nBind failed!!\n");}

    SPLIT, printf("\n\tBind success! Socket: %d\n", sock_fd);

    /* Create a generator to fetch messages from clients and
     * assign them to consumer threads by using queue. */
    pthread_create(&thread, NULL, generator, NULL);
    
    /* Creat consumer threads to process clients' requirement. */
    consumer();
    
    return EXIT_SUCCESS;
}


/* Keep reading message for clients and assign them to
 * consumer threads by put them in a task queue. */
void* generator(void *ptr){
    
    int fetch_flag;
    Cdata *clnt_data;
    socklen_t addr_len = sizeof(struct sockaddr_in);
    task_queue = qopen();
    
    while(ONE){
        clnt_data = (Cdata *)malloc(sizeof(Cdata));
        fetch_flag = recvfrom(sock_fd, clnt_data->msg, MAX_STRING_LEN, 0,
                              (struct sockaddr *)&(clnt_data->clnt_addr), &addr_len);
        
        if (fetch_flag < 0) {usleep(MAGIC_TIME);}
        else {qput(task_queue, clnt_data);}
    }
    return NULL;
}

/* Repeatly takes a pending message in the task queue and processes it. */
void* consumer(){
    
    char c_id[MAX_STRING_LEN];
    char buf[MAX_STRING_LEN], msg[MAX_STRING_LEN];
    Cdata *clnt_data = (Cdata *)malloc(sizeof(Cdata));
    chat_list = qopen();
    
    while(ONE){
        clnt_data = (Cdata *)qget(task_queue);
        
        if (clnt_data == NULL) {
            usleep(MAGIC_TIME);
        } else{
            
            switch (clnt_data->msg[0]) {
                case 'M':
                    sscanf(clnt_data->msg, "%s %s %[^\t\n]s", buf, c_id, msg);
                    fmsg(c_id, chat_list, msg); break;
                case 'P':
                    sscanf(clnt_data->msg, "%s %s", buf, c_id);
                    fping(c_id, &(clnt_data->clnt_addr)); break;
                case 'J':
                    sscanf(clnt_data->msg, "%s %s", buf, c_id);
                    fjoin(c_id, chat_list, &(clnt_data->clnt_addr)); break;
                case 'L':
                    sscanf(clnt_data->msg, "%s %s", buf, c_id);
                    fleave(c_id, chat_list, &(clnt_data->clnt_addr)); break;
                case 'W':
                    fwho(chat_list, &(clnt_data->clnt_addr)); break;
                case 'E':
                    sscanf(clnt_data->msg, "%s %s", buf, c_id);
                    fleave(c_id, chat_list, &(clnt_data->clnt_addr));
                    SPLIT, printf("\n\tClient %s disconnect from server.\n", c_id);
            }
        }
    }
    
    return NULL;
}

