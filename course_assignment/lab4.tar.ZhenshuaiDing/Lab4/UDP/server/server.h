/*
 * FILE: server.h
 * DESCRIPTION:
 *
 *
 * Author: Zhenshuai Ding
 * LAST REVISED: Oct-12-2014
 *
 */

#include <pthread.h>
#include "./function.h"



#define CONSUMER_NUM 1
