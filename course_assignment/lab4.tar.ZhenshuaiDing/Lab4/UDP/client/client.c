/*
 * FILE: client.c
 * DESCRIPTION: An UPD client that repeatly reads input
 * from keyboard and supports commands /ping, /join, /leave
 * and /who.
 *
 *
 * Author: Zhenshuai Ding
 * LAST REVISED: Oct-10-2014
 *
 */

#include "./client.h"

struct sockaddr_in serv_addr;

pthread_t response;

int try_time;
char c_msg[MAX_STRING_LEN]; /* The message that send to the server. */
int sock_fd, connection_flag;

void *receiver(void *sock_fd);
void msg_take(const char *c_id, const int sock_fd);

void handler(int sig){

    signal(SIGALRM, SIG_IGN);          /* ignore this signal       */
    printf("\nServer Not Available\n");
    try_time++;
    sendto(sock_fd, &c_msg, sizeof(c_msg), ZERO,
           (struct sockaddr *)&serv_addr, sizeof(struct sockaddr));
    
    if (try_time < 3) alarm(FIVE);
    else {
        connection_flag = ZERO;
        printf("\nConnection Broken\n");
        close(sock_fd); exit(EXIT_SUCCESS);
    }
    signal(SIGALRM, handler);     /* reinstall the handler    */
}

int main(int argc, char *argv[]) {
    
    
    char *c_id, *ip;
    uint16_t serv_port;
    
    /* Input failure. */
    if (argc != 4)
        {ERROR_OCCUR("\n\tFailed to get client ID, IPt and socket port.\n");}
    
    /* Read parameters from command line. */
    c_id = argv[1], ip = argv[2], serv_port = atoi(argv[3]);
    
    memset((char *)&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(serv_port);
    serv_addr.sin_addr.s_addr = inet_addr(ip);
    
    /* Built connection to server. */
    if((sock_fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
        {ERROR_OCCUR("\n\tFailed to open client socket.\n");}
    
    connection_flag = ONE;
    
    /* Built a message receiver to get message from server. */
    pthread_create(&response, NULL, receiver, (void *)&sock_fd);

    /* Repeatedly take integers from the keyboard. */
    msg_take(c_id, sock_fd);
    
    return EXIT_SUCCESS;
}

/* Get response from server. */
void *receiver(void *sock_fd){
    char s_msg[MAX_STRING_LEN];
    
    try_time = ZERO;
    signal(SIGALRM, handler);
    alarm(FIVE);
    
    while(connection_flag){
        recvfrom(*((int *)sock_fd), s_msg, MAX_STRING_LEN, 0, NULL, NULL);
        alarm(0);
        SPLIT, printf("\nServer reply: %s\n", s_msg);
    }
    
    return NULL;
}

/* Repeatedly take messages from the keyboard. Sent them
 * to the server. */
void msg_take(const char *c_id, const int sock_fd){
    char line[MAX_STRING_LEN];
    
    socklen_t addr_len = sizeof(serv_addr);
    int sent_flag;
    
    while(connection_flag){
        SPLIT, printf("\n\t Enter a Message: \n");
        fgets(line, MAX_LINE_LEN, stdin);
        /*try_time = ZERO;*/
        
        if (line[0] == '/'){
            if (!strncmp(line, "/ping", 5))
                sprintf(c_msg, "P %s", c_id);
            else if (!strncmp(line, "/join", 5))
                    sprintf(c_msg, "J %s", c_id);
            else if (!strncmp(line, "/leave", 6))
                    sprintf(c_msg, "L %s", c_id);
            else if (!strncmp(line, "/who", 4))
                    sprintf(c_msg, "W");
            else if (!strncmp(line, "/exit", 5)){
                    /* Client terminated. It send a message to server to notify
                     * that it is exited. Kill the receiver thread and close the
                     * socket, then exit. */
                
                    sprintf(c_msg, "E %s", c_id);
                    sendto(sock_fd, &c_msg, sizeof(c_msg), ZERO,
                       (struct sockaddr *)&serv_addr, addr_len), close(sock_fd);
                    pthread_cancel(response), pthread_join(response, NULL);
                    SPLIT, printf("\nDisconnect from server, socket closed.\n");
                    exit(EXIT_SUCCESS);
                }
        } else {
            sprintf(c_msg, "M %s %s", c_id, line);
        }
        
        sent_flag = sendto(sock_fd, &c_msg, sizeof(c_msg), ZERO,
                          (struct sockaddr *)&serv_addr, addr_len);
        
        if (sent_flag < 0) {
            ERROR_OCCUR("\n\tFailed to sent server message.\n");}
        
        SPLIT, printf("\n\tClient %s Send Message: %s\n", c_id, c_msg);
    }
}
