/*
 * FILE: client.h
 * DESCRIPTION:
 *
 *
 * Author: Zhenshuai Ding
 * LAST REVISED: Oct-12-2014
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <netdb.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/errno.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <signal.h>

#define ZERO 0
#define ONE 1
#define MAX_LINE_LEN 100
#define MAX_STRING_LEN 500
#define MAGIC_TIME 200
#define SPLIT printf("|-------------------------------------------|\n")
#define ERROR_OCCUR(s) SPLIT, perror(s);\
        exit(EXIT_FAILURE)

int connection_flag;
