/*
 * FILE: client.c
 * DESCRIPTION: An UPD client that repeatly reads input
 * from keyboard and supports commands /ping, /join, /leave
 * and /who.
 *
 *
 * Author: Zhenshuai Ding
 * LAST REVISED: Oct-10-2014
 *
 */

#include "./client.h"

struct sockaddr_in serv_addr;

void *receiver(void *sock_fd);
void msg_take(const char *c_id, const int sock_fd);

int main(int argc, char *argv[]) {
    
    char *c_id, *ip;
    uint16_t serv_port;
    int sock_fd; pthread_t response;
    
    /* Input failure. */
    if (argc != 4)
        {ERROR_OCCUR("\n\tFailed to get client ID, IPt and socket port.\n");}
    
    /* Read parameters from command line. */
    connection_flag = ONE, c_id = argv[1], ip = argv[2], serv_port = atoi(argv[3]);
    
    memset((char *)&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(serv_port);
    serv_addr.sin_addr.s_addr = inet_addr(ip);
    
    /* Built connection to server. */
    if ((sock_fd = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < ZERO)
        {ERROR_OCCUR("\n\tFailed to open client socket.\n");}
    
    if (connect(sock_fd, (struct sockaddr*)&(serv_addr), sizeof(serv_addr)) < ZERO)
        {ERROR_OCCUR("\n\tFailed to connect server.\n");}
        
    /* Built a message receiver to get message from server. */
    pthread_create(&response, NULL, receiver, (void *)&sock_fd);

    /* Repeatedly take integers from the keyboard. */
    msg_take(c_id, sock_fd);
    
    pthread_join(response, NULL);
    
    return EXIT_SUCCESS;
}

/* Get response from server. */
void *receiver(void *sock_fd){
    char s_msg[MAX_STRING_LEN];
    
    while(connection_flag){
        
        if (recv(*((int *)sock_fd), s_msg, MAX_STRING_LEN, 0) < ZERO) break;
            /* ERROR_OCCUR("\n\tFailed to retrieve server message.\n");*/
        else SPLIT, printf("\nServer reply: %s\n", s_msg);
        
        if (strcmp(s_msg, "Server Terminate!") == ZERO)
            exit(EXIT_SUCCESS);
    }
    
    printf("Disconnect from server, socket closed.\n");
    
    return NULL;
}

/* Repeatedly take messages from the keyboard. Sent them
 * to the server. */
void msg_take(const char *c_id, const int sock_fd){
    char line[MAX_STRING_LEN];
    char c_msg[MAX_STRING_LEN]; /* The message that send to the server. */
    
    while(connection_flag){
        SPLIT, printf("\n\t Enter a Message: \n");
        fgets(line, MAX_LINE_LEN, stdin);
        
        if (line[0] == '/'){
            if (!strncmp(line, "/ping", 5))
                sprintf(c_msg, "P %s", c_id);
            else if (!strncmp(line, "/join", 5))
                sprintf(c_msg, "J %s", c_id);
            else if (!strncmp(line, "/leave", 6))
                sprintf(c_msg, "L %s", c_id);
            else if (!strncmp(line, "/who", 4))
                sprintf(c_msg, "W %s", c_id);
            else if (!strncmp(line, "/exit", 5)){
                /* Client terminated. It send a message to server to notify
                    * that it is exited. Kill the receiver thread and close the
                    * socket, then exit. */
                
                sprintf(c_msg, "E %s", c_id), connection_flag = ZERO;
            } else if (!strncmp(line, "/close all", 10)){
                /* The message means we will close all of our server and
                 * clients. The server will push all clients out of the 
                 * chat room then terminate itself. */
                
                sprintf(c_msg, "T %s", c_id), connection_flag = ZERO;
            }
        } else {
            sprintf(c_msg, "M %s %s", c_id, line);
        }
        
        if (send(sock_fd, &c_msg, sizeof(c_msg), ZERO) < ZERO) {
            ERROR_OCCUR("\n\tFailed to sent server message.\n");}
        
        SPLIT, printf("\n\tClient %s Send Message: %s\n", c_id, c_msg);
    }
}
