/*
 * FILE: server.h
 * DESCRIPTION:
 *
 *
 * Author: Zhenshuai Ding
 * LAST REVISED: Oct-12-2014
 *
 */

#include <math.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/errno.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <signal.h>
#include "./lqueue.h"

#define ZERO 0
#define ONE 1
#define MAGIC_TIME 200
#define MAX_LINE_LEN 100
#define MAX_STRING_LEN 500
#define MAX_MSG_NUM 800000
#define SPLIT printf("|-------------------------------------------|\n")
#define ERROR_OCCUR(s) SPLIT, perror(s);\
    exit(EXIT_FAILURE)

typedef struct chatroom_elem_{
    char user_id[MAX_STRING_LEN];
    int sock_fd;
} ChatUser;

/* Broadcast to all clients in the chat room except the originator. */
void fmsg(char *clnt_id, void *chat_list, char *clnt_msg);

/* Receive ping from a client, reply server is up. */
void fping(char *clnt_id, int user_socket);

/* Add a client to the chat room. */
void fjoin(char *clnt_id, void *chat_list, int user_socket);

/* Remove a client from chat room. */
void fleave(char *clnt_id, void *chat_list);

/* Returns a list of id of all clients in the chat room. */
void fwho(void *chat_list, int user_socket);

/* Push all client out of the chat room.*/
void fterminate(void *chat_list);
