
/* 
 * lqueue.h -- public interface to the pthread controled queue module
 */
#include <pthread.h>
#include "./queue.h"

#define public
#define private static
#define QL(lqp) Lqueue * lq = (Lqueue *)lqp; void *elem;\
                pthread_mutex_lock(&(lq->lock))

#define QUL pthread_mutex_unlock(&(lq->lock))

/* Denodes an element in the queue; */
typedef struct _locked_queue{
    void *qp;
    pthread_mutex_t lock;
} Lqueue;


/* create an empty queue */
public void* lqopen(void);

/* deallocate a queue, assuming every element has been removed and deallocated */
public void lqclose(void *lqp);

/* put element at end of queue */
public void lqput(void *lqp, void *elementp);

/* get first element from a queue */
public void* lqget(void *lqp);

/* apply a void function with a parameter to every element of a queue */
public void lqapply_plus(void *lqp, void (*fn)(void* e1, void* e2), void *ptr);

/* search a queue using a supplied boolean function, returns an element */
public void* lqsearch(void *lqp, int (*searchfn)(void* elementp,void* keyp), void* skeyp);

/* search a queue using a supplied boolean function, removes an element */
public void* lqremove(void *lqp, int (*searchfn)(void* elementp,void* keyp), void* skeyp);

