/*
 * FILE: function.c
 * DESCRIPTION: Process various task and messages 
 * from clients.
 *
 * Author: Zhenshuai Ding
 * LAST REVISED: Oct-12-2014
 *
 */

#include "./function.h"

/* Compare to users' ID to see if they are the same client. */
int cmp_user(void *e1, void *e2){
    
    return (strcmp(((ChatUser *)e1)->user_id, ((ChatUser *)e2)->user_id) == 0);
}

/* Display current user's ID and append it in a list. */
void show_user(ChatUser *user, char *id_list){
    
    strcat(id_list, user->user_id); strcat(id_list, ".");
}

/* Judge if a client is in the chat room at present. */
int is_in_chatroom(char *clnt_id, void *chat_list){
    
    return (lqsearch(chat_list, (int (*)(void *, void *))cmp_user, clnt_id) != NULL);
}

/* Broadcast to all clients in the chat room except the originator. */
void broadcast(ChatUser *user, char *broadcast_msg){
    
    char *clnt_id = malloc(sizeof(char) * MAX_STRING_LEN);
    sscanf(broadcast_msg, "%s", clnt_id);
    
    /* if it is the originator of the message. */
    if (strcmp(clnt_id, user->user_id) != 0)
        if (send(user->sock_fd, broadcast_msg, strlen(broadcast_msg) + 1, ZERO) < ZERO)
            {ERROR_OCCUR("\n\tFail to sent message to client.\n");}
}

/* Broadcast to all clients in the chat room. */
void fmsg(char *clnt_id, void *chat_list, char *clnt_msg){
    
    char *broad_msg = malloc(sizeof(char) * MAX_STRING_LEN);
    
    if (is_in_chatroom(clnt_id, chat_list)){
        strcat(broad_msg, clnt_id); strcat(broad_msg, " says : "); strcat(broad_msg, clnt_msg);
        
        lqapply_plus(chat_list, (void (*)(void *, void *))broadcast, (void *)broad_msg);
    }
}

/* Receive ping from a client, reply server is up. */
void fping(char *clnt_id, int user_socket){
    
    char *serv_msg = (char *)malloc(sizeof(char) * MAX_STRING_LEN);
    SPLIT, printf("\n\tServer gets ping from client %s\n", clnt_id);
    
    sprintf(serv_msg, "\tHello %s, I am Server Mr.D :) Ping success!\n", clnt_id);
    
    if (send(user_socket, serv_msg, strlen(serv_msg) + 1, ZERO) < ZERO)
        {ERROR_OCCUR("\n\tFail to sent message to client.\n");}
}

/* Add a client to the chat room. */
void fjoin(char *clnt_id, void *chat_list, int user_socket){
    
    char *serv_msg = (char *)malloc(sizeof(char) * MAX_STRING_LEN);
    ChatUser *new_user = malloc(sizeof(ChatUser));
    
    if (!is_in_chatroom(clnt_id, chat_list)){
        SPLIT, printf("\n\tUser %s enters chat room.\n", clnt_id);

        strcpy(new_user->user_id, clnt_id);
        new_user->sock_fd = user_socket;
        lqput(chat_list, new_user);
        
        sprintf(serv_msg, "\tJoin chat room success.\n");
    } else {sprintf(serv_msg, "\tJoin chat room fail.\n");}
    
    if (send(user_socket, serv_msg, strlen(serv_msg) + 1, ZERO) < ZERO)
        {ERROR_OCCUR("\n\tFail to sent message to client.\n");}
}

/* Remove a client from chat room. */
void fleave(char *clnt_id, void *chat_list){
    
    char *serv_msg = (char *)malloc(sizeof(char) * MAX_STRING_LEN);
    ChatUser *user = (ChatUser *)lqremove(chat_list,
                                         (int (*)(void *, void *))cmp_user, clnt_id);
    
    if (user != NULL){
        SPLIT, printf("\tUser %s leaves chat room.\n", clnt_id);
        
        sprintf(serv_msg, "\n\tLeave chat room success.\n");
        if (send(user->sock_fd, serv_msg, strlen(serv_msg) + 1, ZERO) < ZERO)
            {ERROR_OCCUR("\n\tFail to sent message to client.\n");}
    }
}

/* Returns a list of id of all clients in the chat room. */
void fwho(void *chat_list, int user_socket){
    
    char *id_list = malloc(sizeof(char) * MAX_STRING_LEN);
    
    strcat(id_list, "User in chat room:");
    
    lqapply_plus(chat_list, (void (*)(void *, void *))show_user, id_list);
    
    if (send(user_socket, id_list, strlen(id_list) + 1, ZERO) < ZERO)
        {ERROR_OCCUR("\n\tFail to sent message to client.\n");}
}

/* Push all client out of the chat room.*/
void fterminate(void *chat_list){
    ChatUser *user;
    
    while((user = (ChatUser *)(lqget(chat_list))) != NULL){
        fleave(user->user_id, chat_list);
        send(user->sock_fd, "Server Terminate!", 18, ZERO);
    }
}

