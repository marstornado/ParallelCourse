/*
 * FILE: server.c
 * DESCRIPTION: TCP server that repeatly gets message 
 * from clients, put each message in a task queue, and 
 * processes each message.
 *
 * Author: Zhenshuai Ding
 * LAST REVISED: Oct-10-2014
 *
 */

#include "./server.h"

int main(int argc, char *argv[]) {

    int sock_fd;
    struct sockaddr_in serv_addr;
    uint16_t serv_port;
    
    /* Input failure. */
    if (argc != 2)
        {ERROR_OCCUR("\n\tFailed to get socket port.\n");}
    
    serv_port = atoi(argv[1]);
    memset((char *)&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(serv_port);              /* Local port. */
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);      /* Any incoming add. */

    /* Built server socket. */
    if((sock_fd = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < ZERO)
        {ERROR_OCCUR("\nFailed to create server socket\n");}
    
    if(bind(sock_fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < ZERO)
        {ERROR_OCCUR("\nBind failed!!\n");}
    
    if (listen(sock_fd, BACKLOG) < ZERO) {ERROR_OCCUR("\nFailed to listen.\n");}
    
    listener(sock_fd);
    
    return EXIT_SUCCESS;
}
