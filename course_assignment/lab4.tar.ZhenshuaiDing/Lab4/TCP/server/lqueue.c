/*
 * FILE: lqueue.c
 * DESCRIPTION:
 *      Implementation of a linked-list based queue;
 *
 * Author: Zhenshuai Ding
 * LAST REVISED: Sep-27-2014
 *
 */

#include "./lqueue.h"

#define ZERO 0

/* create an empty queue */
public void* lqopen(void){
    
    Lqueue *lqp = (Lqueue *)malloc(sizeof(Lqueue));
    
    pthread_mutex_init(&(lqp->lock), NULL);
    lqp->qp = qopen();
    
    return lqp;
}

/* deallocate a queue, assuming every element has been removed and deallocated */
public void lqclose(void *lqp){
    
    pthread_mutex_destroy(&(((Lqueue *)lqp)->lock));
    qclose(((Lqueue *)lqp)->qp), free(lqp);
}

/* put element at end of queue */
public void lqput(void *lqp, void *elementp){
    
    QL(lqp); qput(lq->qp, elementp); QUL;
}

/* get first element from a queue */
public void* lqget(void *lqp){
    
    QL(lqp); elem = qget(lq->qp); QUL;
    return elem;
}

/* apply a void function (e.g. a printing fn) to every element of a queue */
public void lqapply_plus(void *lqp, void (*fn)(void* e1, void* e2d), void *ptr){
    
    QL(lqp); qapply_plus(lq->qp, fn, ptr); QUL;
}

/* search a queue using a supplied boolean function, returns an element */
public void* lqsearch(void *lqp, int (*searchfn)(void* elementp, void* keyp), void* skeyp){
    
    QL(lqp); elem = qsearch(lq->qp, searchfn, skeyp); QUL;
    
    return elem;
}

/* search a queue using a supplied boolean function, removes an element */
public void* lqremove(void *lqp, int (*searchfn)(void* elementp,void* keyp), void* skeyp){
    
    QL(lqp); elem = qremove(lq->qp, searchfn, skeyp); QUL;
    
    return elem;
}

