/*
 * FILE: listener.c
 * DESCRIPTION: TCP server that repeatly gets message 
 * from clients, put each message in a task queue, and 
 * processes each message.
 *
 * Author: Zhenshuai Ding
 * LAST REVISED: Oct-10-2014
 *
 */
#include "./listener.h"

/* Repeatly takes a pending message in the task queue and processes it. */
void* consumer(void *ptr);
void ternimate_server();

/* Accept a connection, create a generator and a consumer 
 * thread for this client to handle commands and messages. */
void listener(int sock_fd){
    
    Tdata *t_data;
    
    chat_list = lqopen();
    thread_queue =lqopen();
    
    while(ONE){
        
        t_data = (Tdata *)malloc(sizeof(Tdata));
        t_data->threadID = (pthread_t *)malloc(sizeof(pthread_t));
        lqput(thread_queue, (void *)t_data);
        
        if((t_data->user_socket = accept(sock_fd, NULL, NULL)) < ZERO)
            {ERROR_OCCUR("\nFailed to accpet client connection.\n");}
        
        /* Creat consumer threads to process clients' requirement. */
        pthread_create(t_data->threadID, NULL, consumer, (void *)t_data);
    }
    
    close(sock_fd);
}

/* Keep reading messages and commands for clients. */
void* consumer(void *ptr){
    
    Tdata *t_data = (Tdata *)ptr;
    Cdata *clnt_data;
    char c_id[MAX_STRING_LEN], buf[MAX_STRING_LEN], msg[MAX_STRING_LEN];
    
    while(ONE){
        clnt_data = (Cdata *)malloc(sizeof(Cdata));
        
        if (recv(t_data->user_socket, clnt_data->msg, MAX_STRING_LEN,
                 ZERO) < ZERO) usleep(MAGIC_TIME);
        else {
            sscanf(clnt_data->msg, "%s %s", buf, c_id);
            
            switch (clnt_data->msg[ZERO]) {
                case 'P': fping(c_id, t_data->user_socket); break;
                case 'J': fjoin(c_id, chat_list, t_data->user_socket); break;
                case 'L': fleave(c_id, chat_list); break;
                case 'W': fwho(chat_list, t_data->user_socket); break;
                case 'M':
                    sscanf(clnt_data->msg, "%s %s %[^\t\n]s", buf, c_id, msg);
                    fmsg(c_id, chat_list, msg); break;
                case 'E':
                    
                    fleave(c_id, chat_list);
                    SPLIT, printf("\n\tClient %s disconnect from server.\n", c_id);
                    
                    close(t_data->user_socket);
                    pthread_exit(NULL);
                    break;
                    
                case 'T':
                    
                    /* Push all client out of the chat room. */
                    fterminate(chat_list);
                    
                    /* Marks the server has been ternimated. */
                    ternimate_server();
                    pthread_exit(NULL);
            }
        }
    }
    return NULL;
}

/* Kill all threads and close all socket and the port.*/
void ternimate_server(){
    
    Tdata *t_data;
    
    while ((t_data = lqget(thread_queue)) != NULL){
        
        close(t_data->user_socket);
        
        if (*t_data->threadID != pthread_self())
            pthread_cancel(*t_data->threadID), pthread_join(*t_data->threadID, NULL);
        
    }
    
    SPLIT, printf("\n\tServer are ternimate.\n\tAll connections are broken.\n");
    exit(EXIT_SUCCESS);
}

