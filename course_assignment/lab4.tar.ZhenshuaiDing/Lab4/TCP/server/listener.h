/*
 * FILE: listener.h
 * DESCRIPTION:
 *
 *
 * Author: Zhenshuai Ding
 * LAST REVISED: Oct-12-2014
 *
 */

#include "./function.h"


#define MAX_CLIENT 900

typedef struct clnt_data_{
    struct sockaddr_in clnt_addr;
    char msg[MAX_STRING_LEN];       /* Recode the message grabed from clients*/
} Cdata;

typedef struct thread_data_{
    int user_socket;
    pthread_t *threadID;       /* Recode the message grabed from clients*/
} Tdata;

/* The server maintains a chat room list recording the
 * current user in the room. */
void *chat_list;

void listener(int sock_fd);

void *thread_queue;
