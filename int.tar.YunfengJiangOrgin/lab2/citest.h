//
//  citest.h
//  lab2_test3
//
//  Created by mastornado on 10/7/14.
//  Copyright (c) 2014 mastornado. All rights reserved.
//

#ifndef __lab2_test3__citest__
#define __lab2_test3__citest__

#include <stdio.h>

#endif /* defined(__lab2_test3__citest__) */
