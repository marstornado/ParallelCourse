#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    void *key;
    struct Node* next;
}Node,*NodePtr;

typedef struct Queuelist{
    Node * first;
    Node * end;
}Queuelist, *QuePtr;

void* qopen(void) {
    QuePtr Que = (QuePtr)malloc(sizeof(Queuelist));
    Que->first  = (Node*)malloc(sizeof(Node));
    Que->end = Que->first;
    Que->first->key = NULL;
    Que->first->next = NULL;
    return Que;
}

void qclose(void *qp) {
    QuePtr qpPtr;
    qpPtr = (QuePtr)qp;
    while(qpPtr->first) {
        qpPtr->end=qpPtr->first->next;
        free(qpPtr->first);
        qpPtr->first = qpPtr->end;
    }
    qpPtr->first=qpPtr->end = NULL;
}

void qput(void *qp, void *elementp) {
    QuePtr qpPtr;
    qpPtr = (QuePtr)qp;
    if(elementp == NULL || qp == NULL) {
        return;
    }
    else {
        NodePtr p = (NodePtr)malloc(sizeof(Node));
        p->key = elementp;
        p->next = NULL;
        qpPtr->end->next = p;
        qpPtr->end=p;
    }
}

void* qget(void *qp) {
    QuePtr qpPtr;
    NodePtr np;
    void* elm;
    qpPtr = (QuePtr)qp;
    if(qpPtr == NULL) {
        return NULL;
    }
    else if(qpPtr->first == qpPtr->end) {
        return NULL;
    }
    else if(qpPtr->first->next->key == NULL) {
        return NULL;
    }
    else {
        np = qpPtr->first->next;
        if(qpPtr->first->next->next == NULL) {
            qpPtr->first->next = NULL;
            qpPtr->end = qpPtr->first;
        }
        else {
            qpPtr->first->next = qpPtr->first->next->next;
        }
        elm = np->key;
        return elm;
    }
}

void qapply(void *qp, void (*fn)(void* elementp)) {
    QuePtr qpPtr;
    NodePtr p;
    qpPtr = (QuePtr)qp;
    if(qpPtr->first == qpPtr->end || qpPtr->first->next == NULL) {
        return;
    }
    p = qpPtr->first->next;
    while(p != NULL) {
        fn(p->key);
        p = p->next;
    }
}

void* qsearch(void *qp, int(*searchfn)(void* elementp, void* keyp), void* skeyp) {
    QuePtr qpPtr;
    NodePtr p;
    qpPtr = (QuePtr)qp;
    if(qpPtr->first == qpPtr->end) {
        return NULL;
    }
    p = qpPtr->first->next;
    while(p != NULL) {
        if(searchfn(p->key, skeyp)){
            return p->key;
        }
        p = p->next;
    }
    return NULL;
}

void* qremove(void *qp, int(*searchfn)(void* elementp, void* keyp), void* skeyp) {
    NodePtr p, last;
    QuePtr qpPtr;
    void* elm;
    qpPtr = (QuePtr)qp;
    if(qpPtr->first == qpPtr->end) {
        return NULL;
    }
    else {
        p = qpPtr->first->next;
    }
    last = qpPtr->first;
    while(p != NULL) {
        if(searchfn(p->key, skeyp)) {
            if( p == qpPtr->end) {
                if(qpPtr->first->next == p) {
                    elm = p->key;
                    qpPtr->end = qpPtr->first;
                    qpPtr->first->next = NULL;
                    return elm;
                }
                else {
                    last->next = NULL;
                    qpPtr->end = last;
                    elm = p->key;
                    free(p);
                    return elm;
                }
            }
            else if(p == qpPtr->first->next){
                    elm = p->key;
                    qpPtr->first->next = p->next;
                    return elm;
            }
            else {
                last->next = last->next->next;
                elm = p->key;
                free(p);
                return elm;
            }
        }
        last = p;
        p = p->next;
    }
    return NULL;
}

void qconcat(void *q1p, void *q2p) {
    QuePtr q1pPtr, q2pPtr;
    q1pPtr = (QuePtr)q1p;
    q2pPtr = (QuePtr)q2p;
    if(q1p ==NULL || q2p ==NULL) {
        return;
    }
    else if(q2pPtr->first == q2pPtr->end) {
        return;
    }
    else if(q1pPtr->first == q1pPtr->end) {
        q1pPtr->first = q2pPtr->first;
        q1pPtr->end = q2pPtr->end;
        q2pPtr->first = NULL;
        q2pPtr->end = NULL;
    }
    else {
        q1pPtr->end->next = q2pPtr->first->next;
        q1pPtr->end = q2pPtr->end;
        q2pPtr->end = q2pPtr->first;
        q2pPtr->first->key = NULL;
        q2pPtr->first->next = NULL;
    }
}
