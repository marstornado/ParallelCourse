//
//  citest.c
//  para_lab2
//
//  Created by mastornado on 10/5/14.
//  Copyright (c) 2014 mastornado. All rights reserved.
//
#include "citest.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include <string.h>
#include "integrate.h"
#include "queue.h"


pthread_mutex_t mutex1 = PTHREAD_MUTEX_INITIALIZER;
int numThread;
int runTimes;
double integRes;
double allStrips;
void* qBegin;
int flag;

typedef struct parlist {
    double (*f)(double x);
    double a;
    double b;
    double precision;
    double *result;
    double *strips;
} parlist_t, *parPtr;


typedef struct parQue {
    double (*f)(double x);
    double a;
    double b;
    double precision;
    double *result;
    double *strips;
    int runNum;
}parQue_t;

double func1(double x) {
    return x + 5.0;
}

double func2(double x) {
    return 2*x*x+9*x+4;
}

void *runIntegate(void *x) {
    parQue_t *y;
    pthread_mutex_lock( &mutex1 );
    y = (parQue_t *)qget(x);
    pthread_mutex_unlock( &mutex1 );
    while(y != NULL || flag > 0) {
        if(y != NULL) {
            integrate(y->f, y->a, y->b, y->precision, y->result, y->strips);
            pthread_mutex_lock( &mutex1 );
            if(y->runNum == numThread*15) {
                flag = 0;
            }
            integRes += *(y->result);
            allStrips += *(y->strips);
            y = (parQue_t *)qget(x);
            pthread_mutex_unlock( &mutex1 );
        }
    }
    return NULL;
}

void *generator(void *x) {
    parlist_t *y;
    parQue_t  *qpar;
    double a,b;
    int i;
    
    integRes = 0;
    allStrips = 0;
    y = (parlist_t *)x;
    a = y->a;
    b = y->b;

    for(i=0; i<numThread*15; i++){
        qpar = (parQue_t *)malloc((sizeof(parQue_t)));
        qpar->a = a + ((b-a)/(numThread*15))*i;
        qpar->b = a + ((b-a)/(numThread*15))*(i+1);
        qpar->strips = (double *)malloc(sizeof(double));
        qpar->result = (double *)malloc(sizeof(double));
        qpar->precision = y->precision;
        qpar->f = y->f;
        qpar->runNum = i+1;
        pthread_mutex_lock( &mutex1 );
        qput(qBegin, qpar);
        pthread_mutex_unlock( &mutex1 );
    }
    //pthread_exit(qBegin);
    return NULL;
}

int main (int argc, char *argv[]) {
    
    double a, b, precision, *result, *strip;
    double (*funct)(double x);
    parlist_t *fpar;
    int i, rc;
    
    if(argc < 4) {
        //return 0;
        a = 5;
        b = 40;
        funct = func1;
        precision = 0.01;
        numThread = 1;
    }
    else{
        if(atoi(argv[1]) == 1) {
            funct = func1;
        } else if(atoi(argv[1]) == 2) {
            funct = func2;
        }else {
            funct = func1;
        }
        a = atof(argv[2]);
        b = atof(argv[3]);
        numThread = 10;
        precision = 0.01;
        if(argc > 4) {
            for(i = 4; i< argc; i++){
                if(!strcmp(argv[i], "-m")) {
                    numThread = atoi(argv[i+1]);
                }
                else if(!strcmp(argv[i], "-p")){
                    precision = atof(argv[i+1]);
                }
            }
        }
    }
    pthread_t threads[numThread+1];
    int thread_args[numThread+1];
    flag = 1;
    
    qBegin = qopen();
    fpar = (parlist_t *)malloc((sizeof(parlist_t)));
    result = (double *)malloc(sizeof(double));
    strip = (double *)malloc(sizeof(double));
    fpar->a = a;
    fpar->b = b;
    fpar->f = funct;
    fpar->precision = precision;
    fpar->result = &integRes;
    fpar->strips = &allStrips;

    
    //create queue
    rc = pthread_create(&threads[0], NULL, generator, (void *)fpar);
    //rc = pthread_join(threads[0], NULL);
    //printf("In main: thread %d is complete\n", 0);
    
    //create all threads
    for( i=1; i<numThread+1; i++) {
        thread_args[i] = i;
         rc = pthread_create(&threads[i], NULL, runIntegate, (void *)qBegin);
    }
    
    // wait for each thread to complete
    for (i=0; i<numThread+1; ++i) {
         //printf("result is %.2f \n", (*result));
        //printf("result is %.2f \n", (*strip));
        rc = pthread_join(threads[i], NULL);
        //printf("In main: thread %d is complete\n", i);
    }
    printf("intege is %f \n", integRes);
    printf("strips is %f \n", allStrips);
    qclose(qBegin);
    return 0;
}
