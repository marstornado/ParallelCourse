#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "queue.h"
#include <pthread.h>
#include "./lockQueue.h"

#define BUF_SIZE 1024000
#define MAXPENDING 100
#define THREADNUM 100

typedef struct message
{
    unsigned int msg_len;
    char name[20];
    char mtext[BUF_SIZE];
}mes_t, *mes_p;


typedef struct clients {
    char name[30];
    int cli_fd;
    int id;
} clients_t, *clients_ptr;

typedef struct servMes {
    char name[30];
    char mtext[BUF_SIZE];
    int cli_fd;
}servM_t, *servM_p;

struct sockaddr_in serv_addr, cli_addr;
socklen_t socSize = sizeof(struct sockaddr_in);
int sockfd, port, flag;
int idNum = 0;
clients_t *client1;
void *qclient; //, *qmessage;
pthread_t threadP[THREADNUM];
//mes_t *mes_buf;
//servM_t *servmes, *servmes2;

void itemPrint(void* elementp){
    clients_t *t = (clients_t*)elementp;
    if (t != NULL)
        printf("the queuu contains %s\t\t%d\n", t->name, t->id);
}

void whoPrint(void* elementp, void *mes_buf){
    clients_t *t = (clients_t*)elementp;
    char bufp[30];
    if (t != NULL)
        strcat(((mes_t *)mes_buf)->mtext, t->name);
    strcat(((mes_t *)mes_buf)->mtext, " ");
    snprintf(bufp, 30, "%d", t->id);
    strcat(((mes_t *)mes_buf)->mtext, bufp);
    strcat(((mes_t *)mes_buf)->mtext, " ;");
    printf("the queuu contains %s\t\t%d\n", t->name, t->id);
}

int searchfn(void* elementp, void* keyp){
    clients_t *itemElement;
    char name[30];

    itemElement = (clients_t *) elementp;
    strcpy( name, (char *)keyp);
    if ((elementp == NULL)|(keyp == NULL)) return 0;
    if (!strcmp(itemElement->name, name)) return 1;
    else return 0;
}


void sendmes(int fd, mes_t *mesbuf) {
    long rc,nSend;
    char bufst[3]="st";

    rc = send(fd, bufst, sizeof(bufst), 0);
    /* send message */
    rc = 0;
    nSend = 0;
    rc = send(fd, mesbuf, sizeof(mes_t), 0);
    nSend += rc;
    while(rc != 0 && nSend < sizeof(mes_t)) {
        rc = send(fd, mesbuf, sizeof(mes_t), 0);
        nSend += rc;
    }
}

void broadCastMes(void* client, void* servMess) {
    void sendmes(int fd, mes_t *mesbuf);
    int cli_mem_fd;
    mes_t *mes_buf3;
    strcpy(mes_buf3->name, ((servM_t *)servMess)->name);
    strcpy(mes_buf3->mtext, ((servM_t *)servMess)->mtext);
    cli_mem_fd = ((clients_t *)client)->cli_fd;
    if(cli_mem_fd != ((servM_t *)servMess)->cli_fd) {
        //send(cli_mem_fd, &mes_buf3, sizeof(mes_buf3), 0);
        sendmes(cli_mem_fd, mes_buf3);
    }
}

void * processMessage(void*fd) {

    int cli_fd = *(int *)fd;
    long recvSize, rc;
    char buf3[3];
    mes_t *mes_buf;
    mes_buf = (mes_t *)malloc(sizeof(mes_t));
    servM_t *servmes1;
    servmes1= (servM_t *)malloc(sizeof(servM_t));
    printf("waiting on port %d\n", port);
    while (flag) {
        rc = 0;
        rc = recv(cli_fd, buf3, sizeof(buf3), 0);
        if(!strcmp(buf3,"st") && rc !=0) {\
            rc = 0;
            recvSize = 0;
            rc = recv(cli_fd, mes_buf, sizeof(*mes_buf)-recvSize, 0);
            recvSize += rc;
            while (rc != 0 && recvSize < sizeof(*mes_buf)) {
                rc = recv(cli_fd, (char*)mes_buf+recvSize, sizeof(*mes_buf)-recvSize, 0);
                recvSize += rc;

            }
            if(recvSize==0) {
                printf("the client quit the server.\n");
                return NULL;
            }

            printf("Server Received from %d: \t", cli_fd);
            printf("%s says: \"%s\"\n", mes_buf->name, mes_buf->mtext);

            strcpy(servmes1->name, mes_buf->name);
            strcpy(servmes1->mtext, mes_buf->mtext);
            servmes1->cli_fd = cli_fd;

            //PING
            if (!strcmp(mes_buf->mtext, "\\ping")) {
                strcpy(mes_buf->mtext, "the server is working");
                sendmes(cli_fd, mes_buf);
                //send(cli_fd, mes_buf, sizeof(*mes_buf), 0);
            }

            //general
            if (LockQSearch(qclient, searchfn, (void *)mes_buf->name) != NULL) {

                if (!strcmp(mes_buf->mtext, "\\leave")) {
                    strcpy(mes_buf->mtext, "leave the chat room");
                    strcpy(servmes1->name, mes_buf->name);
                    strcpy(servmes1->mtext, mes_buf->mtext);
                    LockQApplyValue(qclient, broadCastMes, (void *)servmes1);
                    LockQRemove(qclient, searchfn, (void *)mes_buf->name);
                    LockQApply(qclient, itemPrint);
                    printf("%s leave the room.\n", mes_buf->name);
                    strcpy(mes_buf->mtext, "the server: bye!");
                    //send(cli_fd, mes_buf, sizeof(*mes_buf), 0);
                    sendmes(cli_fd, mes_buf);
                }
                else if (!strcmp(mes_buf->mtext, "\\who")) {

                    strcpy(servmes1->mtext, "the member in the room: ");
                    strcpy(mes_buf->mtext, servmes1->mtext);
                    LockQApplyValue(qclient, whoPrint, mes_buf);
                    strcpy(mes_buf->name, "server ");
                    //send(cli_fd, mes_buf, sizeof(*mes_buf), 0);
                    sendmes(cli_fd, mes_buf);
                }
                else if(!strcmp(mes_buf->mtext, "\\closeserver")) {
                    flag = 0;
                    strcpy(servmes1->name, "server:");
                    strcpy(servmes1->mtext, "\\leave");
                    servmes1->cli_fd = -1;
                    LockQApplyValue(qclient, broadCastMes, (void *)servmes1);
                }
                else {
                    // echo back to clients
                    printf("broad cast the message. \n");
                    //LockQApply(qclient, itemPrint);
                    LockQApplyValue(qclient, broadCastMes, (void *)servmes1);
                }
            }
            //Join
            if (!strcmp(mes_buf->mtext, "\\join")) {
                client1 = (clients_t *)malloc(sizeof(clients_t));
                strcpy(client1->name, mes_buf->name);
                client1->id = ++idNum;
                client1->cli_fd = cli_fd;

                if (LockQSearch(qclient, searchfn, (void *)mes_buf->name) == NULL) {
                    LockQPut(qclient, client1);
                    strcpy(mes_buf->mtext, "join_the_chat_room");
                    //send(cli_fd, mes_buf, sizeof(*mes_buf), 0);
                    sendmes(cli_fd, mes_buf);
                }
                else {
                    strcpy(mes_buf->mtext, "server_has_the_same_name");
                    //send(cli_fd, mes_buf, sizeof(*mes_buf), 0);
                    sendmes(cli_fd, mes_buf);
                }
            }

            printf("nest message : \n");
        }
    }
    return NULL;
}


void init() {
    sockfd=socket(AF_INET, SOCK_STREAM, 0);
    if(sockfd < 0) {
        printf("fail to create a new socket");
        exit(-1);
    }

    memset((char *) &serv_addr, 0, sizeof(struct sockaddr_in));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    serv_addr.sin_addr.s_addr = htons(INADDR_ANY);

    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) == -1) {
        printf("bind error");
        exit(-1);
    }
    if (listen(sockfd, MAXPENDING) < 0) {
        printf("set listen fail.\n");
        exit(-1);
    }
    printf("sucess start the server\n");
    printf("start listen.\n");
    flag = 1;

}

int main(int argc, const char * argv[]) {

    if (argc < 2) {
    printf("please input the right parameter");
    return 1;
    }
    //bind to server port
    port = atoi(argv[1]);

    int i;
    //port = 8899;

    init();
    qclient = LockQOpen();

    while(flag) {
        int clifd = accept(sockfd,(struct sockaddr*)&cli_addr,&socSize);
        if (clifd == -1) {
            printf("connect client fail.\n");
            continue;
        }
        if(idNum <THREADNUM) {
            pthread_create(&threadP[idNum], NULL, processMessage, &clifd);
        }
        //mes_buf = (mes_p)malloc(sizeof(mes_t));
        printf("wait for the end of the thread,\n");
        //close the server

    }
    for(i=0;i<THREADNUM;i++) {
        pthread_join(threadP[i], NULL);
    }

    pthread_exit(NULL);
    qclose(qclient);
    close(sockfd);
    return 0;
}