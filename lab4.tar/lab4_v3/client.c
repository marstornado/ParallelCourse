#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>

#define BUF_SIZE 1024000

typedef struct message
{
    unsigned int msg_len;
    char name[20];
    char mtext[BUF_SIZE];
}mes_t, *mes_p;

int sockfd, port, flag;
//char *IP = "127.0.0.1";
char IP[30];
struct sockaddr_in server;

socklen_t socSize = sizeof(struct sockaddr_in);
char buf[BUF_SIZE];
mes_t *mes_buf, *mes_buf2;


void * sendM() {
    while(flag) {
        char buf2[]={};
        char buf3[3] = "st";
        long nSend, rc;
        scanf("%s", buf2);
        //strcpy(buf3, "st");
        strcpy(mes_buf2->mtext, buf2);
        mes_buf2->msg_len = sizeof(*mes_buf2);
        send(sockfd, buf3, sizeof(buf3), 0);
        rc = 0;
        nSend = 0;
        //printf("sockfd is %d.\n",sockfd);
        /* send message */
        while(rc != -1 && nSend < sizeof(*mes_buf2)) {
            rc = send(sockfd, mes_buf2, sizeof(*mes_buf2), 0);
            nSend += rc;
        }
        
        
        if (!strcmp(buf2,"\\leave")) {
            printf("leave the chat room. \n");
            flag = 0;
            break;
        }
    }
    flag = 0;
    return NULL;
}


void init() {
    printf("start the client.\n");
    
    /* initialize socket */
    sockfd=socket(AF_INET, SOCK_STREAM, 0);
    
    /* initialize server addr */
    memset((char *) &server, 0, sizeof(struct sockaddr_in));
    server.sin_family = AF_INET;
    server.sin_port = htons(port);
    server.sin_addr.s_addr = inet_addr(IP);
    //inet_aton(IP, &server.sin_addr);
    if(connect(sockfd, (struct sockaddr *)&server, sizeof(server)) == -1) {
        perror("can not connect to the client");
        printf("fail to start the client");
        exit(-1);
    }
    printf("the server is on connect to the server");
    
}

int main(int argc, char *argv[]) {
    
    long rc, recvSize;
    char bufst[3];
    pthread_t thread1;
    
    if (argc < 4) {
        printf("Usage: %s name <host> <port>\n", argv[0]);
        return 1;
    }
    port = atoi(argv[3]);
    strcpy(IP,argv[2]);
    flag=1;
    mes_buf = (mes_p)malloc(sizeof(mes_t));
    mes_buf2 = (mes_p)malloc(sizeof(mes_t));
    strcpy(mes_buf->name, argv[1]);
    strcpy(mes_buf2->name, argv[1]);

    /*
    strcpy(IP,"127.0.0.1");
    port = 8899;
    flag=1;
    mes_buf = (mes_p)malloc(sizeof(mes_t));
    mes_buf2 = (mes_p)malloc(sizeof(mes_t));
    strcpy(mes_buf->name, "mars");
    strcpy(mes_buf2->name, "mars");
    */
    init();
    
    printf("let us input the message:\n");
    /* start a thread to process the input message */
    pthread_create(&thread1, NULL, sendM, NULL);
    
    /* receive echo message*/
    while (flag) {
        //printf("start warting flag ");
        rc = 0;
        rc = recv(sockfd, bufst, sizeof(bufst), 0);
        if(!strcmp(bufst,"st") && rc != 0) {
            recvSize = 0;
            rc = 0;
            rc = recv(sockfd, mes_buf, sizeof(*mes_buf)-recvSize, 0);
            recvSize += rc;
            while (rc != 0 && recvSize < sizeof(*mes_buf)) {
                rc = recv(sockfd, (char*)mes_buf+recvSize, sizeof(*mes_buf)-recvSize, 0);
                recvSize += rc;
                
            }
            printf("%s says: \"%s\"\n", mes_buf->name,mes_buf->mtext);
            if (!strcmp(mes_buf->mtext, "\\leave")) {
                printf("leave the chat room. \n");
                flag = 0;
                break;
            }
        
        }
    }
    printf("the person quit the program. \n");
    pthread_join(thread1, NULL);
    pthread_exit(NULL);
    close(sockfd);
    return 0;
}