cp lab4_/lab3_udp/main.pc ./test/client.c
cp lab3_udpServer/lab3_udpServer/main.c ./test/server.c
