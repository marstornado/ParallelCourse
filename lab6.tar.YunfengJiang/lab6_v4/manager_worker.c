#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mpi.h"
#include "unistd.h"
#include <math.h>
#include <pthread.h>
#include "integrate.h"
#include "queue.h"
#include "lockQueue.h"
#include "manager_worker.h"

typedef struct qthread {
    void *qBegin;
    double *qelem;
    double *result;
    int num;
    int tnum;
    int flag;
} qth_t;
pthread_mutex_t mutex1 = PTHREAD_MUTEX_INITIALIZER;

void * manager(qth_t *qmanage);
void *partition(void *qthp);
void *procParaSend(void *qthreadp);
void * worker(int pid, int num);
void *runIntegate(void *qthreadp);
double func(double x);

int main(int argc, char *argv[])
{
    int num, pid, printer;
    double qelem[8] = {-5, -10, 0.01, 0, 0, 0, 0, 0};
    msgInit(&argc, &argv, &num, &pid);
    printer = num-1;
    //printf("pid is %d num is %d printer is %d\n", pid, num, printer);
    void *qBegin;

    if(pid==0) {
        qth_t *qmanage;

        double *qelemM;
        qBegin = LockQOpen();
        qmanage = (qth_t *)malloc(sizeof(qth_t));
        qelemM = (double *)malloc(sizeof(double)*8);
        memcpy(qelemM, qelem,8*sizeof(double));
        qmanage->qelem = qelemM;
        qmanage->num = (num-2)*10;
        qmanage->tnum = 2;
        qmanage->qBegin = qBegin;
        manager(qmanage);
        printf("-----------------------rank %d finish\n", pid);
    }
    /*
    else if(pid == printer) {
        double res[num-1], allresult=0;
        double strs[num-1], allstrips=0;
        double restmp[2];
        int i, from;

        for (i = 0; i< num-2; i++) {
            dataRecv(from, restmp, 2);
            printf("pid is %d  num is %d res is %f strips is %f\n", printer, num, restmp[0], restmp[1]);
            res[from] = restmp[0];
            allresult += restmp[0];
            strs[from] = restmp[1];
            allstrips += restmp[1];
        }
        printf("pid is %d allresult is %f allstrips is %f finish\n", pid, allresult, allstrips);
        printf("-----------------------rank %d finish\n", pid);
    }
    */
    else {
        worker(pid, num);
        printf("-----------------------rank %d finish\n", pid);
    }

    MPI_Finalize();
}

void * manager(qth_t *qmanage) {:“
    pthread_t thread1, thread2;
    pthread_create(&thread1, NULL, partition, (void *)qmanage);
    pthread_create(&thread2, NULL, procParaSend, (void *)qmanage);
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    return NULL;
}
void * worker(int pid, int num) {
    char buf[5];
    int i,from, flag=1;
    double *qelemW, *result;
    void *qBegin;
    qth_t *qworker;
    pthread_t threads[TNUM];
    qworker = (qth_t *)malloc(sizeof(qth_t));
    qworker->num = TNUM*10;
    qworker->tnum = TNUM;
    result = (double *)malloc(sizeof(double)*2);
    result[0] = 0;
    result[1] = 0;
    qworker->result = result;
    strcpy(buf,"go");
    do {
        msgGo(0, buf);
        msgWait(from,buf);
        if(!strcmp(buf, "wait")) {
            printf("wait \n");
        }
        else if(!strcmp(buf, "go")) {
            qelemW = (double *)malloc(sizeof(double)*8);
            qBegin = LockQOpen();
            qworker->qBegin = qBegin;
            dataRecv(from, qelemW, 8);
            qworker->qelem = qelemW;
            qworker->flag=1;
            printf("pid %d recv data from 0 a is %f\n",  pid, qelemW[0]);
            pthread_create(&threads[0], NULL, partition, (void *)qworker);
            for (i = 1; i<TNUM; i++) {
                pthread_create(&threads[i], NULL, runIntegate, (void *)qworker);
            }
            for(i = 0; i< TNUM; i++) {
                pthread_join(threads[i], NULL);
            }

            //pthread_join(threads[0], NULL);
            //runIntegate((void *)qworker);
            LockQClose(qBegin);

        }
        else if (!strcmp(buf, "done")){
            flag = 0;
        }
    } while (flag);
    printf("finish pid is %d res is %f strps is %f \n", pid, result[0], result[1]);
    dataSend(num -1, result, 2);
    return NULL;
}

void *partition(void *qthp) {
    qth_t *qth = (qth_t*)qthp;
    double *qpar;
    double a, b, precs;
    int pnum, i;
    void *qBegin;
    pnum = qth->num;
    qBegin = qth->qBegin;
    a = (qth->qelem)[0];
    b = (qth->qelem)[1];
    precs = (qth->qelem)[2];
    //printf("a %f b %f \n", a, b);
    for (i=0; i < pnum; i++) {
        qpar = (double *)malloc(sizeof(double)*8);
        qpar[0] = a + ((b-a)/pnum)*i;
        qpar[1] = a + ((b-a)/pnum)*(i+1);
        qpar[2] = precs;
        qpar[3] = i;
        qpar[4] = pnum;
        qpar[5] = 0; qpar[6] = 0; qpar[7] = 0;
        //printf("qput is %f, num is %f, pnum is %f\n", qpar[0], qpar[3], qpar[4]);
        LockQPut(qBegin, qpar);
    }
    printf("partition finished \n");
    pthread_exit ("thread all done");
    return NULL;
}

void *procParaSend(void *qthreadp) {
    qth_t *qthread = (qth_t *)qthreadp;
    char buf[5];
    double *qelem;
    int from, flag=1;
    int i = 0;
    int pnum=qthread->num;
    void *qBegin = qthread->qBegin;
    printf("start wait for reqs que length is pnum %d\n", pnum);
    do {
        msgRecv(from, buf, sizeof(buf));
        qelem = LockQGet(qBegin);
        if(qelem !=NULL || flag !=0) {
            if(qelem != NULL) {
                strcpy(buf, "go");
                msgGo(from, buf);
                MPI_Send(qelem, 8, MPI_DOUBLE, from, MSGTAG, ALL);
                if(qelem[3] > qelem[4]-2) {
                    flag = 0;
                }
                printf("send data a is %f, 4 is %f\n", qelem[0], qelem[4]);
            }
            else {
                printf("wait\n");
                strcpy(buf, "wait");
                msgGo(from, buf);
            }
        }
        else {
            strcpy(buf, "done");
            msgGo(from, buf);
            i++;
            printf("from is %d i is %d\n",from, i);
        }
    } while (i < pnum/10);
    printf("procParaSend finish\n");
    pthread_exit ("thread all done");
    return NULL;
}

void *runIntegate(void *qthreadp) {
    qth_t *qthread = (qth_t *)qthreadp;
    void *qBegin = qthread->qBegin;
    double *qelem;
    qelem = LockQGet(qBegin);

    while(qelem !=NULL || qthread->flag != 0) {
        if(qelem != NULL) {
            //printf("test a %f  3 is  %f 4 is %f 6 is %f 7 is %f \n", qelem[0], qelem[3], qelem[4], qelem[6], qelem[7]);
            integrate(func, qelem[0], qelem[1], qelem[2], &qelem[6], &qelem[7]);
            pthread_mutex_lock( &mutex1 );
            (qthread->result)[0] += qelem[6];
            (qthread->result)[1] += qelem[7];
            pthread_mutex_unlock( &mutex1 );
            //printf("res is %f stris is %f\n", (qthread->result)[0], (qthread->result)[1]);
            if(qelem[3] > qelem[4] -2) {
                qthread->flag = 0;
            }
        }
        qelem = LockQGet(qBegin);
    }
/*
    while(qelem !=NULL || flag !=0) {
        if(qelem != NULL) {
            printf("test %f \n", qelem[0]);

            //integrate(func, qelem[0], qelem[1], qelem[2], &qelem[6], &qelem[7]);

            pthread_mutex_lock( &mutex1 );
            *(qthread->result) += qelem[6];
            *(qthread->strips) += qelem[7];
            pthread_mutex_unlock( &mutex1 );
            if(qelem[3] > qelem[4] -2) {
                flag = 0;
            }
            qelem = LockQGet(qBegin);
        }
    }
*/
    return NULL;
}

double func(double x) {
    //return x*sin(x*x);
    return x+5;
}
