#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mpi.h"
#include "unistd.h"
#include <math.h>
#include <pthread.h>
#include "integrate.h"
#include "queue.h"
#include "lockQueue.h"
#include "manager_worker.h"

typedef struct qthread {
    void *qBegin;
    double *qelem;
    double *result, *strips;
    int num;
    int flag;
} qth_t;

void manager_worker(qth_t *qthread, void *(*funcp)(void *qthread));
void *partition(void *qthp);
void *runIntegate(void *qthreadp);
void *procParaSend(void *qthreadp);
double func(double x);
void temp(qth_t *qthread);


int main(int argc, char *argv[])
{
    int num, pid, printer;
    double qelem[8] = {-5, -10, 0.01, 0, 0, 0, 0, 0};
    double result = 0;
    double strips = 0;
    msgInit(&argc, &argv, &num, &pid);
    printer = num-1;
    //printf("pid is %d num is %d printer is %d\n", pid, num, printer);


    if(pid==0) {
        //manager();
        qth_t *qproc;
        qproc = (qth_t *)malloc(sizeof(qth_t));
        qproc->qelem = qelem;
        qproc->num = (num-2)*10;
        manager_worker(qproc, procParaSend);
        printf("-----------------------rank %d finish\n", pid);
    }
    else if(pid == printer) {
        double restmp, res[num-1], allresult=0;
        double strstmp, strs[num-1], allstrips=0;
        int i, from;

        for (i = 0; i< num-2; i++) {
            dataRecv(from, &restmp, 1);
            dataRecv(from, &strstmp, 1);
            printf("pid is %d  num is %d i is %d strips is %f\n", printer, num, i, strstmp);
            res[from] = restmp;
            allresult += restmp;
            strs[from] = strstmp;
            allstrips += strstmp;
        }
        printf("pid is %d allresult is %f allstrips is %f finish\n", pid, allresult, allstrips);
        printf("-----------------------rank %d finish\n", pid);
    }
    else {
        int from;
        char mess[5];
        double qelemW[8];
        int flag = 1;
        qth_t *qproc;
        qproc = (qth_t *)malloc(sizeof(qth_t));
        qproc->qelem = qelemW;
        qproc->num = (TNUM)*10;
        qproc->result = &result;
        qproc->strips = &strips;

        do {
            strcpy(mess,"g");
            printf("send g\n");
            msgGo(0, mess);
            msgWait(from,mess);
            if(!strcmp(mess, "wait")) {
                printf("wait \n");
            }
            else if(!strcmp(mess, "go")) {
                dataRecv(from, qelemW, sizeof(double)*8);
                printf("aa is %f\n",  qproc->qelem[0]);
                //manager_worker(qproc, runIntegate);
            }
            printf("main a is %s, \n",mess);
            if(!strcmp(mess, "done")) {
                //printf("test\n");
                flag = 0;
            }
        }while(flag);
        //printf("result is %f to printer %d ", result, printer);
        dataSend(printer, &result, 1);
        dataSend(printer, &strips, 1);
        printf("rank %d printer is %dfinish\n", pid, printer);
        printf("-----------------------rank %d finish\n", pid);
    }

    MPI_Finalize();
}

void manager_worker(qth_t *qthread, void *(*funcp)(void *qthread)) {

    double qtmp[8], *qelem;
    void *qBegin;
    qth_t *qinfo;
    int i, num;
    qelem = qthread->qelem;
    num = qthread->num;
    pthread_t threads[TNUM];

    memcpy(&qtmp,qelem,8*sizeof(double));
    qinfo = (qth_t *)malloc(sizeof(qth_t));
    qBegin = LockQOpen();
    qinfo->qBegin = qBegin;
    qinfo->qelem = qtmp;
    qinfo->num = num;
    printf("the num of process is %d, \n", qinfo->num);
    qinfo->result = qthread->result;
    qinfo->strips  = qthread->strips;


    pthread_create(&threads[0], NULL, partition, (void *)qinfo);
    pthread_join(threads[0], NULL);
    /*
    for (i = 1; i<TNUM; i++) {
        pthread_create(&threads[i], NULL, funcp, qinfo);
    }
    for(i = 1; i< TNUM; i++) {
        pthread_join(threads[i], NULL);
    }
*/
    funcp(qinfo);
    //partition(qinfo);

}

void *partition(void *qthp) {
    qth_t *qth = (qth_t*)qthp;
    double *qelem, *qpar;
    double a, b, precs;
    int i, pnum;
    void *qPart;
    qelem = qth->qelem;
    pnum = qth->num;
    qPart = qth->qBegin;
    a = qelem[0];
    b = qelem[1];
    precs = qelem[2];
    printf("a %f b %f \n", a, b);
    for (i=0; i < pnum; i++) {
        qpar = (double *)malloc(sizeof(double)*8);
        qpar[0] = a + ((b-a)/pnum)*i;
        qpar[1] = a + ((b-a)/pnum)*(i+1);
        qpar[2] = precs;
        qpar[3] = i;
        qpar[4] = pnum;
        qpar[5] = 0; qpar[6] = 0; qpar[7] = 0;
        //printf("temp is %f,\n", qpar[0]);
        LockQPut(qPart, qpar);
    }
    printf("partition finished \n");
    return NULL;
}

void *runIntegate(void *qthreadp) {
    qth_t *qthread = (qth_t *)qthreadp;
    void *qBegin = qthread->qBegin;
    double *qelem;
    int flag=1;
    qelem = LockQGet(qBegin);
    while(qelem !=NULL || flag !=0) {
        if(qelem != NULL) {
            integrate(func, qelem[0], qelem[1], qelem[2], &qelem[6], &qelem[7]);
            *(qthread->result) += qelem[6];
            *(qthread->strips) += qelem[7];
            if(qelem[3] > qelem[4] -2) {
                flag = 0;
            }
            qelem = LockQGet(qBegin);
        }
    }
    return NULL;
}

void *procParaSend(void *qthreadp) {
    qth_t *qthread = (qth_t *)qthreadp;
    char buf[5];
    double *qelem;
    int from, flag = 1;
    int i=0;
    int pnum=qthread->num;
    printf("start wait for reqs pnum is %d\n", pnum);
    void *qBegin = qthread->qBegin;
    do {
        msgRecv(from, buf, sizeof(buf));
        qelem = LockQGet(qBegin);
        if(qelem !=NULL || flag !=0) {
            if(qelem != NULL) {
                //printf("a is %f\n", qelem[0]);
                strcpy(buf, "go");
                msgGo(from, buf);
                MPI_Send(qelem, sizeof(double)*8, MPI_DOUBLE, from, MSGTAG, ALL);
                printf("3 is %f, 4 is %f\n", qelem[3], qelem[4]);
                if(qelem[3] > qelem[4]-2) {
                    flag = 0;
                }
            }
            else {
                printf("wait\n");
                 strcpy(buf, "wait");
                 msgGo(from, buf);
            }
        }
        else {
            strcpy(buf, "done");
            msgGo(from, buf);
            i++;
            printf("i is %d\n", i);
        }
    } while (i < pnum/10);
    printf("procParaSend finish\n");
    return NULL;
}

double func(double x) {
    //return x*sin(x*x);
    return x+5;
}

void temp(qth_t *qthread) {
    char buf[5];
    int from;
    printf("num\n");
    msgRecv(from, buf, sizeof(buf));
    strcpy(buf, "go");
    msgGo(from, buf);
    printf("man go");
}
