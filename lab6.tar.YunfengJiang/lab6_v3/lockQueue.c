//
//  lockQueue.c
//  lab6
//
//  Created by mastornado on 11/2/14.
//  Copyright (c) 2014 mastornado. All rights reserved.
//

#include "lockQueue.h"
#include "queue.h"
#include <pthread.h>
#include <stdlib.h>

typedef struct {
    pthread_mutex_t mutexl;
    void *qp;
}lockNode;


public void* LockQOpen(void) {
    pthread_mutex_t mutexl = PTHREAD_MUTEX_INITIALIZER;
    lockNode *lockq =(lockNode*)malloc(sizeof(lockNode));
    lockq->mutexl = mutexl;
    pthread_mutex_lock(&mutexl);
    void *lockQBegin = qopen();
    pthread_mutex_unlock(&mutexl);
    lockq->qp = lockQBegin;
    return lockq;
}

public void LockQPut(void *qp, void* elementp) {
    lockNode *lockq = (lockNode *)qp;
    pthread_mutex_t mutexl = lockq->mutexl;
    pthread_mutex_lock(&mutexl);
    qput(lockq->qp, elementp);
    pthread_mutex_unlock(&mutexl);
}

public void* LockQGet(void *qp) {
    lockNode *lockq = (lockNode *)qp;
    pthread_mutex_t mutexl = lockq->mutexl;
    pthread_mutex_lock(&mutexl);
    void *elementp = qget(lockq->qp);
    pthread_mutex_unlock(&mutexl);
    return elementp;
}

public void LockQApply(void *qp, void (*fn)(void* elementp)) {
    lockNode *lockq = (lockNode *)qp;
    pthread_mutex_t mutexl = lockq->mutexl;
    pthread_mutex_lock(&mutexl);
    qapply(lockq->qp, fn);
    pthread_mutex_unlock(&mutexl);
}

public void LockQApplyValue(void *qp, void (*fn)(void* elementp, void* key), void* skey){
    lockNode *lockq = (lockNode *)qp;
    pthread_mutex_t mutexl = lockq->mutexl;
    pthread_mutex_lock(&mutexl);
    qapplyValue(lockq->qp, fn, skey);
    pthread_mutex_unlock(&mutexl);
}

public void* LockQSearch(void *qp,
                         int (*searchfn)(void* elementp,void* keyp),
                         void* skeyp) {
    lockNode *lockq = (lockNode *)qp;
    pthread_mutex_t mutexl = lockq->mutexl;
    pthread_mutex_lock(&mutexl);
    void *searchp = qsearch(lockq->qp, searchfn, skeyp);
    pthread_mutex_unlock(&mutexl);
    return searchp;
}

public void* LockQRemove(void *qp,
                         int (*searchfn)(void* elementp,void* keyp),
                         void* skeyp) {
    lockNode *lockq = (lockNode *)qp;
    pthread_mutex_t mutexl = lockq->mutexl;
    pthread_mutex_lock(&mutexl);
    void* returnValue = qremove(lockq->qp, searchfn, skeyp);
    pthread_mutex_unlock(&mutexl);
    return returnValue;
}

public void LockQClose(void *qp) {
    lockNode *lockq = (lockNode *)qp;
    pthread_mutex_t mutexl = lockq->mutexl;
    pthread_mutex_lock(&mutexl);
    qclose(lockq->qp);
    pthread_mutex_unlock(&mutexl);
    
}
