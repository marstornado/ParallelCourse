//
//  integrate.c
//  para_lab2
//
//  Created by mastornado on 10/5/14.
//  Copyright (c) 2014 mastornado. All rights reserved.
//
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "integrate.h"

public void integrate(double (*f)(double x), double a, double b, double precision, double *result, double *strips) {
    double i;
    double width;
    double res1, res2;
    double strips_tmp;
    
    strips_tmp = 1.0;
    res1 = -INFINITY;
    res2 = INFINITY;
    while(fabs(res2 - res1) > precision ) {
        res2 = res1;
        res1 = 0;
        width = (b - a)/strips_tmp;
        //printf("a is %f , b is %f  width is %f \n", a, b, width);
        for(i = 0;i < strips_tmp;  i++) {
            res1 += 0.5*(f(a + width*(i+1))+f(a + width*i))*width;
        }
        strips_tmp++;
    }

    //printf("res 1 is %f %f %f %f\n", a, b, res1, strips_tmp-1);
    (*strips) = strips_tmp - 1;
    (*result) = res1;
}
