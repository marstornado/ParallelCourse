#define MSGTAG 103
#define ALL MPI_COMM_WORLD
#define ANY MPI_ANY_SOURCE
#define TNUM 2

#define msgInit(argc, argv, num, pid) \
    {    MPI_Init(argc, argv);              \
         MPI_Comm_rank(MPI_COMM_WORLD,pid);       \
         MPI_Comm_size(MPI_COMM_WORLD, num);     \
    }
#define msgFinalize() \
    MPI_Finalize()
#define msgSend(to, buf, size) \
    MPI_Send(buf, size, MPI_CHAR, to, MSGTAG, ALL)
#define msgRecv(from, buf, size)  {                            \
    MPI_Status status;                         \
    MPI_Recv(buf, size, MPI_CHAR, ANY, MSGTAG, ALL, &status); \
    from = status.MPI_SOURCE;        \
}
#define dataRecv(from, buf, size)  {                            \
MPI_Status status;                         \
MPI_Recv(buf, size, MPI_DOUBLE, ANY, MSGTAG, ALL, &status); \
from = status.MPI_SOURCE;        \
}
#define dataSend(to, buf, size) \
    MPI_Send(buf, size, MPI_DOUBLE, to, MSGTAG, ALL)
#define msgWait(from, mess) \
    msgRecv(from, mess, sizeof(mess))
#define msgGo(to, mess) \
    MPI_Send(mess, sizeof(mess), MPI_CHAR, to, MSGTAG, ALL)
#define msgAny(mess) { \
    int from;      \
    msgRecv(from, mess, sizeof(mess)); \
}
