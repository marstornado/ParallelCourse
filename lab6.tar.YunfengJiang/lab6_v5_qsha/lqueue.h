/*
 * lqueue.h -- public interface to the locked queue module
 */
#pragma once
#define public
#define private static

/* create an empty queue */
public void* lqopen(void);

/* deallocate a queue, assuming every element has been removed and deallocated */
public void lqclose(void *lqBegin);

/* put element at end of queue */
public void lqput(void *lqBegin, void *elementp);

/* get first element from a queue */
public void* lqget(void *lqBegin);

/* apply a void function (e.g. a printing fn) to every element of a queue */
public void lqapply(void *lqBegin, void (*fn)(void* elementp));

/* search a queue using a supplied boolean function, returns an element */
public void* lqsearch(void *lqBegin,
                      int (*searchfn)(void* elementp,void* keyp),
                      void* skeyp);

/* search a queue using a supplied boolean function, removes an element */
public void* lqremove(void *lqBegin,
                      int (*searchfn)(void* elementp,void* keyp),
                      void* skeyp);


