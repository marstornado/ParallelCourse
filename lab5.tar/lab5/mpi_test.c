#include"mpi.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MYTAG 103

int main(int argc,char *argv[])
{
       int a, b, c, d, r;
       int myrank, numprocs, namelen;
       MPI_Status status;

       MPI_Init(&argc,&argv);

       MPI_Comm_rank(MPI_COMM_WORLD,&myrank);
       MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
       if(myrank==0)
       {
            printf("please input number a, b, c, d : \n");
            scanf("%d %d %d %d", &a, &b, &c, &d);
            MPI_Send(&a, 1, MPI_INT,1, MYTAG, MPI_COMM_WORLD);
            MPI_Send(&b, 1, MPI_INT,1, MYTAG, MPI_COMM_WORLD);
            MPI_Send(&c, 1, MPI_INT,2, MYTAG, MPI_COMM_WORLD);
            MPI_Send(&d, 1, MPI_INT,2, MYTAG, MPI_COMM_WORLD);
            MPI_Recv(&r, 1, MPI_INT, MPI_ANY_SOURCE, MYTAG, MPI_COMM_WORLD, &status);
            printf("the minimum num of the four number : %d\n", r);
       }
       else
       {
            MPI_Recv(&a, 1, MPI_INT, MPI_ANY_SOURCE, MYTAG, MPI_COMM_WORLD,&status);
            MPI_Recv(&b, 1, MPI_INT, MPI_ANY_SOURCE, MYTAG, MPI_COMM_WORLD,&status);
            if(a > b)
            {
                r = b;
            }
            else
            {
                r = a;
            }
            if(myrank == 3) {
                MPI_Send(&r, 1, MPI_INT,0, MYTAG, MPI_COMM_WORLD);
            }
            else {
                MPI_Send(&r, 1, MPI_INT,3, MYTAG, MPI_COMM_WORLD);
            }
       }
       MPI_Finalize();
       return 0;
}
