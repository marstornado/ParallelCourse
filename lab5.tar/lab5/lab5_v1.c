#include"mpi.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MYTAG 103

int main(int argc,char *argv[])
{
    int myrank, numprocs, namelen, cmd, starter, num, i, ranktmp;
    MPI_Status status;
    char  mess[5], sig[5] = "yes";
    MPI_Init(&argc,&argv);
    MPI_Comm_rank(MPI_COMM_WORLD,&myrank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
    
    if(argc < 2) {
        printf("printf input the right parameter: \n");
    }
    else {
        cmd = atoi(argv[1]);
    }
    
    if( cmd == 1) {
        starter = 0;
        num = numprocs;
        ranktmp = 0;
    }
    else if( cmd == 2) {
        starter = 0;
        num = 1;
        ranktmp = (myrank+1)%numprocs;
    }
    else if ( cmd == 3) {
        starter = (-1)*(numprocs-1);
        num = starter + 1;
        if (myrank >= 1) {
            ranktmp = myrank-1;
        }
        else {
            ranktmp = numprocs-1;
        }
        
    }
    
    
    if (myrank == abs(starter)) {
        printf("Hello: %d processes, process %d .\n", numprocs, myrank);
        if (numprocs > 1) {
            //for(i = starter+1; i< num; i++)
            i = starter+1;
            do {
                MPI_Send(sig, sizeof(sig), MPI_CHAR, abs(i), MYTAG, MPI_COMM_WORLD);
                MPI_Recv(mess, sizeof(mess), MPI_CHAR, MPI_ANY_SOURCE, MYTAG, MPI_COMM_WORLD, &status);
                if(strcmp(mess, sig)) {
                    printf("return error message. \n");
                }
                i++;
            }
            while (i< num);
        }
    }
    else {
        MPI_Recv(mess, sizeof(mess), MPI_CHAR, MPI_ANY_SOURCE, MYTAG, MPI_COMM_WORLD, &status);
        if(!strcmp(mess, sig)) {
            printf("Hello: %d processes, process %d .\n", numprocs, myrank);
        }
        else {
            printf("return error message. \n");
        }
        MPI_Send(sig, sizeof(sig), MPI_CHAR, ranktmp, MYTAG, MPI_COMM_WORLD);
    }
    
    MPI_Finalize();
    return 0;
}
