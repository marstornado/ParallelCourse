#include"mpi.h"
#include"unistd.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MYTAG 103
#define RECV(mess, status, sig)  {                                                       \
      MPI_Recv(&mess, sizeof(mess), MPI_CHAR, MPI_ANY_SOURCE, MYTAG, MPI_COMM_WORLD, &status); \
      if(strcmp(mess, sig)) {                                                                   \
           printf("return error message. \n");                                           \
      }                                                                                                   \
}

void MpiTest(int starter, int num, int ranktmp, int myrank, int numprocs) {
    MPI_Status status;
    char  mess[5], sig[5] = "yes";
    if (myrank == abs(starter)) {
        //MPI_Barrier(MPI_COMM_WORLD);
        printf("Hello: %d processes, process %d .\n", numprocs, myrank);
        fflush(stdout);
        usleep(1000);
        if (numprocs > 1) {
            int i = starter+1;
            do {
                MPI_Send(sig, sizeof(sig), MPI_CHAR, abs(i), MYTAG, MPI_COMM_WORLD);
                RECV(mess, status, sig) ;
                i++;
            }
            while (i< num);
        }
    }
    else {
        RECV(mess, status, sig);
        //MPI_Barrier(MPI_COMM_WORLD);
        printf("Hello: %d processes, process %d .\n", numprocs, myrank);
        fflush(stdout);
        usleep(1000);
        MPI_Send(sig, sizeof(sig), MPI_CHAR, ranktmp, MYTAG, MPI_COMM_WORLD);
    }
}

int main(int argc,char *argv[])
{
    //int cmd, starter, num, ranktmp;
    int cmd, myrank, numprocs;
    MPI_Init(&argc,&argv);
    MPI_Comm_rank(MPI_COMM_WORLD,&myrank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    if(argc < 2) {
        printf("printf input the right parameter: \n");
        exit(-1);
    }
    cmd = atoi(argv[1]);

    if( cmd == 1) {
        MpiTest(0, numprocs, 0, myrank, numprocs);
    }
    else if( cmd == 2) {
        MpiTest(0, 1, (myrank+1)%numprocs, myrank, numprocs);
    }
    else if ( cmd == 3) {
        int starter = (-1)*(numprocs-1);
        if (myrank >= 1) {
            MpiTest((-1)*(numprocs-1), starter + 1, myrank-1, myrank, numprocs);
        }
        else {
            MpiTest((-1)*(numprocs-1), starter + 1, numprocs-1, myrank, numprocs);
        }
    }
    MPI_Finalize();
    return 0;
}
