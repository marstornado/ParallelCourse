#include"mpi.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MYTAG 103

int main(int argc,char *argv[])
{
       int myrank, numprocs, namelen;
       MPI_Status status;
       char  mess[5], sig[5] = "yes";
       MPI_Init(&argc,&argv);

       MPI_Comm_rank(MPI_COMM_WORLD,&myrank);
       MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

       if (myrank == 0) {
            printf("Hello: %d processes, process %d .\n", numprocs, myrank);
            if(numprocs > 1) {
                MPI_Send(sig, sizeof(sig), MPI_CHAR, 1, MYTAG, MPI_COMM_WORLD);
                MPI_Recv(mess, sizeof(mess), MPI_CHAR, MPI_ANY_SOURCE, MYTAG, MPI_COMM_WORLD, &status);
                if(!strcmp(mess, sig)) {
                     printf("finished. \n");
                 }
                 else {
                      printf("return error message. \n");
                 }
            }
       }
       else {
             MPI_Recv(mess, sizeof(mess), MPI_CHAR, MPI_ANY_SOURCE, MYTAG, MPI_COMM_WORLD, &status);
             if(!strcmp(mess, sig)) {
                 printf("Hello: %d processes, process %d .\n", numprocs, myrank);
             }
            else {
                 printf("return error message. \n");
            }
            if (myrank < numprocs-1) {
                MPI_Send(sig, sizeof(sig), MPI_CHAR, myrank+1, MYTAG, MPI_COMM_WORLD);
             }
             else if (myrank == numprocs-1) {
                   MPI_Send(sig, sizeof(sig), MPI_CHAR, 0, MYTAG, MPI_COMM_WORLD);
             }
       }
       MPI_Finalize();
       return 0;
}
