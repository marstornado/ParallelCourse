#include"mpi.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MYTAG 103

int main(int argc,char *argv[])
{
       int myrank, numprocs, namelen;
       MPI_Status status;
       char  mess[5], sig[5] = "yes";
       MPI_Init(&argc,&argv);
       MPI_Comm_rank(MPI_COMM_WORLD,&myrank);
       MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

       if (myrank == 0) {
            int i;
            printf("Hello: %d processes, process %d .\n", numprocs, myrank);
            for(i = 0; i< numprocs; i++) {
                MPI_Send(sig, strlen(sig), MPI_CHAR, i, MYTAG, MPI_COMM_WORLD);
                MPI_Recv(mess, strlen(mess), MPI_CHAR, i, MYTAG, MPI_COMM_WORLD, &status);
                if(!strcmp(mess, sig)) {
                    continue;
                    strcmp(mess, "");
                }
                else {
                    printf("return error message. \n");
                }
            }
       }
       else {
             MPI_Recv(mess, strlen(mess), MPI_CHAR, 0, MYTAG, MPI_COMM_WORLD, &status);
                if(!strcmp(mess, sig)) {
                    printf("Hello: %d processes, process %d .\n", numprocs, myrank);
                }
                else {
                    printf("return error message. \n");
                }
                MPI_Send(sig, strlen(sig), MPI_CHAR, 0, MYTAG, MPI_COMM_WORLD);
       }
       MPI_Finalize();
       return 0;
}
