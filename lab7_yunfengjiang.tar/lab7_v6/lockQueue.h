
/*
 * queue.h -- public interface to the queue module
 */
#define public
#define private static

/* create an empty queue */
public void* LockQOpen(void);

/* deallocate a queue, assuming every element has been removed and deallocated */
public void LockQClose(void *qp);

/* put element at end of queue */
public void LockQPut(void *qp, void *elementp);

/* get first element from a queue */
public void* LockQGet(void *qp);

/* apply a void function (e.g. a printing fn) to every element of a queue */
public void LockQApply(void *qp, void (*fn)(void* elementp));

/* apply a void function (e.g. a printing fn) to every element of a queue */
public void LockQApplyValue(void *qp, void (*fn)(void* elementp, void* key), void* skey);

/* search a queue using a supplied boolean function, returns an element */
public void* LockQSearch(void *qp,
                     int (*searchfn)(void* elementp,void* keyp),
                     void* skeyp);

/* search a queue using a supplied boolean function, removes an element */
public void* LockQRemove(void *qp,
                     int (*searchfn)(void* elementp,void* keyp),
                     void* skeyp);
